from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, List, Tuple
from dataclasses import dataclass

import numpy as np
import pandas as pd
import torch.nn as nn

from constants import REPO_ROOT

class TransformerLM(nn.Module):
    def __init__(
        self,
        vocab_size: int,
        d_model: int,
        n_heads: int,
        n_layers: int,
        d_ff: int,
        dropout: float,
        max_pos: int,
        pad_id: int = 0,
    ):
        super().__init__()
        self.pad_id = pad_id
        self.tok = nn.Embedding(vocab_size, d_model, padding_idx=pad_id)
        self.pos = nn.Embedding(max_pos, d_model)
        enc_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=d_ff,
            dropout=dropout,
            batch_first=True,
            activation="gelu",
        )
        self.enc = nn.TransformerEncoder(enc_layer, num_layers=n_layers)
        self.ln = nn.LayerNorm(d_model)
        self.head = nn.Linear(d_model, vocab_size, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T = x.shape
        if T > self.pos.num_embeddings:
            raise ValueError(f"T={T} exceeds max_pos={self.pos.num_embeddings}")
        pos = torch.arange(T, device=x.device).unsqueeze(0).expand(B, T)
        h = self.tok(x) + self.pos(pos)
        causal = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), diagonal=1)
        h = self.enc(h, mask=causal)
        h = self.ln(h)
        return self.head(h)

@dataclass
class NgramLM:
    order: int
    k: float
    vocab: Dict[str, int]
    unk_id: int
    bos_id: int
    counts: List[Dict[Tuple[int, ...], Counter]]
    context_totals: List[Dict[Tuple[int, ...], int]]

    def logprob_next(self, history: List[int], token_id: int) -> float:
        V = len(self.vocab)
        max_h = self.order - 1
        h = history[-max_h:] if max_h > 0 else []

        for n in range(self.order, 0, -1):
            ctx_len = n - 1
            ctx = tuple(h[-ctx_len:]) if ctx_len > 0 else tuple()

            dist = self.counts[n].get(ctx)
            total = self.context_totals[n].get(ctx, 0)

            if total > 0 and dist is not None:
                c_hw = dist.get(token_id, 0)
                p = (c_hw + self.k) / (total + self.k * V)
                return math.log(p)

        return -math.log(V)

    def logprob_prefixes(self, tokens: List[int]) -> List[float]:
        hist = [self.bos_id]
        cum = 0.0
        out = []
        for tid in tokens:
            lp = self.logprob_next(hist, tid)
            cum += lp
            out.append(cum)
            hist.append(tid)
        return out

def pick_latest_processed_dir() -> Path:
    root = Path(REPO_ROOT)
    cands = [p for p in root.glob("processed_*") if p.is_dir()]
    if not cands:
        raise FileNotFoundError(f"No processed_* under {root}")
    return max(cands, key=lambda p: p.stat().st_mtime)


def load_sequences(processed_dir: Path, ids: set[str], id_col: str) -> Dict[str, List[str]]:
    remaining = set(map(str, ids))
    out: Dict[str, List[str]] = {}
    for fp in sorted(processed_dir.glob("traces_batch_*.parquet")):
        if not remaining:
            break
        df = pd.read_parquet(fp, columns=[id_col, "tokens"])
        df[id_col] = df[id_col].astype(str)
        sub = df[df[id_col].isin(remaining)]
        if sub.empty:
            continue
        for tid, toks in zip(sub[id_col].tolist(), sub["tokens"].tolist()):
            out[str(tid)] = list(toks)
        remaining -= set(sub[id_col].tolist())
    return out


def log_odds_dirichlet(
    count_a: int, count_b: int, tot_a: int, tot_b: int, prior: float, V: int
) -> Tuple[float, float]:
    """
    Returns (log_odds, z_score) with symmetric Dirichlet prior alpha=prior.
    Reference: Monroe et al. (2008) "Fightin’ Words"
    """
    a = count_a + prior
    b = count_b + prior
    A = tot_a + prior * V
    B = tot_b + prior * V

    logodds = np.log(a / (A - a)) - np.log(b / (B - b))
    var = 1.0 / a + 1.0 / b
    z = float(logodds / np.sqrt(var))
    return float(logodds), float(z)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--processed_dir", type=str, default=None)
    ap.add_argument("--K", type=int, default=100, help="Use only first K tokens of each trace")
    ap.add_argument("--prior", type=float, default=0.01, help="Dirichlet prior alpha")
    ap.add_argument("--top", type=int, default=200, help="How many top tokens to export")
    args = ap.parse_args()

    processed_dir = Path(args.processed_dir) if args.processed_dir else pick_latest_processed_dir()
    splits = json.loads((processed_dir / "splits.json").read_text(encoding="utf-8"))
    id_col = splits.get("id_col", "trace_id_content")

    ben_ids = set(splits["benign"]["test"])
    mal_ids = set(splits["malware"]["test"])

    print("Using:", processed_dir)
    print("Loading sequences...")
    ben = load_sequences(processed_dir, ben_ids, id_col=id_col)
    mal = load_sequences(processed_dir, mal_ids, id_col=id_col)

    c_ben = Counter()
    c_mal = Counter()
    df_ben = Counter()
    df_mal = Counter()

    tot_ben = 0
    tot_mal = 0

    for toks in ben.values():
        pref = toks[: args.K]
        tot_ben += len(pref)
        c_ben.update(pref)
        df_ben.update(set(pref))

    for toks in mal.values():
        pref = toks[: args.K]
        tot_mal += len(pref)
        c_mal.update(pref)
        df_mal.update(set(pref))

    vocab = sorted(set(c_ben) | set(c_mal))
    V = len(vocab)

    rows = []
    n_ben = len(ben)
    n_mal = len(mal)

    for tok in vocab:
        cb = int(c_ben.get(tok, 0))
        cm = int(c_mal.get(tok, 0))
        fb = cb / max(1, tot_ben)
        fm = cm / max(1, tot_mal)

        db = int(df_ben.get(tok, 0))
        dm = int(df_mal.get(tok, 0))
        dfb = db / max(1, n_ben)
        dfm = dm / max(1, n_mal)

        logodds, z = log_odds_dirichlet(cm, cb, tot_mal, tot_ben, args.prior, V)

        rows.append({
            "token": tok,
            "count_mal": cm,
            "count_ben": cb,
            "freq_mal": fm,
            "freq_ben": fb,
            "freq_diff_mal_minus_ben": fm - fb,
            "docfreq_mal": dfm,
            "docfreq_ben": dfb,
            "docfreq_diff_mal_minus_ben": dfm - dfb,
            "logodds_mal_vs_ben": logodds,
            "z_logodds": z,
        })

    df = pd.DataFrame(rows)

    out_dir = processed_dir / "posthoc"
    out_dir.mkdir(parents=True, exist_ok=True)

    df.sort_values("z_logodds", ascending=False).head(args.top).to_csv(
        out_dir / f"token_diff_prefix{args.K}_top_mal.csv", index=False
    )
    df.sort_values("z_logodds", ascending=True).head(args.top).to_csv(
        out_dir / f"token_diff_prefix{args.K}_top_ben.csv", index=False
    )
    df.sort_values("freq_diff_mal_minus_ben", ascending=False).head(args.top).to_csv(
        out_dir / f"token_freqdiff_prefix{args.K}_top_mal.csv", index=False
    )

    df.to_csv(out_dir / f"token_diff_prefix{args.K}_full.csv", index=False)

    print("Saved:")
    print(" ", out_dir / f"token_diff_prefix{args.K}_top_mal.csv")
    print(" ", out_dir / f"token_diff_prefix{args.K}_top_ben.csv")
    print(" ", out_dir / f"token_diff_prefix{args.K}_full.csv")


if __name__ == "__main__":
    main()
