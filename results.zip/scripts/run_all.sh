#!/bin/bash
set -e

echo "Installing requirements"
poetry install

echo "Processing started."

echo "Step 0.1"
python3 0_1_extract_traces.py
echo "Step 0.1 done."

echo "Step 0.2"
python3 0_2_make_splits.py
echo "Step 0.2 done."

echo "Step 0.3"
python3 0_3_milestones.py
echo "Step 0.3 done."

echo "Step 0.4"
python3 0_4_sanity_check.py
echo "Step 0.4 done."

echo "Step 1.1"
python3 1_1_ngram_lr_train_threshold.py
echo "Step 1.1 done."

echo "Step 1.2"
python3 1_2_ngram_lr_eval.py
echo "Step 1.2 done."

echo "Step 2.1"
python3 2_1_tx_lm_train_threshold.py
echo "Step 2.1 done."

echo "Step 2.2"
python3 2_2_tx_lm_train_threshold_eval.py
echo "Step 2.2 done."

echo "Step 3.1"
python3 3_1_ngram_robustness_eval.py
echo "Step 3.1 done."

echo "Step 3.2"
python3 3_2_tx_robustness_eval.py
echo "Step 3.2 done."

echo "Step 4.0"
python3 4_0_validate.py
echo "Step 4.0 done."

echo "Step 4.1"
python3 4_1_posthoc_stats.py
echo "Step 4.1 done."

echo "Step 4.2"
python3 4_2_length_diagnostics.py
echo "Step 4.2 done."

echo "Step 4.3"
python3 4_3_prefix_auc_ngram.py
echo "Step 4.3 done."

echo "Step 4.4"
python3 4_4_prefix_cut_experiment.py
echo "Step 4.4 done."

echo "Step 4.5"
python3 4_5_prefix_auc_tx.py
echo "Step 4.5 done."

echo "Step 4.6"
python3 4_6_prefix_cut_tx.py
echo "Step 4.6 done."

echo "Step 4.7"
python3 4_7_per_family_auc.py --model both
echo "Step 4.7 done."

echo "Step 4.8"
python3 4_8_token_diff_prefix.py --K 100 --top 200
echo "Step 4.8 done."

echo "Step 4.9.1"
python3 4_9_remove_top_tokens_auc.py \
  --model both \
  --topN 10 \
  --mode remove \
  --scope prefix \
  --K 100
echo "Step 4.9.1 done."

echo "Step 4.9.2"
python3 4_9_remove_top_tokens_auc.py \
  --model both \
  --topN 10 \
  --mode remove \
  --scope prefix \
  --K 100
echo "Step 4.9.2 done."

echo "Step 4.9.3"
python3 4_9_remove_top_tokens_auc.py \
  --model both \
  --topN 10 \
  --mode mask \
  --scope prefix \
  --K 100
echo "Step 4.9.3 done."

echo "All scripts completed successfully."
