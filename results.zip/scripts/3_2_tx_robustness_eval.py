import json, random, hashlib, argparse
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from collections import Counter

import numpy as np
import pandas as pd
import torch
import torch.nn as nn

from constants import REPO_ROOT

SEED = 1337
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed_all(SEED)

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

@dataclass
class Cfg:
    pad: str = "<PAD>"
    bos: str = "<BOS>"
    unk: str = "<UNK>"

    d_model: int = 256
    n_heads: int = 8
    n_layers: int = 4
    d_ff: int = 1024
    dropout: float = 0.1
    max_pos: int = 50000

    score_context: int = 512
    score_stride: int = 512

cfg = Cfg()

class TransformerLM(nn.Module):
    def __init__(
        self,
        vocab_size: int,
        d_model: int,
        n_heads: int,
        n_layers: int,
        d_ff: int,
        dropout: float,
        max_pos: int,
        pad_id: int = 0,
    ):
        super().__init__()
        self.pad_id = pad_id
        self.tok = nn.Embedding(vocab_size, d_model, padding_idx=pad_id)
        self.pos = nn.Embedding(max_pos, d_model)
        enc_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=d_ff,
            dropout=dropout,
            batch_first=True,
            activation="gelu",
        )
        self.enc = nn.TransformerEncoder(enc_layer, num_layers=n_layers)
        self.ln = nn.LayerNorm(d_model)
        self.head = nn.Linear(d_model, vocab_size, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T = x.shape
        if T > self.pos.num_embeddings:
            raise ValueError(f"T={T} exceeds max_pos={self.pos.num_embeddings}")
        pos = torch.arange(T, device=x.device).unsqueeze(0).expand(B, T)
        h = self.tok(x) + self.pos(pos)
        causal = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), diagonal=1)
        h = self.enc(h, mask=causal)
        h = self.ln(h)
        return self.head(h)

def load_model(dirpath: Path, cfg: Cfg) -> Tuple[TransformerLM, Dict[str, int]]:
    with open(dirpath / "vocab.json", "r", encoding="utf-8") as f:
        vocab: Dict[str, int] = json.load(f)

    ck = torch.load(dirpath / "best.pt", map_location=DEVICE)
    pad_id = int(ck.get("pad_id", vocab.get(cfg.pad, 0)))

    model = TransformerLM(
        vocab_size=len(vocab),
        d_model=cfg.d_model,
        n_heads=cfg.n_heads,
        n_layers=cfg.n_layers,
        d_ff=cfg.d_ff,
        dropout=cfg.dropout,
        max_pos=cfg.max_pos,
        pad_id=pad_id,
    ).to(DEVICE)
    model.load_state_dict(ck["model"])
    model.eval()
    return model, vocab

def pick_latest_processed_dir() -> Path:
    root = Path(REPO_ROOT)
    cands = [p for p in root.glob("processed_*") if p.is_dir()]
    if not cands:
        raise FileNotFoundError(f"No processed_* directories under {root}.")
    return max(cands, key=lambda p: p.stat().st_mtime)

def resolve_processed_dir(user_arg: Optional[str] = None) -> Path:
    if user_arg:
        p = Path(user_arg)
        if not p.exists():
            raise FileNotFoundError(f"--processed_dir does not exist: {p}")
        return p
    return pick_latest_processed_dir()

def load_thresholds(processed_dir: Path) -> dict:
    p = processed_dir / "tx_thresholds.json"
    if not p.exists():
        raise FileNotFoundError(f"Missing {p}")
    return json.loads(p.read_text(encoding="utf-8"))

def iter_parquet_files(dirpath: Path, pattern: str):
    files = sorted(dirpath.glob(pattern))
    if not files:
        raise FileNotFoundError(f"No parquet files found in {dirpath} matching {pattern}")
    for fp in files:
        yield fp

def load_sequences_only(processed_dir: Path, ids: set[str], *, id_col: str) -> Dict[str, List[str]]:
    remaining = set(map(str, ids))
    out: Dict[str, List[str]] = {}
    for fp in iter_parquet_files(processed_dir, "traces_batch_*.parquet"):
        if not remaining:
            break
        df = pd.read_parquet(fp, columns=[id_col, "tokens"])
        df[id_col] = df[id_col].astype(str)
        sub = df[df[id_col].isin(remaining)]
        if sub.empty:
            continue
        for tid, toks in zip(sub[id_col].tolist(), sub["tokens"].tolist()):
            out[str(tid)] = toks
        remaining.difference_update(set(sub[id_col].tolist()))
    if remaining:
        print(f"[WARN] missing {len(remaining)} ids in trace batches.")
    return out

def load_meta(processed_dir: Path, ids: set[str], *, id_col: str) -> pd.DataFrame:
    remaining = set(map(str, ids))
    parts = []
    cols = [id_col, "label", "family", "source"]
    for fp in iter_parquet_files(processed_dir, "traces_batch_*.parquet"):
        if not remaining:
            break
        df = pd.read_parquet(fp, columns=cols)
        df[id_col] = df[id_col].astype(str)
        sub = df[df[id_col].isin(remaining)]
        if sub.empty:
            continue
        parts.append(sub[cols])
        remaining.difference_update(set(sub[id_col].tolist()))
    if parts:
        m = pd.concat(parts, ignore_index=True)
        return m.drop_duplicates(id_col)
    return pd.DataFrame({id_col: list(map(str, ids)), "label": None, "family": None, "source": None})

def load_milestones_long(processed_dir: Path, *, id_col: str) -> pd.DataFrame:
    batch_files = sorted(processed_dir.glob("milestones_batch_*.parquet"))
    single_file = processed_dir / "milestones.parquet"

    if batch_files:
        ms = pd.concat((pd.read_parquet(fp) for fp in batch_files), ignore_index=True)
    elif single_file.exists():
        ms = pd.read_parquet(single_file)
    else:
        raise FileNotFoundError(f"Missing milestones in {processed_dir} (milestones_batch_*.parquet).")

    if id_col not in ms.columns:
        if "trace_id" in ms.columns and id_col != "trace_id":
            ms = ms.rename(columns={"trace_id": id_col})
        else:
            raise ValueError(f"Milestones must contain id column: {id_col}")

    ms[id_col] = ms[id_col].astype(str)

    if "milestone" in ms.columns:
        idx_col = None
        for c in ["milestone_idx", "event_idx", "token_idx", "idx", "pos", "t_idx"]:
            if c in ms.columns:
                idx_col = c
                break
        if idx_col is None:
            raise ValueError("Long milestones schema but no index column found.")
        out = ms[[id_col, "milestone", idx_col]].rename(columns={idx_col: "milestone_idx"}).copy()
        out["milestone_idx"] = pd.to_numeric(out["milestone_idx"], errors="coerce").astype("Int64")
    else:
        wide_map = {"t_dns": "DNS", "t_c2": "C2", "t_pers": "Persistence", "t_priv": "PrivEsc"}
        present = [c for c in wide_map if c in ms.columns]
        if not present:
            raise ValueError("Milestones schema not recognized.")
        parts = []
        for col in present:
            tmp = ms[[id_col, col]].copy()
            tmp = tmp.rename(columns={col: "milestone_idx"})
            tmp["milestone"] = wide_map[col]
            parts.append(tmp)
        out = pd.concat(parts, ignore_index=True)
        out["milestone_idx"] = pd.to_numeric(out["milestone_idx"], errors="coerce").astype("Int64")

    out = out.dropna(subset=["milestone_idx"]).copy()
    out = out.sort_values([id_col, "milestone", "milestone_idx"])
    out = out.groupby([id_col, "milestone"], as_index=False).first()
    return out[[id_col, "milestone", "milestone_idx"]]

@torch.no_grad()
def logprob_prefixes_tx_contextcarry(
    model: TransformerLM,
    vocab: Dict[str, int],
    seq_tokens: List[str],
    *,
    context: int,
    stride: int,
    bos: str,
    unk: str,
) -> List[float]:
    """
    Returns cumulative log-probs per token in seq_tokens.
    Output length == len(seq_tokens). Index i corresponds to prefix ending at token i.
    """
    model.eval()
    bos_id = vocab[bos]
    unk_id = vocab[unk]

    ids = [bos_id] + [vocab.get(t, unk_id) for t in seq_tokens]
    N = len(seq_tokens)
    if N == 0:
        return []

    cum = 0.0
    out: List[float] = []

    t = 1
    while t <= N:
        t_end = min(N + 1, t + stride)
        a = max(0, t - context - 1)
        b = t_end

        x_ids = ids[a:b]
        y_ids = ids[a+1:b+1]
        L = min(len(x_ids), len(y_ids))
        x_ids = x_ids[:L]
        y_ids = y_ids[:L]

        x = torch.tensor([x_ids], dtype=torch.long, device=DEVICE)
        y = torch.tensor([y_ids], dtype=torch.long, device=DEVICE)

        logits = model(x)
        logp = torch.log_softmax(logits, dim=-1)
        tgt_lp = logp.gather(-1, y.unsqueeze(-1)).squeeze(-1).squeeze(0)

        for p in range(t, t_end):
            wi = p - (a + 1)
            if 0 <= wi < tgt_lp.numel():
                cum += float(tgt_lp[wi].item())
                out.append(cum)

        t = t_end

    if len(out) != N:
        raise AssertionError(f"context-carry scoring produced len(out)={len(out)} != N={N}")
    return out

def prefix_lr_series(
    model_mal: TransformerLM,
    vocab_mal: Dict[str, int],
    model_ben: TransformerLM,
    vocab_ben: Dict[str, int],
    seq_tokens: List[str],
    cfg: Cfg,
) -> List[float]:
    mal_lp = logprob_prefixes_tx_contextcarry(
        model_mal, vocab_mal, seq_tokens,
        context=cfg.score_context, stride=cfg.score_stride,
        bos=cfg.bos, unk=cfg.unk,
    )
    ben_lp = logprob_prefixes_tx_contextcarry(
        model_ben, vocab_ben, seq_tokens,
        context=cfg.score_context, stride=cfg.score_stride,
        bos=cfg.bos, unk=cfg.unk,
    )
    L = min(len(mal_lp), len(ben_lp))
    return [mal_lp[i] - ben_lp[i] for i in range(L)]

def max_prefix_lr(
    model_mal: TransformerLM,
    vocab_mal: Dict[str, int],
    model_ben: TransformerLM,
    vocab_ben: Dict[str, int],
    seq_tokens: List[str],
    cfg: Cfg,
) -> float:
    s = prefix_lr_series(model_mal, vocab_mal, model_ben, vocab_ben, seq_tokens, cfg)
    return max(s) if s else float("-inf")

def first_crossing(prefix_series: List[float], tau: float) -> Optional[int]:
    for i, v in enumerate(prefix_series):
        if v >= tau:
            return i
    return None

def corrupt_iid(tokens: List[str], p_del: float, rng: random.Random) -> List[str]:
    if p_del <= 0:
        return tokens
    return [t for t in tokens if rng.random() > p_del]

def corrupt_bursty(tokens: List[str], p_del: float, mean_burst: int, rng: random.Random) -> List[str]:
    if p_del <= 0:
        return tokens
    if mean_burst <= 1:
        return corrupt_iid(tokens, p_del, rng)

    p_end = 1.0 / float(mean_burst)
    p_start = p_del / (mean_burst * (1 - p_del) + 1e-12)
    p_start = min(1.0, max(0.0, p_start))

    out = []
    i = 0
    n = len(tokens)
    while i < n:
        if rng.random() < p_start:
            j = i
            while j < n:
                j += 1
                if rng.random() < p_end:
                    break
            i = j
        else:
            out.append(tokens[i])
            i += 1
    return out

def corrupt(tokens: List[str], p_del: float, mode: str, mean_burst: int, rng: random.Random) -> List[str]:
    if mode == "iid":
        return corrupt_iid(tokens, p_del, rng)
    if mode == "bursty":
        return corrupt_bursty(tokens, p_del, mean_burst, rng)
    raise ValueError(f"Unknown corruption mode: {mode}")

def stable_int_seed(*parts: str) -> int:
    h = hashlib.sha256("||".join(parts).encode("utf-8")).digest()
    return int.from_bytes(h[:8], "big", signed=False)

def corrupt_with_trace_seed(
    tokens: List[str],
    *,
    p_del: float,
    mode: str,
    mean_burst: int,
    base_seed: int,
    trace_id: str,
) -> Tuple[List[str], float]:
    tid_seed = stable_int_seed(str(base_seed), mode, f"{p_del:.4f}", trace_id)
    rng = random.Random(tid_seed)
    orig = len(tokens)
    out = corrupt(tokens, p_del=p_del, mode=mode, mean_burst=mean_burst, rng=rng)
    realized = 0.0 if orig == 0 else float(orig - len(out)) / float(orig)
    return out, realized

def early_table_from_det_and_ms(
    det: pd.DataFrame,
    ms_long: pd.DataFrame,
    *,
    id_col: str,
    det_col: str,
) -> pd.DataFrame:
    base = ms_long[[id_col, "milestone", "milestone_idx"]].drop_duplicates([id_col, "milestone"])
    df = base.merge(det[[id_col, det_col]], on=id_col, how="left")

    rows = []
    for milestone, g in df.groupby("milestone"):
        denom = int(g[id_col].nunique())
        if denom == 0:
            rows.append({
                "milestone": milestone,
                "denom_milestone_observed": 0,
                "detected_rate": None,
                "detected_before_rate": None,
                "lead_n": 0,
                "lead_median": None,
                "lead_p25": None,
                "lead_p75": None,
                "missing_detection": 0,
            })
            continue

        has_det = g[det_col].notna().to_numpy()
        detected_rate = float(np.mean(has_det))

        before_flags = np.zeros(len(g), dtype=bool)
        lead_vals = []

        ms_idx = g["milestone_idx"].astype("Int64").to_numpy()
        dt_idx = g[det_col].astype("Int64").to_numpy()

        for i in range(len(g)):
            if pd.isna(ms_idx[i]):
                continue
            if pd.isna(dt_idx[i]):
                before_flags[i] = False
                continue
            msi = int(ms_idx[i])
            dti = int(dt_idx[i])
            before_flags[i] = (dti < msi)
            if before_flags[i]:
                lead_vals.append(msi - dti)

        detected_before_rate = float(np.mean(before_flags))
        missing_detection = denom - int(g.loc[g[det_col].notna(), id_col].nunique())

        if lead_vals:
            arr = np.asarray(lead_vals, dtype=float)
            lead_n = int(len(arr))
            lead_median = float(np.median(arr))
            lead_p25 = float(np.quantile(arr, 0.25))
            lead_p75 = float(np.quantile(arr, 0.75))
        else:
            lead_n = 0
            lead_median = lead_p25 = lead_p75 = None

        rows.append({
            "milestone": milestone,
            "denom_milestone_observed": denom,
            "detected_rate": detected_rate,
            "detected_before_rate": detected_before_rate,
            "lead_n": lead_n,
            "lead_median": lead_median,
            "lead_p25": lead_p25,
            "lead_p75": lead_p75,
            "missing_detection": missing_detection,
        })

    return pd.DataFrame(rows).sort_values("milestone")

def eval_at_setting(
    *,
    ben: Dict[str, List[str]],
    mal: Dict[str, List[str]],
    meta: pd.DataFrame,
    ms_mal_long: pd.DataFrame,
    id_col: str,
    model_ben: TransformerLM, vocab_ben: Dict[str, int],
    model_mal: TransformerLM, vocab_mal: Dict[str, int],
    cfg: Cfg,
    tau_01: float,
    tau_1: float,
    tau_5: float,
    tau_10: float,
    p_del: float,
    mode: str,
    mean_burst: int,
    seed: int,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    ben_scores = []
    ben_rdel = []
    ben_empty = 0

    for tid in sorted(ben.keys()):
        toks_c, rdel = corrupt_with_trace_seed(
            ben[tid], p_del=p_del, mode=mode, mean_burst=mean_burst, base_seed=seed, trace_id=tid
        )
        ben_rdel.append(rdel)
        if len(toks_c) == 0:
            ben_empty += 1
        s = max_prefix_lr(model_mal, vocab_mal, model_ben, vocab_ben, toks_c, cfg)
        ben_scores.append((tid, s))
    ben_df = pd.DataFrame(ben_scores, columns=[id_col, "score"]).merge(meta, on=id_col, how="left")

    mal_scores = []
    mal_rdel = []
    mal_empty = 0
    det_rows = []

    for tid in sorted(mal.keys()):
        toks_c, rdel = corrupt_with_trace_seed(
            mal[tid], p_del=p_del, mode=mode, mean_burst=mean_burst, base_seed=seed, trace_id=tid
        )
        mal_rdel.append(rdel)
        if len(toks_c) == 0:
            mal_empty += 1

        series = prefix_lr_series(model_mal, vocab_mal, model_ben, vocab_ben, toks_c, cfg)
        mx = max(series) if series else float("-inf")
        d01 = first_crossing(series, tau_01)
        d1  = first_crossing(series, tau_1)
        d5  = first_crossing(series, tau_5)
        d10  = first_crossing(series, tau_10)

        mal_scores.append((tid, mx))
        det_rows.append((tid, d01, d1, d5, d10))

    mal_df = pd.DataFrame(mal_scores, columns=[id_col, "score"]).merge(meta, on=id_col, how="left")
    det = pd.DataFrame(det_rows, columns=[id_col, "det_idx_tau_0_1", "det_idx_tau_1_0", "det_idx_tau_5_0", "det_idx_tau_10_0"])

    ben_del_mean = float(np.mean(ben_rdel)) if ben_rdel else float("nan")
    mal_del_mean = float(np.mean(mal_rdel)) if mal_rdel else float("nan")

    out_rows = []
    for tag, tau in [("tau_0_1", tau_01), ("tau_1_0", tau_1), ("tau_5_0", tau_5), ("tau_10_0", tau_10)]:
        fpr = float(np.mean(ben_df["score"].values >= tau))
        tpr = float(np.mean(mal_df["score"].values >= tau))
        out_rows.append({
            "mode": mode,
            "p_del_target": float(p_del),
            "p_del_realized_ben_mean": ben_del_mean,
            "p_del_realized_mal_mean": mal_del_mean,
            "empty_frac_ben": float(ben_empty / max(1, len(ben_df))),
            "empty_frac_mal": float(mal_empty / max(1, len(mal_df))),
            "seed": int(seed),
            "tau": tag,
            "threshold": float(tau),
            "FPR_test": fpr,
            "TPR_test": tpr,
            "ben_test_n": int(len(ben_df)),
            "mal_test_n": int(len(mal_df)),
        })
    overall = pd.DataFrame(out_rows)

    fam_rows = []
    if "family" in mal_df.columns and mal_df["family"].notna().any():
        for fam, g in mal_df.groupby("family"):
            for tag, tau in [("tau_0.1", tau_01), ("tau_1.0", tau_1), ("tau_5.0", tau_5), ("tau_10.0", tau_10)]:
                tpr = float(np.mean(g["score"].values >= tau))
                fam_rows.append({
                    "mode": mode,
                    "p_del_target": float(p_del),
                    "seed": int(seed),
                    "tau": tag,
                    "family": fam,
                    "n": int(len(g)),
                    "TPR": tpr,
                })
    byfam = pd.DataFrame(fam_rows)

    early_rows = []
    for det_col, tag in [("det_idx_tau_0_1", "tau_0_1"), ("det_idx_tau_1_0", "tau_1_0"), ("det_idx_tau_5_0", "tau_5_0"), ("det_idx_tau_10_0", "tau_10_0")]:
        tbl = early_table_from_det_and_ms(det, ms_mal_long, id_col=id_col, det_col=det_col)
        tbl.insert(0, "tau", tag)
        tbl.insert(0, "seed", int(seed))
        tbl.insert(0, "p_del_target", float(p_del))
        tbl.insert(0, "mode", mode)
        early_rows.append(tbl)
    early_df = pd.concat(early_rows, ignore_index=True)

    return overall, byfam, early_df

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--processed_dir", type=str, default=None,
                    help="processed_{timestamp} directory. If omitted, picks newest processed_* under REPO_ROOT.")
    ap.add_argument("--mean_burst", type=int, default=20)
    ap.add_argument("--p_grid", type=str, default="0,0.05,0.1,0.2,0.3")
    ap.add_argument("--modes", type=str, default="iid,bursty")
    ap.add_argument("--seeds", type=str, default=None, help="Comma list. Default: SEED,SEED+1,SEED+2")
    args = ap.parse_args()
    print("HERE")
    processed_dir = resolve_processed_dir(args.processed_dir)
    thr = load_thresholds(processed_dir)
    print("Using processed dir:", processed_dir)
    print("DEVICE:", DEVICE)

    if "cfg" in thr and isinstance(thr["cfg"], dict):
        for k, v in thr["cfg"].items():
            if hasattr(cfg, k):
                setattr(cfg, k, v)

    splits = json.loads((processed_dir / "splits.json").read_text(encoding="utf-8"))
    id_col = thr.get("id_col", splits.get("id_col", "trace_id_content"))
    if not isinstance(id_col, str) or not id_col:
        id_col = "trace_id_content"

    if "tau_0_1" not in thr or "tau_1_0" not in thr:
        raise KeyError("tx_thresholds.json missing required discrete keys: tau_0_1 and tau_1_0")
    tau_01 = float(thr["tau_0_1"])
    tau_1  = float(thr["tau_1_0"])
    tau_5  = float(thr["tau_5_0"])
    tau_10  = float(thr["tau_10_0"])
    print(f"Loaded thresholds: tau_0_1={tau_01} tau_1_0={tau_1} tau_5_0={tau_5} tau_10_0={tau_10}")

    ben_test_ids = set(map(str, splits["benign"]["test"]))
    mal_test_ids = set(map(str, splits["malware"]["test"]))
    eval_ids = ben_test_ids | mal_test_ids

    print("Loading models...")
    model_ben, vocab_ben = load_model(processed_dir / "tx_models" / "benign", cfg)
    model_mal, vocab_mal = load_model(processed_dir / "tx_models" / "malware", cfg)
    if vocab_ben != vocab_mal:
        raise AssertionError("TX vocabs differ (ben vs mal). Retrain with shared vocab.")

    print("Loading sequences...")
    ben_test = load_sequences_only(processed_dir, ben_test_ids, id_col=id_col)
    mal_test = load_sequences_only(processed_dir, mal_test_ids, id_col=id_col)

    print("Loading meta...")
    meta = load_meta(processed_dir, eval_ids, id_col=id_col).drop_duplicates(id_col)

    print("Loading milestones...")
    ms = load_milestones_long(processed_dir, id_col=id_col)
    ms_mal_long = ms[ms[id_col].isin(mal_test_ids)].copy()

    p_grid = [float(x.strip()) for x in args.p_grid.split(",") if x.strip() != ""]
    modes = [m.strip() for m in args.modes.split(",") if m.strip() != ""]
    mean_burst = int(args.mean_burst)
    if args.seeds:
        seeds = [int(x.strip()) for x in args.seeds.split(",") if x.strip() != ""]
    else:
        seeds = [SEED, SEED + 1, SEED + 2]

    print(f"modes={modes} | p_grid={p_grid} | mean_burst={mean_burst} | seeds={seeds}")

    all_overall = []
    all_byfam = []
    all_early = []

    for mode in modes:
        for p_del in p_grid:
            for s in seeds:
                print(f"Scoring mode={mode} p_del={p_del:.2f} seed={s} ...")
                overall, byfam, early_df = eval_at_setting(
                    ben=ben_test,
                    mal=mal_test,
                    meta=meta,
                    ms_mal_long=ms_mal_long,
                    id_col=id_col,
                    model_ben=model_ben, vocab_ben=vocab_ben,
                    model_mal=model_mal, vocab_mal=vocab_mal,
                    cfg=cfg,
                    tau_01=tau_01, 
                    tau_1=tau_1,
                    tau_5=tau_5,
                    tau_10=tau_10,
                    p_del=p_del,
                    mode=mode,
                    mean_burst=mean_burst,
                    seed=s,
                )
                all_overall.append(overall)
                all_early.append(early_df)
                if not byfam.empty:
                    all_byfam.append(byfam)

    overall_df = pd.concat(all_overall, ignore_index=True)
    out_fp = processed_dir / "fig3_robustness_tx.csv"
    overall_df.to_csv(out_fp, index=False)

    if all_byfam:
        byfam_df = pd.concat(all_byfam, ignore_index=True)
        out_fp2 = processed_dir / "fig3_robustness_tx_by_family.csv"
        byfam_df.to_csv(out_fp2, index=False)
    else:
        byfam_df = pd.DataFrame()

    early_all = pd.concat(all_early, ignore_index=True)
    out_fp3 = processed_dir / "fig3_robustness_tx_early.csv"
    early_all.to_csv(out_fp3, index=False)

    print("\n=== Robustness summary (mean across seeds): TPR/FPR ===")
    summ = (
        overall_df
        .groupby(["mode", "p_del_target", "tau"], as_index=False)
        .agg(
            TPR_mean=("TPR_test", "mean"),
            TPR_std=("TPR_test", "std"),
            FPR_mean=("FPR_test", "mean"),
            FPR_std=("FPR_test", "std"),
            ben_del_mean=("p_del_realized_ben_mean", "mean"),
            mal_del_mean=("p_del_realized_mal_mean", "mean"),
            empty_ben_mean=("empty_frac_ben", "mean"),
            empty_mal_mean=("empty_frac_mal", "mean"),
        )
    )
    print(summ.to_string(index=False))

    print("\n=== Robustness summary (mean across seeds): EARLY ===")
    summ_e = (
        early_all
        .groupby(["mode", "p_del_target", "tau", "milestone"], as_index=False)
        .agg(
            denom=("denom_milestone_observed", "mean"),
            detected_rate_mean=("detected_rate", "mean"),
            detected_rate_std=("detected_rate", "std"),
            detected_before_rate_mean=("detected_before_rate", "mean"),
            detected_before_rate_std=("detected_before_rate", "std"),
            lead_median_mean=("lead_median", "mean"),
        )
    )
    print(summ_e.to_string(index=False))

    print("\nSaved:")
    print(f" - {out_fp}")
    if not byfam_df.empty:
        print(f" - {out_fp2}")
    print(f" - {out_fp3}")

if __name__ == "__main__":
    main()
