from __future__ import annotations

import argparse
import json
import pickle
from pathlib import Path
from typing import Dict, List
import math
import numpy as np
import pandas as pd
from dataclasses import dataclass

from constants import REPO_ROOT

@dataclass
class NgramLM:
    order: int
    k: float
    vocab: Dict[str, int]
    unk_id: int
    bos_id: int
    counts: List[Dict[Tuple[int, ...], Counter]]
    context_totals: List[Dict[Tuple[int, ...], int]]

    def logprob_next(self, history: List[int], token_id: int) -> float:
        V = len(self.vocab)
        max_h = self.order - 1
        h = history[-max_h:] if max_h > 0 else []

        for n in range(self.order, 0, -1):
            ctx_len = n - 1
            ctx = tuple(h[-ctx_len:]) if ctx_len > 0 else tuple()

            dist = self.counts[n].get(ctx)
            total = self.context_totals[n].get(ctx, 0)

            if total > 0 and dist is not None:
                c_hw = dist.get(token_id, 0)
                p = (c_hw + self.k) / (total + self.k * V)
                return math.log(p)

        return -math.log(V)

    def logprob_prefixes(self, tokens: List[int]) -> List[float]:
        hist = [self.bos_id]
        cum = 0.0
        out = []
        for tid in tokens:
            lp = self.logprob_next(hist, tid)
            cum += lp
            out.append(cum)
            hist.append(tid)
        return out


def pick_latest_processed_dir() -> Path:
    root = Path(REPO_ROOT)
    cands = [p for p in root.glob("processed_*") if p.is_dir()]
    return max(cands, key=lambda p: p.stat().st_mtime)


def load_sequences(processed_dir: Path, ids: set[str], id_col: str) -> Dict[str, List[str]]:
    remaining = set(map(str, ids))
    out = {}
    for fp in sorted(processed_dir.glob("traces_batch_*.parquet")):
        if not remaining:
            break
        df = pd.read_parquet(fp, columns=[id_col, "tokens"])
        df[id_col] = df[id_col].astype(str)
        sub = df[df[id_col].isin(remaining)]
        for tid, toks in zip(sub[id_col], sub["tokens"]):
            out[str(tid)] = list(toks)
        remaining -= set(sub[id_col])
    return out


def roc_auc(y_true: np.ndarray, scores: np.ndarray) -> float:
    y_true = np.asarray(y_true, int)
    scores = np.asarray(scores, float)
    n_pos = np.sum(y_true == 1)
    n_neg = np.sum(y_true == 0)

    ranks = pd.Series(scores).rank(method="average").to_numpy()
    sum_ranks_pos = np.sum(ranks[y_true == 1])
    return (sum_ranks_pos - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg)


def prefix_lr_series(lm_mal, lm_ben, toks: List[str]):
    if len(toks) == 0:
        return []
    mal_ids = [lm_mal.vocab.get(t, lm_mal.unk_id) for t in toks]
    ben_ids = [lm_ben.vocab.get(t, lm_ben.unk_id) for t in toks]
    mal_lp = lm_mal.logprob_prefixes(mal_ids)
    ben_lp = lm_ben.logprob_prefixes(ben_ids)
    L = min(len(mal_lp), len(ben_lp))
    return [mal_lp[i] - ben_lp[i] for i in range(L)]


def max_cum_lr(lm_mal, lm_ben, toks: List[str]):
    s = prefix_lr_series(lm_mal, lm_ben, toks)
    return max(s) if s else float("-inf")


def max_avg_lr(lm_mal, lm_ben, toks: List[str]):
    s = prefix_lr_series(lm_mal, lm_ben, toks)
    if not s:
        return float("-inf")
    return max(s[i] / (i + 1) for i in range(len(s)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--processed_dir", type=str, default=None)
    parser.add_argument("--cuts", type=str, default="0,10,25,50,100,200")
    args = parser.parse_args()

    processed_dir = Path(args.processed_dir) if args.processed_dir else pick_latest_processed_dir()
    print("Using:", processed_dir)

    cuts = sorted(set(int(x.strip()) for x in args.cuts.split(",")))

    splits = json.loads((processed_dir / "splits.json").read_text())
    id_col = splits.get("id_col", "trace_id_content")

    ben_ids = set(splits["benign"]["test"])
    mal_ids = set(splits["malware"]["test"])

    print("Loading sequences...")
    ben = load_sequences(processed_dir, ben_ids, id_col)
    mal = load_sequences(processed_dir, mal_ids, id_col)

    with open(processed_dir / "ngram_models.pkl", "rb") as f:
        obj = pickle.load(f)
    lm_ben = obj["lm_ben"]
    lm_mal = obj["lm_mal"]

    ben_list = list(ben.values())
    mal_list = list(mal.values())

    y = np.concatenate([np.zeros(len(ben_list)), np.ones(len(mal_list))])

    print("\n=== PREFIX CUT EXPERIMENT ===")
    print("cut\tAUC(max_cum)\tAUC(max_avg)")

    for cut in cuts:
        ben_cut = [toks[cut:] if len(toks) > cut else [] for toks in ben_list]
        mal_cut = [toks[cut:] if len(toks) > cut else [] for toks in mal_list]

        ben_sc = np.array([max_cum_lr(lm_mal, lm_ben, toks) for toks in ben_cut])
        mal_sc = np.array([max_cum_lr(lm_mal, lm_ben, toks) for toks in mal_cut])
        auc_cum = roc_auc(y, np.concatenate([ben_sc, mal_sc]))

        ben_sa = np.array([max_avg_lr(lm_mal, lm_ben, toks) for toks in ben_cut])
        mal_sa = np.array([max_avg_lr(lm_mal, lm_ben, toks) for toks in mal_cut])
        auc_avg = roc_auc(y, np.concatenate([ben_sa, mal_sa]))

        print(f"{cut}\t{auc_cum:.6f}\t{auc_avg:.6f}")


if __name__ == "__main__":
    main()
