import json, math, random, argparse
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import torch
import torch.nn as nn

from constants import REPO_ROOT

SEED = 1337
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed_all(SEED)

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

@dataclass
class Cfg:
    pad: str = "<PAD>"
    bos: str = "<BOS>"
    unk: str = "<UNK>"

    d_model: int = 256
    n_heads: int = 8
    n_layers: int = 4
    d_ff: int = 1024
    dropout: float = 0.1
    max_pos: int = 50000

    score_context: int = 512
    score_stride: int = 512

cfg = Cfg()


class TransformerLM(nn.Module):
    def __init__(self, vocab_size: int, d_model: int, n_heads: int, n_layers: int, d_ff: int, dropout: float, max_pos: int, pad_id: int = 0):
        super().__init__()
        self.pad_id = pad_id
        self.tok = nn.Embedding(vocab_size, d_model, padding_idx=pad_id)
        self.pos = nn.Embedding(max_pos, d_model)
        enc_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=d_ff,
            dropout=dropout,
            batch_first=True,
            activation="gelu",
        )
        self.enc = nn.TransformerEncoder(enc_layer, num_layers=n_layers)
        self.ln = nn.LayerNorm(d_model)
        self.head = nn.Linear(d_model, vocab_size, bias=False)

    def forward(self, x: torch.Tensor, key_padding_mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        B, T = x.shape
        if T > self.pos.num_embeddings:
            raise ValueError(f"T={T} exceeds max_pos={self.pos.num_embeddings}")
        pos = torch.arange(T, device=x.device).unsqueeze(0).expand(B, T)
        h = self.tok(x) + self.pos(pos)
        causal = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), diagonal=1)
        h = self.enc(h, mask=causal, src_key_padding_mask=key_padding_mask)
        h = self.ln(h)
        return self.head(h)


def pick_latest_processed_dir() -> Path:
    root = Path(REPO_ROOT)
    cands = [p for p in root.glob("processed_*") if p.is_dir()]
    if not cands:
        raise FileNotFoundError(f"No processed_* dirs under {root}")
    return max(cands, key=lambda p: p.stat().st_mtime)


def load_model(dirpath: Path, cfg: Cfg) -> Tuple[TransformerLM, Dict[str, int]]:
    with open(dirpath / "vocab.json", "r", encoding="utf-8") as f:
        vocab = json.load(f)
    ck = torch.load(dirpath / "best.pt", map_location=DEVICE)
    pad_id = int(ck.get("pad_id", vocab.get(getattr(cfg, "pad", "<PAD>"), 0)))

    model = TransformerLM(
        vocab_size=len(vocab),
        d_model=cfg.d_model,
        n_heads=cfg.n_heads,
        n_layers=cfg.n_layers,
        d_ff=cfg.d_ff,
        dropout=cfg.dropout,
        max_pos=cfg.max_pos,
        pad_id=pad_id,
    ).to(DEVICE)
    model.load_state_dict(ck["model"])
    model.eval()
    return model, vocab


def iter_parquet_files(dirpath: Path, pattern: str):
    files = sorted(dirpath.glob(pattern))
    if not files:
        raise FileNotFoundError(f"No parquet files found in {dirpath} matching {pattern}")
    for fp in files:
        yield fp


def load_sequences_only(processed_dir: Path, ids: set[str], *, id_col: str) -> Dict[str, List[str]]:
    remaining = set(ids)
    out: Dict[str, List[str]] = {}
    for fp in iter_parquet_files(processed_dir, "traces_batch_*.parquet"):
        if not remaining:
            break
        df = pd.read_parquet(fp, columns=[id_col, "tokens"])
        sub = df[df[id_col].isin(remaining)]
        if sub.empty:
            continue
        for tid, toks in zip(sub[id_col].tolist(), sub["tokens"].tolist()):
            out[tid] = toks
        remaining.difference_update(sub[id_col].tolist())
    if remaining:
        print(f"[WARN] missing {len(remaining)} ids in trace batches.")
    return out


def load_meta(processed_dir: Path, ids: set[str], *, id_col: str) -> pd.DataFrame:
    remaining = set(ids)
    parts = []
    cols = [id_col, "label", "family", "source"]
    for fp in iter_parquet_files(processed_dir, "traces_batch_*.parquet"):
        if not remaining:
            break
        df = pd.read_parquet(fp, columns=cols)
        sub = df[df[id_col].isin(remaining)]
        if sub.empty:
            continue
        parts.append(sub)
        remaining.difference_update(sub[id_col].tolist())
    if parts:
        return pd.concat(parts, ignore_index=True).drop_duplicates(id_col)
    return pd.DataFrame({id_col: list(ids), "label": None, "family": None, "source": None})


@torch.no_grad()
def logprob_prefixes_tx_contextcarry(
    model: TransformerLM,
    vocab: Dict[str, int],
    seq_tokens: List[str],
    *,
    context: int,
    stride: int,
    bos: str,
    unk: str,
) -> List[float]:
    """
    Returns cumulative log-probs for each token in seq_tokens (length N).
    Output length == len(seq_tokens). Index i corresponds to prefix ending at token i.
    """
    model.eval()
    bos_id = vocab[bos]
    unk_id = vocab[unk]

    ids = [bos_id] + [vocab.get(t, unk_id) for t in seq_tokens]
    N = len(seq_tokens)
    if N == 0:
        return []

    cum = 0.0
    out: List[float] = []

    t = 1
    while t <= N:
        t_end = min(N + 1, t + stride)
        a = max(0, t - context - 1)
        b = t_end

        x_ids = ids[a:b]
        y_ids = ids[a+1:b+1]
        L = min(len(x_ids), len(y_ids))
        x_ids = x_ids[:L]
        y_ids = y_ids[:L]

        x = torch.tensor([x_ids], dtype=torch.long, device=DEVICE)
        y = torch.tensor([y_ids], dtype=torch.long, device=DEVICE)

        logits = model(x)
        logp = torch.log_softmax(logits, dim=-1)
        tgt_lp = logp.gather(-1, y.unsqueeze(-1)).squeeze(-1).squeeze(0)

        for p in range(t, t_end):
            wi = p - (a + 1)
            if 0 <= wi < tgt_lp.numel():
                cum += float(tgt_lp[wi].item())
                out.append(cum)

        t = t_end

    if len(out) != N:
        raise AssertionError(f"Scoring produced len(out)={len(out)} != N={N}")
    return out


def prefix_lr_series(
    model_mal: TransformerLM,
    vocab_mal: Dict[str, int],
    model_ben: TransformerLM,
    vocab_ben: Dict[str, int],
    seq_tokens: List[str],
    cfg: Cfg,
) -> List[float]:
    mal_lp = logprob_prefixes_tx_contextcarry(
        model_mal, vocab_mal, seq_tokens,
        context=cfg.score_context, stride=cfg.score_stride,
        bos=cfg.bos, unk=cfg.unk,
    )
    ben_lp = logprob_prefixes_tx_contextcarry(
        model_ben, vocab_ben, seq_tokens,
        context=cfg.score_context, stride=cfg.score_stride,
        bos=cfg.bos, unk=cfg.unk,
    )
    L = min(len(mal_lp), len(ben_lp))
    return [mal_lp[i] - ben_lp[i] for i in range(L)]


def max_prefix_lr(*args, **kwargs) -> float:
    s = prefix_lr_series(*args, **kwargs)
    return max(s) if s else float("-inf")


def first_crossing(prefix_series: List[float], tau: float) -> Optional[int]:
    for i, v in enumerate(prefix_series):
        if v >= tau:
            return i
    return None


def load_milestones_long(processed_dir: Path, *, id_col: str) -> pd.DataFrame:
    """
    Returns: [id_col, milestone, milestone_idx] with earliest milestone per (id_col,milestone).
    Supports wide (t_dns,...) or long schemas.
    """
    batch_files = sorted(processed_dir.glob("milestones_batch_*.parquet"))
    single_file = processed_dir / "milestones.parquet"

    if batch_files:
        ms = pd.concat((pd.read_parquet(fp) for fp in batch_files), ignore_index=True)
    elif single_file.exists():
        ms = pd.read_parquet(single_file)
    else:
        raise FileNotFoundError(f"Missing milestones in {processed_dir} (milestones_batch_*.parquet).")

    if id_col not in ms.columns:
        if "trace_id" in ms.columns and id_col != "trace_id":
            ms = ms.rename(columns={"trace_id": id_col})
        else:
            raise ValueError(f"Milestones must contain id column: {id_col}")

    if "milestone" in ms.columns:
        idx_col = None
        for c in ["milestone_idx", "event_idx", "token_idx", "idx", "pos", "t_idx"]:
            if c in ms.columns:
                idx_col = c
                break
        if idx_col is None:
            raise ValueError("Long milestones schema but no index column found.")
        out = ms[[id_col, "milestone", idx_col]].rename(columns={idx_col: "milestone_idx"}).copy()
        out["milestone_idx"] = pd.to_numeric(out["milestone_idx"], errors="coerce").astype("Int64")
    else:
        wide_map = {"t_dns": "DNS", "t_c2": "C2", "t_pers": "Persistence", "t_priv": "PrivEsc"}
        present = [c for c in wide_map if c in ms.columns]
        if not present:
            raise ValueError("Milestones schema not recognized.")
        parts = []
        for col in present:
            tmp = ms[[id_col, col]].copy()
            tmp = tmp.rename(columns={col: "milestone_idx"})
            tmp["milestone"] = wide_map[col]
            parts.append(tmp)
        out = pd.concat(parts, ignore_index=True)
        out["milestone_idx"] = pd.to_numeric(out["milestone_idx"], errors="coerce").astype("Int64")

    out = out.dropna(subset=["milestone_idx"]).copy()
    out = out.sort_values([id_col, "milestone", "milestone_idx"])
    out = out.groupby([id_col, "milestone"], as_index=False).first()
    return out[[id_col, "milestone", "milestone_idx"]]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--processed_dir", type=str, default=None,
                    help="processed_{timestamp} directory (recommended). If omitted, picks newest processed_*.")
    ap.add_argument("--inclusive", action="store_true",
                    help="Count detection at same index as milestone as 'before' (det_idx <= milestone_idx). Default strict.")
    args = ap.parse_args()

    processed_dir = Path(args.processed_dir) if args.processed_dir else pick_latest_processed_dir()
    print("Using processed dir:", processed_dir)
    print("DEVICE:", DEVICE)

    splits_path = processed_dir / "splits.json"
    thr_path = processed_dir / "tx_thresholds.json"    
    if not splits_path.exists():
        raise FileNotFoundError(f"Missing {splits_path}")
    if not thr_path.exists():
        raise FileNotFoundError(f"Missing {thr_path} (run transformer training/thresholding first)")

    splits = json.loads(splits_path.read_text(encoding="utf-8"))
    thr = json.loads(thr_path.read_text(encoding="utf-8"))

    id_col = thr.get("id_col", splits.get("id_col", "trace_id_content"))

    if "cfg" in thr:
        for k, v in thr["cfg"].items():
            if hasattr(cfg, k):
                setattr(cfg, k, v)

    need = ["tau_0_1", "tau_1_0", "tau_5_0", "tau_10_0"]
    missing = [k for k in need if k not in thr]
    if missing:
        raise KeyError(f"{thr_path} missing required discrete keys: {missing}")

    tau_01 = float(thr["tau_0_1"])
    tau_1  = float(thr["tau_1_0"])
    tau_5  = float(thr["tau_5_0"])
    tau_10  = float(thr["tau_10_0"])


    ben_test_ids = set(splits["benign"]["test"])
    mal_test_ids = set(splits["malware"]["test"])
    eval_ids = ben_test_ids | mal_test_ids

    print("Loading models...")
    model_ben, vocab_ben = load_model(processed_dir / "tx_models" / "benign", cfg)
    model_mal, vocab_mal = load_model(processed_dir / "tx_models" / "malware", cfg)

    if vocab_ben != vocab_mal:
        raise AssertionError(
            "Benign and malware Transformer vocabs differ. "
            "Retrain with a shared vocab built on (ben_train ∪ mal_train)."
        )

    print("Loading sequences...")
    ben_test = load_sequences_only(processed_dir, ben_test_ids, id_col=id_col)
    mal_test = load_sequences_only(processed_dir, mal_test_ids, id_col=id_col)

    print("Loading meta...")
    meta = load_meta(processed_dir, eval_ids, id_col=id_col)

    def compute_max_scores(id_to_tokens: Dict[str, List[str]]) -> pd.DataFrame:
        rows = []
        for tid, toks in id_to_tokens.items():
            mx = max_prefix_lr(model_mal, vocab_mal, model_ben, vocab_ben, toks, cfg)
            rows.append((tid, mx))
        return pd.DataFrame(rows, columns=[id_col, "max_prefix_lr"])

    print("Scoring benign test...")
    ben_scores = compute_max_scores(ben_test).merge(meta, on=id_col, how="left")
    print("Scoring malware test...")
    mal_scores = compute_max_scores(mal_test).merge(meta, on=id_col, how="left")

    def summarize_at_tau(tau: float) -> Dict[str, float]:
        fpr = float(np.mean(ben_scores["max_prefix_lr"].values >= tau))
        tpr = float(np.mean(mal_scores["max_prefix_lr"].values >= tau))
        return {"threshold": float(tau), "FPR_test": fpr, "TPR_test": tpr}

    fig1 = pd.DataFrame([
        {"tau": "0.1% discrete", **summarize_at_tau(tau_01), "ben_test_n": len(ben_scores), "mal_test_n": len(mal_scores)},
        {"tau": "1% discrete",   **summarize_at_tau(tau_1),  "ben_test_n": len(ben_scores), "mal_test_n": len(mal_scores)},
        {"tau": "5% discrete",   **summarize_at_tau(tau_5),  "ben_test_n": len(ben_scores), "mal_test_n": len(mal_scores)},
        {"tau": "10% discrete",   **summarize_at_tau(tau_10),  "ben_test_n": len(ben_scores), "mal_test_n": len(mal_scores)},
    ])[["tau", "threshold", "FPR_test", "TPR_test", "ben_test_n", "mal_test_n"]]


    print("\nFigure 1 (overall):")
    print(fig1.to_string(index=False))
    fig1.to_csv(processed_dir / "fig1_tpr_fpr_tx.csv", index=False)

    if "family" in mal_scores.columns and mal_scores["family"].notna().any():
        fam_rows = []
        for fam, g in mal_scores.groupby("family"):
            fam_rows.append({
                "family": fam,
                "n": int(len(g)),
                "TPR@tau_0_1": float(np.mean(g["max_prefix_lr"].values >= tau_01)),
                "TPR@tau_1_0": float(np.mean(g["max_prefix_lr"].values >= tau_1)),
                "TPR@tau_5_0": float(np.mean(g["max_prefix_lr"].values >= tau_5)),
                "TPR@tau_10_0": float(np.mean(g["max_prefix_lr"].values >= tau_10)),
            })
        fig1_fam = pd.DataFrame(fam_rows).sort_values("family")
        print("\nFigure 1 (by family):")
        print(fig1_fam.to_string(index=False))
        fig1_fam.to_csv(processed_dir / "fig1_tpr_by_family_tx.csv", index=False)
    else:
        print("\nFigure 1 (by family): family labels not found; skipping.")

    print("\nLoading milestones...")
    ms = load_milestones_long(processed_dir, id_col=id_col)
    ms = ms[ms[id_col].isin(mal_test_ids)].copy()

    print("Computing detection indices for malware test...")
    det_rows = []
    for tid, toks in mal_test.items():
        series = prefix_lr_series(model_mal, vocab_mal, model_ben, vocab_ben, toks, cfg)
        d01 = first_crossing(series, tau_01)
        d1  = first_crossing(series, tau_1)
        d5  = first_crossing(series, tau_5)
        d10  = first_crossing(series, tau_10)
        det_rows.append((tid, d01, d1, d5, d10))
        det = pd.DataFrame(det_rows, columns=[id_col, "det_idx_tau_0_1", "det_idx_tau_1_0", "det_idx_tau_5_0", "det_idx_tau_10_0"])

    det = pd.DataFrame(det_rows, columns=[id_col, "det_idx_tau_0_1", "det_idx_tau_1_0", "det_idx_tau_5_0", "det_idx_tau_10_0"])

    ms_mal = ms.merge(det, on=id_col, how="left")

    def early_table(det_col: str) -> pd.DataFrame:
        """
        Milestone-relative stats (match ngram robustness semantics):
        - Denominator: traces where milestone exists
        - detected_rate: P(det exists | milestone observed)
        - detected_before_rate: P(det < milestone_idx | milestone observed) (or <= if inclusive)
        - lead stats: among traces with milestone observed AND detection exists
        """
        out_rows = []
        for milestone, g in ms_mal.groupby("milestone"):
            denom = int(g[id_col].nunique())
            if denom == 0:
                out_rows.append({
                    "milestone": milestone,
                    "denom_milestone_observed": 0,
                    "detected_rate": None,
                    "detected_before_rate": None,
                    "lead_n": 0,
                    "lead_median": None,
                    "lead_p25": None,
                    "lead_p75": None,
                    "missing_detection": 0,
                })
                continue

            has_det = g[det_col].notna().to_numpy()
            detected_rate = float(np.mean(has_det))

            ms_idx = g["milestone_idx"].astype("Int64").to_numpy()
            dt_idx = g[det_col].astype("Int64").to_numpy()

            before_flags = np.zeros(len(g), dtype=bool)
            lead_vals = []

            for i in range(len(g)):
                if pd.isna(ms_idx[i]):
                    continue
                if pd.isna(dt_idx[i]):
                    before_flags[i] = False
                    continue
                msi = int(ms_idx[i])
                dti = int(dt_idx[i])
                if args.inclusive:
                    before_flags[i] = (dti <= msi)
                else:
                    before_flags[i] = (dti < msi)
                lead_vals.append(msi - dti)

            detected_before_rate = float(np.mean(before_flags))
            missing_detection = denom - int(g.loc[g[det_col].notna(), id_col].nunique())

            if lead_vals:
                arr = np.asarray(lead_vals, dtype=float)
                lead_n = int(len(arr))
                lead_median = float(np.median(arr))
                lead_p25 = float(np.quantile(arr, 0.25))
                lead_p75 = float(np.quantile(arr, 0.75))
            else:
                lead_n = 0
                lead_median = lead_p25 = lead_p75 = None

            out_rows.append({
                "milestone": milestone,
                "denom_milestone_observed": denom,
                "detected_rate": detected_rate,
                "detected_before_rate": detected_before_rate,
                "lead_n": lead_n,
                "lead_median": lead_median,
                "lead_p25": lead_p25,
                "lead_p75": lead_p75,
                "missing_detection": missing_detection,
            })

        return pd.DataFrame(out_rows).sort_values("milestone")



    fig2_01 = early_table("det_idx_tau_0_1")
    fig2_1  = early_table("det_idx_tau_1_0")
    fig2_5  = early_table("det_idx_tau_5_0")
    fig2_10  = early_table("det_idx_tau_10_0")


    print("\nFigure 2 (early detection @ tau_0.1):")
    print(fig2_01.to_string(index=False))
    print("\nFigure 2 (early detection @ tau_1.0):")
    print(fig2_1.to_string(index=False))
    print("\nFigure 2 (early detection @ tau_5.0):")
    print(fig2_5.to_string(index=False))
    print("\nFigure 2 (early detection @ tau_10.0):")
    print(fig2_10.to_string(index=False))


    fig2_01.to_csv(processed_dir / "fig2_early_0.1_tx.csv", index=False)
    fig2_1.to_csv(processed_dir / "fig2_early_1.0_tx.csv", index=False)
    fig2_5.to_csv(processed_dir / "fig2_early_5.0_tx.csv", index=False)
    fig2_10.to_csv(processed_dir / "fig2_early_10.0_tx.csv", index=False)

    print("\nSaved CSVs in:", processed_dir)


if __name__ == "__main__":
    main()
