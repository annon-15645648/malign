from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Iterable, Optional
import pyarrow.parquet as pq
import pandas as pd

from constants import REPO_ROOT


DNS_APIS = {
    "DnsQuery_A", "DnsQuery_W", "DnsQueryEx", "getaddrinfo", "GetAddrInfoW",
    "gethostbyname", "GetHostByName"
}
C2_APIS = {
    "connect", "WSAConnect", "InternetConnectW", "InternetConnectA",
    "HttpSendRequestW", "HttpSendRequestA", "WinHttpConnect", "WinHttpSendRequest"
}

PERSIST_SERVICE = {"CreateServiceW", "CreateServiceA"}
REG_WRITE = {"RegSetValueExW", "RegSetValueExA", "RegCreateKeyExW", "RegCreateKeyExA", "NtSetValueKey"}
PROC_CREATE = {"CreateProcessInternalW", "CreateProcessW", "CreateProcessA"}

PRIV_APIS = {
    "AdjustTokenPrivileges", "OpenProcessToken", "DuplicateTokenEx",
    "ImpersonateLoggedOnUser", "CreateProcessWithTokenW", "CreateProcessAsUserW",
    "ShellExecuteExW"
}



def pick_latest_processed_dir() -> Path:
    root = Path(REPO_ROOT)
    cands = [p for p in root.glob("processed_*") if p.is_dir()]
    if not cands:
        raise FileNotFoundError(f"No processed_* dirs under {root}")
    return max(cands, key=lambda p: p.stat().st_mtime)


def iter_batches(processed_dir: Path, glob_pat: str = "traces_batch_*.parquet", *, id_col: str = "trace_id_content"):
    files = sorted(processed_dir.glob(glob_pat))
    if not files:
        raise FileNotFoundError(f"No input batches found in {processed_dir} matching {glob_pat}")

    cols = set(pq.ParquetFile(files[0]).schema.names)

    if id_col not in cols:
         raise KeyError(f"id_col='{id_col}' not found in parquet schema. Available: {sorted(cols)}")
    wanted = [id_col, "tokens", "label", "family", "source"]
    optional = []
    for c in ("trace_id_path", "virtual_path", "sample_name_stem"):
        if c in cols:
            optional.append(c)

    read_cols = wanted + optional

    for fp in files:
        yield fp, pd.read_parquet(fp, columns=read_cols)


def normalize_tokens(tokens: list[str], mode: str) -> list[str]:
    """
    mode:
      - "none": no normalization (exact match)
      - "lower": lower-case tokens
    """
    if mode == "none":
        return tokens
    if mode == "lower":
        return [t.lower() for t in tokens]
    raise ValueError(f"Unknown token normalization mode: {mode}")


def normalize_api_set(api_set: set[str], mode: str) -> set[str]:
    if mode == "none":
        return api_set
    if mode == "lower":
        return {a.lower() for a in api_set}
    raise ValueError(f"Unknown token normalization mode: {mode}")


def first_idx(tokens: list[str], api_set: set[str]) -> Optional[int]:
    for i, t in enumerate(tokens):
        if t in api_set:
            return i
    return None


def persistence_idx_with_sets(
    tokens: list[str],
    persist_service: set[str],
    reg_write: set[str],
    proc_create: set[str],
    window: int = 500,
) -> Optional[int]:
    """Return token index for a Persistence milestone.

    Priority:
      1) direct service-persistence indicators (e.g., CreateService*/OpenSCManager*).
      2) heuristic: registry-write + process-create occurring within +/- `window` tokens.

    Returns None if no persistence evidence is found.
    """

    i_service = first_idx(tokens, persist_service)
    if i_service is not None:
        return i_service

    reg_positions = [i for i, t in enumerate(tokens) if t in reg_write]
    proc_positions = [i for i, t in enumerate(tokens) if t in proc_create]
    if not reg_positions or not proc_positions:
        return None

    reg_positions.sort()
    proc_positions.sort()

    j = 0
    best = None
    for r in reg_positions:
        while j < len(proc_positions) and proc_positions[j] < r - window:
            j += 1
        for k in (j - 1, j):
            if 0 <= k < len(proc_positions):
                pr = proc_positions[k]
                if abs(pr - r) <= window:
                    cand = min(r, pr)
                    if best is None or cand < best:
                        best = cand
        if best == 0:
            break
    return best

def persistence_idx(tokens: list[str], window: int = 500) -> Optional[int]:
    return persistence_idx_with_sets(tokens, PERSIST_SERVICE, REG_WRITE, PROC_CREATE, window=window)


def extract_milestones(tokens: list[str]) -> dict[str, Optional[int]]:
    return {
        "t_dns": first_idx(tokens, DNS_APIS),
        "t_c2": first_idx(tokens, C2_APIS),
        "t_pers": persistence_idx(tokens),
        "t_priv": first_idx(tokens, PRIV_APIS),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--processed_dir",
        type=str,
        default=None,
        help="processed_{timestamp} directory. If omitted, picks newest processed_* under REPO_ROOT.",
    )
    ap.add_argument("--flush_every", type=int, default=1000, help="Write milestones every N traces.")
    ap.add_argument(
        "--id_col",
        type=str,
        default="trace_id_content",
        help="ID column to use (default: trace_id_content).",
    )
    ap.add_argument(
        "--only_malware",
        action="store_true",
        help="If set, compute milestones only for malware-labeled traces.",
    )
    ap.add_argument(
        "--token_norm",
        type=str,
        default="none",
        choices=["none", "lower"],
        help="Token normalization before matching milestone API sets.",
    )
    ap.add_argument(
        "--persist_window",
        type=int,
        default=500,
        help="Window (in event indices) for persistence heuristic REG_WRITE +/- PROC_CREATE.",
    )
    args = ap.parse_args()

    processed_dir = Path(args.processed_dir) if args.processed_dir else pick_latest_processed_dir()
    out_dir = processed_dir
    FLUSH_EVERY = int(args.flush_every)

    print(f"Using processed dir: {processed_dir}")
    print(f"Writing milestones to: {out_dir}")
    print(f"id_col={args.id_col} only_malware={args.only_malware} token_norm={args.token_norm} persist_window={args.persist_window}")

    dns_apis = normalize_api_set(DNS_APIS, args.token_norm)
    c2_apis = normalize_api_set(C2_APIS, args.token_norm)
    persist_service = normalize_api_set(PERSIST_SERVICE, args.token_norm)
    reg_write = normalize_api_set(REG_WRITE, args.token_norm)
    proc_create = normalize_api_set(PROC_CREATE, args.token_norm)
    priv_apis = normalize_api_set(PRIV_APIS, args.token_norm)

    ms_buffer: list[dict] = []
    flush_idx = 0
    done = 0

    manifest = {
        "processed_dir": str(processed_dir),
        "id_col": args.id_col,
        "only_malware": bool(args.only_malware),
        "token_norm": args.token_norm,
        "persist_window": args.persist_window,
        "output_glob": "milestones_batch_*.parquet",
    }
    with open(out_dir / "milestones_manifest.json", "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)

    for fp, df in iter_batches(processed_dir, id_col=args.id_col):
        if args.only_malware:
            df = df[df["label"] == "malware"]
            if df.empty:
                continue

        for r in df.itertuples(index=False):
            toks = normalize_tokens(r.tokens, args.token_norm)
            m = {
                "t_dns": first_idx(toks, dns_apis),
                "t_c2": first_idx(toks, c2_apis),
                "t_pers": persistence_idx_with_sets(toks, persist_service, reg_write, proc_create, window=args.persist_window),
                "t_priv": first_idx(toks, priv_apis),
            }

            row = {
                args.id_col: getattr(r, args.id_col),
                "label": r.label,
                "family": r.family,
                "source": r.source,
                "trace_id": getattr(r, args.id_col),
                **m,
            }

            for opt in ("trace_id_path", "virtual_path", "sample_name_stem"):
                if hasattr(r, opt):
                    row[opt] = getattr(r, opt)

            ms_buffer.append(row)
            done += 1

            if done % FLUSH_EVERY == 0:
                flush_idx += 1
                out_path = out_dir / f"milestones_batch_{flush_idx:06d}.parquet"
                pd.DataFrame(ms_buffer).to_parquet(out_path, index=False)
                ms_buffer.clear()
                print(f"Wrote {out_path} (processed={done})")

    if ms_buffer:
        flush_idx += 1
        out_path = out_dir / f"milestones_batch_{flush_idx:06d}.parquet"
        pd.DataFrame(ms_buffer).to_parquet(out_path, index=False)
        ms_buffer.clear()
        print(f"Wrote {out_path} (processed={done})")

    print("Done.")


if __name__ == "__main__":
    main()
