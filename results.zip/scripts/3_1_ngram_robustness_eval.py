import json, math, pickle, random, hashlib, argparse
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from collections import Counter

import numpy as np
import pandas as pd

from constants import REPO_ROOT

SEED = 1337
random.seed(SEED)
np.random.seed(SEED)

@dataclass
class NgramLM:
    order: int
    k: float
    vocab: Dict[str, int]
    unk_id: int
    bos_id: int
    counts: List[Dict[Tuple[int, ...], Counter]]
    context_totals: List[Dict[Tuple[int, ...], int]]

    def logprob_next(self, history: List[int], token_id: int) -> float:
        V = len(self.vocab)
        max_h = self.order - 1
        h = history[-max_h:] if max_h > 0 else []

        for n in range(self.order, 0, -1):
            ctx_len = n - 1
            ctx = tuple(h[-ctx_len:]) if ctx_len > 0 else tuple()

            dist = self.counts[n].get(ctx)
            total = self.context_totals[n].get(ctx, 0)

            if total > 0 and dist is not None:
                c_hw = dist.get(token_id, 0)
                p = (c_hw + self.k) / (total + self.k * V)
                return math.log(p)

        return -math.log(V)

    def logprob_prefixes(self, tokens: List[int]) -> List[float]:
        hist = [self.bos_id]
        cum = 0.0
        out = []
        for tid in tokens:
            lp = self.logprob_next(hist, tid)
            cum += lp
            out.append(cum)
            hist.append(tid)
        return out


def pick_latest_processed_dir() -> Path:
    root = Path(REPO_ROOT)
    cands = [p for p in root.glob("processed_*") if p.is_dir()]
    if not cands:
        raise FileNotFoundError(f"No processed_* directories under {root}")
    return max(cands, key=lambda p: p.stat().st_mtime)

def resolve_processed_dir(user_arg: Optional[str]) -> Path:
    if user_arg:
        p = Path(user_arg)
        if not p.exists():
            raise FileNotFoundError(f"--processed_dir does not exist: {p}")
        return p
    return pick_latest_processed_dir()

def require_file(p: Path) -> None:
    if not p.exists():
        raise FileNotFoundError(f"Missing required file: {p}")


def iter_trace_batches(processed_dir: Path, glob_pat: str = "traces_batch_*.parquet"):
    files = sorted(processed_dir.glob(glob_pat))
    if not files:
        raise FileNotFoundError(f"No trace batch files found in {processed_dir} matching {glob_pat}")
    for fp in files:
        yield fp

def load_sequences_only(processed_dir: Path, ids: set[str], *, id_col: str) -> Dict[str, List[str]]:
    remaining = set(ids)
    out: Dict[str, List[str]] = {}
    for fp in iter_trace_batches(processed_dir):
        if not remaining:
            break
        df = pd.read_parquet(fp, columns=[id_col, "tokens"])
        sub = df[df[id_col].isin(remaining)]
        if sub.empty:
            continue
        for tid, toks in zip(sub[id_col].tolist(), sub["tokens"].tolist()):
            out[tid] = toks
        remaining.difference_update(sub[id_col].tolist())
    if remaining:
        print(f"[WARN] missing {len(remaining)} ids in trace batches.")
    return out

def load_meta(processed_dir: Path, ids: set[str], *, id_col: str) -> pd.DataFrame:
    remaining = set(ids)
    parts = []
    cols = [id_col, "label", "family", "source"]
    for fp in iter_trace_batches(processed_dir):
        if not remaining:
            break
        df = pd.read_parquet(fp, columns=cols)
        sub = df[df[id_col].isin(remaining)]
        if sub.empty:
            continue
        parts.append(sub[cols])
        remaining.difference_update(sub[id_col].tolist())
    if parts:
        return pd.concat(parts, ignore_index=True).drop_duplicates(id_col)
    return pd.DataFrame({id_col: list(ids), "label": None, "family": None, "source": None})


def load_milestones(processed_dir: Path, *, id_col: str) -> pd.DataFrame:
    """
    Supports:
      - milestones_batch_*.parquet (preferred)
      - milestones.parquet (fallback)

    Accepts either:
      A) long: id_col, milestone, milestone_idx/event_idx/token_idx/...
      B) wide: id_col, t_dns, t_c2, t_pers, t_priv

    Returns a long DF with:
      [id_col, milestone, milestone_idx] (Int64)
    with earliest milestone_idx per (id_col, milestone).
    """
    batch_files = sorted(processed_dir.glob("milestones_batch_*.parquet"))
    single_file = processed_dir / "milestones.parquet"

    if batch_files:
        ms = pd.concat((pd.read_parquet(fp) for fp in batch_files), ignore_index=True)
    elif single_file.exists():
        ms = pd.read_parquet(single_file)
    else:
        raise FileNotFoundError(
            f"Missing milestones. Expected {processed_dir}/milestones_batch_*.parquet or {single_file}"
        )

    if id_col not in ms.columns and "trace_id" in ms.columns and id_col != "trace_id":
        ms = ms.rename(columns={"trace_id": id_col})

    if id_col not in ms.columns:
        raise ValueError(f"Milestones must contain ID column: {id_col}")

    if "milestone" in ms.columns:
        idx_col = None
        for c in ["milestone_idx", "event_idx", "token_idx", "idx", "pos", "t_idx"]:
            if c in ms.columns:
                idx_col = c
                break
        if idx_col is None:
            raise ValueError("Long milestones schema but no index column found.")
        out = ms[[id_col, "milestone", idx_col]].rename(columns={idx_col: "milestone_idx"}).copy()
        out["milestone_idx"] = pd.to_numeric(out["milestone_idx"], errors="coerce").astype("Int64")

    else:
        wide_map = {"t_dns": "DNS", "t_c2": "C2", "t_pers": "Persistence", "t_priv": "PrivEsc"}
        present = [c for c in wide_map if c in ms.columns]
        if not present:
            raise ValueError("Milestones schema not recognized (expected long or wide columns).")

        parts = []
        for col in present:
            tmp = ms[[id_col, col]].copy()
            tmp = tmp.rename(columns={col: "milestone_idx"})
            tmp["milestone"] = wide_map[col]
            parts.append(tmp)
        out = pd.concat(parts, ignore_index=True)
        out["milestone_idx"] = pd.to_numeric(out["milestone_idx"], errors="coerce").astype("Int64")
        out = out[[id_col, "milestone", "milestone_idx"]]

    out = (
        out.dropna(subset=["milestone_idx"])
           .sort_values(["milestone", "milestone_idx"])
           .groupby([id_col, "milestone"], as_index=False)
           .first()
    )
    return out


def prefix_lr_series_ngram(lm_mal: NgramLM, lm_ben: NgramLM, seq: List[str]) -> List[float]:
    """
    Returns S(t) for each prefix token index (0-based in seq), i.e., length == len(seq).
    """
    if len(seq) == 0:
        return []

    mal_ids = [lm_mal.vocab.get(t, lm_mal.unk_id) for t in seq]
    ben_ids = [lm_ben.vocab.get(t, lm_ben.unk_id) for t in seq]

    mal_lp = lm_mal.logprob_prefixes(mal_ids)
    ben_lp = lm_ben.logprob_prefixes(ben_ids)

    L = min(len(mal_lp), len(ben_lp))
    return [mal_lp[i] - ben_lp[i] for i in range(L)]


def max_lr_score_over_prefixes(lm_mal: NgramLM, lm_ben: NgramLM, seq: List[str]) -> float:
    s = prefix_lr_series_ngram(lm_mal, lm_ben, seq)
    return max(s) if s else float("-inf")

def first_crossing(prefix_series: List[float], tau: float) -> Optional[int]:
    for i, v in enumerate(prefix_series):
        if v >= tau:
            return i
    return None


def corrupt_iid(tokens: List[str], p_del: float, rng: random.Random) -> List[str]:
    if p_del <= 0:
        return tokens
    return [t for t in tokens if rng.random() > p_del]

def corrupt_bursty(tokens: List[str], p_del: float, mean_burst: int, rng: random.Random) -> List[str]:
    if p_del <= 0:
        return tokens
    if mean_burst <= 1:
        return corrupt_iid(tokens, p_del, rng)

    p_end = 1.0 / float(mean_burst)
    p_start = float(p_del) / (float(mean_burst) * (1.0 - float(p_del)) + 1e-12)
    p_start = min(1.0, max(0.0, p_start))

    out = []
    i = 0
    n = len(tokens)
    while i < n:
        if rng.random() < p_start:
            j = i
            while j < n:
                j += 1
                if rng.random() < p_end:
                    break
            i = j
        else:
            out.append(tokens[i])
            i += 1
    return out

def corrupt(tokens: List[str], p_del: float, mode: str, mean_burst: int, rng: random.Random) -> List[str]:
    if mode == "iid":
        return corrupt_iid(tokens, p_del, rng)
    if mode == "bursty":
        return corrupt_bursty(tokens, p_del, mean_burst, rng)
    raise ValueError(f"Unknown corruption mode: {mode}")

def stable_int_seed(*parts: str) -> int:
    h = hashlib.sha256("||".join(parts).encode("utf-8")).digest()
    return int.from_bytes(h[:8], "big", signed=False)

def corrupt_with_trace_seed(
    tokens: List[str],
    *,
    p_del: float,
    mode: str,
    mean_burst: int,
    base_seed: int,
    trace_id: str,
) -> Tuple[List[str], float]:
    tid_seed = stable_int_seed(str(base_seed), mode, f"{p_del:.4f}", trace_id)
    rng = random.Random(tid_seed)
    orig = len(tokens)
    out = corrupt(tokens, p_del=p_del, mode=mode, mean_burst=mean_burst, rng=rng)
    realized = 0.0 if orig == 0 else float(orig - len(out)) / float(orig)
    return out, realized


def early_table_from_det_and_ms(
    det: pd.DataFrame,
    ms_long: pd.DataFrame,
    *,
    id_col: str,
    det_col: str,
) -> pd.DataFrame:
    """
    Denominator per milestone = milestone observed (in ms_long).
    detected_rate = P(det exists | milestone observed)
    detected_before_rate = P(det < milestone_idx | milestone observed), missing detection => False
    Lead stats computed on (milestone observed AND detection exists).
    """
    df = ms_long.merge(det[[id_col, det_col]], on=id_col, how="left")

    rows = []
    for milestone, g in df.groupby("milestone"):
        denom = int(g[id_col].nunique())
        if denom == 0:
            rows.append({
                "milestone": milestone,
                "denom_milestone_observed": 0,
                "detected_rate": None,
                "detected_before_rate": None,
                "lead_n": 0,
                "lead_median": None,
                "lead_p25": None,
                "lead_p75": None,
                "missing_detection": 0,
            })
            continue

        has_det = g[det_col].notna().to_numpy()
        detected_rate = float(np.mean(has_det))

        before_flags = np.zeros(len(g), dtype=bool)
        lead_vals = []
        ms_idx = g["milestone_idx"].astype("Int64").to_numpy()
        dt_idx = g[det_col].astype("Int64").to_numpy()

        for i in range(len(g)):
            if pd.isna(ms_idx[i]):
                continue
            if pd.isna(dt_idx[i]):
                before_flags[i] = False
                continue
            msi = int(ms_idx[i])
            dti = int(dt_idx[i])
            before_flags[i] = (dti < msi)
            if before_flags[i]:
                lead_vals.append(msi - dti)

        detected_before_rate = float(np.mean(before_flags))
        missing_detection = int(denom - int(g.loc[g[det_col].notna(), id_col].nunique()))

        if lead_vals:
            arr = np.asarray(lead_vals, dtype=float)
            lead_n = int(len(arr))
            lead_median = float(np.median(arr))
            lead_p25 = float(np.quantile(arr, 0.25))
            lead_p75 = float(np.quantile(arr, 0.75))
        else:
            lead_n = 0
            lead_median = lead_p25 = lead_p75 = None

        rows.append({
            "milestone": milestone,
            "denom_milestone_observed": denom,
            "detected_rate": detected_rate,
            "detected_before_rate": detected_before_rate,
            "lead_n": lead_n,
            "lead_median": lead_median,
            "lead_p25": lead_p25,
            "lead_p75": lead_p75,
            "missing_detection": missing_detection,
        })

    return pd.DataFrame(rows).sort_values("milestone")


def eval_at_setting(
    *,
    ben: Dict[str, List[str]],
    mal: Dict[str, List[str]],
    meta: pd.DataFrame,
    ms_mal_long: pd.DataFrame,
    id_col: str,
    lm_ben: NgramLM,
    lm_mal: NgramLM,
    tau_01: float,
    tau_1: float,
    tau_5: float,
    tau_10: float,
    p_del: float,
    mode: str,
    mean_burst: int,
    seed: int,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    ben_scores = []
    ben_rdel = []
    ben_empty = 0

    for tid in sorted(ben.keys()):
        toks_c, rdel = corrupt_with_trace_seed(
            ben[tid], p_del=p_del, mode=mode, mean_burst=mean_burst, base_seed=seed, trace_id=tid
        )
        ben_rdel.append(rdel)
        if len(toks_c) == 0:
            ben_empty += 1
        s = max_lr_score_over_prefixes(lm_mal, lm_ben, toks_c)
        ben_scores.append((tid, s))

    ben_df = pd.DataFrame(ben_scores, columns=[id_col, "score"]).merge(meta, on=id_col, how="left")

    mal_scores = []
    mal_rdel = []
    mal_empty = 0
    det_rows = []

    for tid in sorted(mal.keys()):
        toks_c, rdel = corrupt_with_trace_seed(
            mal[tid], p_del=p_del, mode=mode, mean_burst=mean_burst, base_seed=seed, trace_id=tid
        )
        mal_rdel.append(rdel)
        if len(toks_c) == 0:
            mal_empty += 1

        series = prefix_lr_series_ngram(lm_mal, lm_ben, toks_c)
        mx = max(series) if series else float("-inf")
        d01 = first_crossing(series, tau_01)
        d1  = first_crossing(series, tau_1)
        d5  = first_crossing(series, tau_5)
        d10  = first_crossing(series, tau_10)
        mal_scores.append((tid, mx))
        det_rows.append((tid, d01, d1, d5, d10))


    mal_df = pd.DataFrame(mal_scores, columns=[id_col, "score"]).merge(meta, on=id_col, how="left")
    det = pd.DataFrame(det_rows, columns=[id_col, "det_idx_tau_0_1", "det_idx_tau_1_0", "det_idx_tau_5_0", "det_idx_tau_10_0"])

    ben_del_mean = float(np.mean(ben_rdel)) if ben_rdel else float("nan")
    mal_del_mean = float(np.mean(mal_rdel)) if mal_rdel else float("nan")

    out_rows = []
    for tag, tau in [("tau_0_1", tau_01), ("tau_1_0", tau_1), ("tau_5_0", tau_5), ("tau_10_0", tau_10)]:
        fpr = float(np.mean(ben_df["score"].values >= tau))
        tpr = float(np.mean(mal_df["score"].values >= tau))
        out_rows.append({
            "mode": mode,
            "p_del_target": float(p_del),
            "p_del_realized_ben_mean": ben_del_mean,
            "p_del_realized_mal_mean": mal_del_mean,
            "empty_frac_ben": float(ben_empty / max(1, len(ben_df))),
            "empty_frac_mal": float(mal_empty / max(1, len(mal_df))),
            "seed": int(seed),
            "tau": tag,
            "threshold": float(tau),
            "FPR_test": fpr,
            "TPR_test": tpr,
            "ben_test_n": int(len(ben_df)),
            "mal_test_n": int(len(mal_df)),
        })
    overall = pd.DataFrame(out_rows)

    fam_rows = []
    if "family" in mal_df.columns and mal_df["family"].notna().any():
        for fam, g in mal_df.groupby("family"):
            for tag, tau in [("tau_0.1", tau_01), ("tau_1.0", tau_1), ("tau_5.0", tau_5), ("tau_10.0", tau_10)]:
                tpr = float(np.mean(g["score"].values >= tau))
                fam_rows.append({
                    "mode": mode,
                    "p_del_target": float(p_del),
                    "seed": int(seed),
                    "tau": tag,
                    "family": fam,
                    "n": int(len(g)),
                    "TPR": tpr,
                })
    byfam = pd.DataFrame(fam_rows)

    early_rows = []
    for det_col, tag in [("det_idx_tau_0_1", "tau_0_1"), ("det_idx_tau_1_0", "tau_1_0"), ("det_idx_tau_5_0", "tau_5_0"), ("det_idx_tau_10_0", "tau_10_0")]:
        tbl = early_table_from_det_and_ms(det, ms_mal_long, id_col=id_col, det_col=det_col)
        tbl.insert(0, "tau", tag)
        tbl.insert(0, "seed", int(seed))
        tbl.insert(0, "p_del_target", float(p_del))
        tbl.insert(0, "mode", mode)
        early_rows.append(tbl)
    early_df = pd.concat(early_rows, ignore_index=True)

    return overall, byfam, early_df


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--processed_dir", type=str, default=None,
                    help="processed_{timestamp} directory (recommended). If omitted, picks newest processed_*.")
    ap.add_argument("--mean_burst", type=int, default=20)
    ap.add_argument("--p_grid", type=str, default="0,0.05,0.1,0.2,0.3")
    ap.add_argument("--modes", type=str, default="iid,bursty")
    ap.add_argument("--seeds", type=str, default=None, help="Comma list. Default: SEED,SEED+1,SEED+2")
    args = ap.parse_args()

    processed_dir = resolve_processed_dir(args.processed_dir)
    print("Using processed dir:", processed_dir)

    require_file(processed_dir / "splits.json")
    require_file(processed_dir / "ngram_thresholds.json")
    require_file(processed_dir / "ngram_models.pkl")

    splits = json.loads((processed_dir / "splits.json").read_text(encoding="utf-8"))
    th = json.loads((processed_dir / "ngram_thresholds.json").read_text(encoding="utf-8"))

    id_col = th.get("id_col", splits.get("id_col", "trace_id_content"))
    required = ["tau_0_1", "tau_1_0", "tau_5_0", "tau_10_0"]
    missing = [k for k in required if k not in th]
    if missing:
        raise KeyError(f"ngram_thresholds.json missing required discrete keys: {missing}")

    tau_01 = float(th["tau_0_1"])
    tau_1  = float(th["tau_1_0"])
    tau_5  = float(th["tau_5_0"])
    tau_10  = float(th["tau_10_0"])


    with open(processed_dir / "ngram_models.pkl", "rb") as f:
        obj = pickle.load(f)
    lm_ben = obj["lm_ben"]
    lm_mal = obj["lm_mal"]

    ben_test_ids = set(splits["benign"]["test"])
    mal_test_ids = set(splits["malware"]["test"])
    eval_ids = ben_test_ids | mal_test_ids

    print("Loading sequences...")
    ben_test = load_sequences_only(processed_dir, ben_test_ids, id_col=id_col)
    mal_test = load_sequences_only(processed_dir, mal_test_ids, id_col=id_col)

    print("Loading meta...")
    meta = load_meta(processed_dir, eval_ids, id_col=id_col).drop_duplicates(id_col)

    print("Loading milestones...")
    ms = load_milestones(processed_dir, id_col=id_col)
    ms_mal_long = ms[ms[id_col].isin(mal_test_ids)].copy()

    p_grid = [float(x.strip()) for x in args.p_grid.split(",") if x.strip() != ""]
    modes = [m.strip() for m in args.modes.split(",") if m.strip() != ""]
    mean_burst = int(args.mean_burst)
    if args.seeds:
        seeds = [int(x.strip()) for x in args.seeds.split(",") if x.strip() != ""]
    else:
        seeds = [SEED, SEED + 1, SEED + 2]

    print(f"modes={modes} | p_grid={p_grid} | mean_burst={mean_burst} | seeds={seeds}")

    all_overall = []
    all_byfam = []
    all_early = []

    for mode in modes:
        for p_del in p_grid:
            for s in seeds:
                print(f"Scoring mode={mode} p_del={p_del:.2f} seed={s} ...")
                overall, byfam, early_df = eval_at_setting(
                    ben=ben_test,
                    mal=mal_test,
                    meta=meta,
                    ms_mal_long=ms_mal_long,
                    id_col=id_col,
                    lm_ben=lm_ben,
                    lm_mal=lm_mal,
                    tau_01=tau_01,
                    tau_1=tau_1,
                    tau_5=tau_5,
                    tau_10=tau_10,
                    p_del=p_del,
                    mode=mode,
                    mean_burst=mean_burst,
                    seed=s,
                )
                all_overall.append(overall)
                all_early.append(early_df)
                if not byfam.empty:
                    all_byfam.append(byfam)

    overall_df = pd.concat(all_overall, ignore_index=True)
    out_fp = processed_dir / "fig3_robustness_ngram.csv"
    overall_df.to_csv(out_fp, index=False)

    if all_byfam:
        byfam_df = pd.concat(all_byfam, ignore_index=True)
        out_fp2 = processed_dir / "fig3_robustness_ngram_by_family.csv"
        byfam_df.to_csv(out_fp2, index=False)
    else:
        byfam_df = pd.DataFrame()

    early_all = pd.concat(all_early, ignore_index=True)
    out_fp3 = processed_dir / "fig3_robustness_ngram_early.csv"
    early_all.to_csv(out_fp3, index=False)

    print("\n=== Robustness summary (mean across seeds): TPR/FPR ===")
    summ = (
        overall_df
        .groupby(["mode", "p_del_target", "tau"], as_index=False)
        .agg(
            TPR_mean=("TPR_test", "mean"),
            TPR_std=("TPR_test", "std"),
            FPR_mean=("FPR_test", "mean"),
            FPR_std=("FPR_test", "std"),
            ben_del_mean=("p_del_realized_ben_mean", "mean"),
            mal_del_mean=("p_del_realized_mal_mean", "mean"),
            empty_ben_mean=("empty_frac_ben", "mean"),
            empty_mal_mean=("empty_frac_mal", "mean"),
        )
    )
    print(summ.to_string(index=False))

    print("\n=== Robustness summary (mean across seeds): EARLY ===")
    summ_e = (
        early_all
        .groupby(["mode", "p_del_target", "tau", "milestone"], as_index=False)
        .agg(
            denom=("denom_milestone_observed", "mean"),
            detected_rate_mean=("detected_rate", "mean"),
            detected_rate_std=("detected_rate", "std"),
            detected_before_rate_mean=("detected_before_rate", "mean"),
            detected_before_rate_std=("detected_before_rate", "std"),
            lead_median_mean=("lead_median", "mean"),
        )
    )
    print(summ_e.to_string(index=False))

    print("\nSaved:")
    print(f" - {out_fp}")
    if not byfam_df.empty:
        print(f" - {processed_dir / 'fig3_robustness_ngram_by_family.csv'}")
    print(f" - {out_fp3}")

if __name__ == "__main__":
    main()
