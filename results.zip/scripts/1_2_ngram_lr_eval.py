import json
import pickle
import argparse
from pathlib import Path
from dataclasses import dataclass
from typing import Dict, List, Tuple, Optional
from collections import Counter
import math

import numpy as np
import pandas as pd

from constants import REPO_ROOT


@dataclass
class NgramLM:
    order: int
    k: float
    vocab: Dict[str, int]
    unk_id: int
    bos_id: int
    counts: List[Dict[Tuple[int, ...], Counter]]
    context_totals: List[Dict[Tuple[int, ...], int]]

    def logprob_next(self, history: List[int], token_id: int) -> float:
        V = len(self.vocab)
        max_h = self.order - 1
        h = history[-max_h:] if max_h > 0 else []

        for n in range(self.order, 0, -1):
            ctx_len = n - 1
            ctx = tuple(h[-ctx_len:]) if ctx_len > 0 else tuple()

            dist = self.counts[n].get(ctx)
            total = self.context_totals[n].get(ctx, 0)

            if total > 0 and dist is not None:
                c_hw = dist.get(token_id, 0)
                p = (c_hw + self.k) / (total + self.k * V)
                return math.log(p)

        return -math.log(V)

    def logprob_prefixes(self, tokens: List[int]) -> List[float]:
        hist = [self.bos_id]
        cum = 0.0
        out = []
        for tid in tokens:
            lp = self.logprob_next(hist, tid)
            cum += lp
            out.append(cum)
            hist.append(tid)
        return out


def max_lr_score_over_prefixes(lm_mal: NgramLM, lm_ben: NgramLM, seq_tokens: List[str]) -> Tuple[float, List[float]]:
    mal_ids = [lm_mal.vocab.get(t, lm_mal.unk_id) for t in seq_tokens]
    ben_ids = [lm_ben.vocab.get(t, lm_ben.unk_id) for t in seq_tokens]

    mal_lp = lm_mal.logprob_prefixes(mal_ids)
    ben_lp = lm_ben.logprob_prefixes(ben_ids)

    s = [a - b for a, b in zip(mal_lp, ben_lp)]
    return (max(s) if s else float("-inf")), s


def detection_time(s_list: List[float], tau: float) -> Optional[int]:
    """Earliest t where score crosses tau. Returns index t (0-based) or None."""
    for t, s in enumerate(s_list):
        if s >= tau:
            return t
    return None


def is_missing(x) -> bool:
    return x is None or (isinstance(x, float) and np.isnan(x))


def lead_time(t_m, t_d) -> Optional[int]:
    if is_missing(t_m) or is_missing(t_d):
        return None
    return int(t_m) - int(t_d)


def summarize_leads(leads: List[Optional[int]]):
    vals = [x for x in leads if x is not None]
    if not vals:
        return {"n": 0, "median": None, "p25": None, "p75": None}
    arr = np.array(vals, dtype=float)
    return {
        "n": int(len(arr)),
        "median": float(np.median(arr)),
        "p25": float(np.quantile(arr, 0.25)),
        "p75": float(np.quantile(arr, 0.75)),
    }


def pick_latest_processed_dir() -> Path:
    root = Path(REPO_ROOT)
    cands = [p for p in root.glob("processed_*") if p.is_dir()]
    if not cands:
        raise FileNotFoundError(f"No processed_* dirs under {root}")
    return max(cands, key=lambda p: p.stat().st_mtime)


def iter_parquet_files(dirpath: Path, pattern: str):
    files = sorted(dirpath.glob(pattern))
    if not files:
        raise FileNotFoundError(f"No parquet files found in {dirpath} matching {pattern}")
    for fp in files:
        yield fp


def load_trace_rows_for_ids(processed_dir: Path, ids: set[str], *, id_col: str) -> pd.DataFrame:
    keep = []
    remaining = set(ids)

    for fp in iter_parquet_files(processed_dir, "traces_batch_*.parquet"):
        if not remaining:
            break
        df = pd.read_parquet(fp, columns=[id_col, "label", "family", "tokens", "len", "source"])
        sub = df[df[id_col].isin(remaining)]
        if not sub.empty:
            keep.append(sub)
            remaining.difference_update(sub[id_col].tolist())

    if remaining:
        print(f"[WARN] {len(remaining)} ids not found in trace batches (id_col={id_col}).")
    if keep:
        return pd.concat(keep, ignore_index=True)
    return pd.DataFrame(columns=[id_col, "label", "family", "tokens", "len", "source"])


def load_milestones_for_ids(processed_dir: Path, ids: set[str], *, id_col: str) -> dict[str, dict]:
    needed = set(ids)
    ms_map: dict[str, dict] = {}

    for fp in iter_parquet_files(processed_dir, "milestones_batch_*.parquet"):
        if not needed:
            break
        df = pd.read_parquet(fp, columns=[id_col, "t_dns", "t_c2", "t_pers", "t_priv"])
        sub = df[df[id_col].isin(needed)]
        if sub.empty:
            continue
        for r in sub.itertuples(index=False):
            tid = getattr(r, id_col)
            ms_map[tid] = {"t_dns": r.t_dns, "t_c2": r.t_c2, "t_pers": r.t_pers, "t_priv": r.t_priv}
        needed.difference_update(sub[id_col].tolist())

    if needed:
        print(f"[WARN] {len(needed)} ids not found in milestone batches (id_col={id_col}).")
    return ms_map


def load_thresholds(processed_dir: Path) -> tuple[float, float, float, dict]:
    """
    Loads thresholds from ngram_thresholds.json.

    Returns:
      tau_0_1, tau_1_0, tau_5_0, raw_threshold_dict
    """
    p = processed_dir / "ngram_thresholds.json"
    if not p.exists():
        raise FileNotFoundError(
            f"Missing ngram_thresholds.json in {processed_dir}. "
            f"Discrete thresholds are required."
        )

    th = json.loads(p.read_text(encoding="utf-8"))

    required = ["tau_0_1", "tau_1_0", "tau_5_0", "tau_10_0"]
    missing = [k for k in required if k not in th]
    if missing:
        raise KeyError(
            "ngram_thresholds.json must contain flat discrete keys "
            f"{required}. Missing: {missing}. "
            "Refusing to infer from quantiles or legacy formats."
        )

    return float(th["tau_0_1"]), float(th["tau_1_0"]), float(th["tau_5_0"]), float(th["tau_10_0"]), th


def early_table(mal_df: pd.DataFrame, det_col: str, *, inclusive: bool = False) -> pd.DataFrame:
    """
    Proper milestone-relative stats:
      - Denominator: traces where milestone exists (t_m not missing)
      - detected_before: fraction with detection and t_d < t_m (or <= if inclusive)
      - detected_rate: fraction with any detection among milestone-observed traces
      - lead-time stats: among traces with both milestone and detection
    """
    rows = []
    milestones = [("DNS", "t_dns"), ("C2", "t_c2"), ("Persistence", "t_pers"), ("PrivEsc", "t_priv")]

    for name, tcol in milestones:
        t_m = mal_df[tcol].values
        t_d = mal_df[det_col].values

        mask_m = ~pd.isna(t_m)
        denom = int(mask_m.sum())
        if denom == 0:
            rows.append({
                "milestone": name,
                "denom_milestone_observed": 0,
                "detected_rate": None,
                "detected_before_rate": None,
                "lead_n": 0,
                "lead_median": None,
                "lead_p25": None,
                "lead_p75": None,
            })
            continue

        t_m_obs = t_m[mask_m]
        t_d_obs = t_d[mask_m]

        det_mask = ~pd.isna(t_d_obs)
        detected_rate = float(det_mask.mean())

        if inclusive:
            before = det_mask & (t_d_obs <= t_m_obs)
        else:
            before = det_mask & (t_d_obs < t_m_obs)
        detected_before_rate = float(before.mean())

        leads = []
        for tm, td in zip(t_m_obs, t_d_obs):
            lt = lead_time(tm, td)
            if lt is not None:
                leads.append(lt)

        summ = summarize_leads(leads)
        rows.append({
            "milestone": name,
            "denom_milestone_observed": denom,
            "detected_rate": detected_rate,
            "detected_before_rate": detected_before_rate,
            "lead_n": summ["n"],
            "lead_median": summ["median"],
            "lead_p25": summ["p25"],
            "lead_p75": summ["p75"],
        })

    return pd.DataFrame(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--processed_dir", type=str, default=None,
                    help="processed_{timestamp} directory. If omitted, picks newest processed_* under REPO_ROOT.")
    ap.add_argument(
        "--inclusive",
        action="store_true",
        help="Count detection at the same event index as 'before' (t_d <= t_m). Default is strict (t_d < t_m).",
    )
    args = ap.parse_args()

    processed_dir = Path(args.processed_dir) if args.processed_dir else pick_latest_processed_dir()
    print(f"Using processed dir: {processed_dir}")

    splits = json.loads((processed_dir / "splits.json").read_text(encoding="utf-8"))
    id_col = splits.get("id_col", "trace_id_content")
    print(f"Using id_col: {id_col}")

    with open(processed_dir / "ngram_models.pkl", "rb") as f:
        obj = pickle.load(f)
    lm_ben = obj["lm_ben"]
    lm_mal = obj["lm_mal"]

    tau_01, tau_1, tau_5, tau_10, th_raw = load_thresholds(processed_dir)
    print(f"Loaded thresholds: tau_0.1={tau_01} tau_1.0={tau_1} tau_5.0={tau_5} tau_10.0={tau_10}")


    ben_test_ids = set(splits["benign"]["test"])
    mal_test_ids = set(splits["malware"]["test"])
    eval_ids = ben_test_ids | mal_test_ids

    df_eval = load_trace_rows_for_ids(processed_dir, eval_ids, id_col=id_col)

    ms_map = load_milestones_for_ids(processed_dir, eval_ids, id_col=id_col)
    for col in ("t_dns", "t_c2", "t_pers", "t_priv"):
        df_eval[col] = df_eval[id_col].map(lambda tid, c=col: ms_map.get(tid, {}).get(c, np.nan))

    ben_test = df_eval[df_eval[id_col].isin(ben_test_ids)].copy()
    mal_test = df_eval[df_eval[id_col].isin(mal_test_ids)].copy()

    print("Eval sizes:", {"ben_test": len(ben_test), "mal_test": len(mal_test)})

    def score_df(d: pd.DataFrame) -> pd.DataFrame:
        max_scores = []
        det01 = []
        det1 = []
        det5 = []
        det10 = []
        for r in d.itertuples(index=False):
            m, s = max_lr_score_over_prefixes(lm_mal, lm_ben, r.tokens)
            max_scores.append(m)
            det01.append(detection_time(s, tau_01))
            det1.append(detection_time(s, tau_1))
            det5.append(detection_time(s, tau_5))
            det10.append(detection_time(s, tau_10))
        d2 = d.copy()
        d2["max_lr"] = max_scores
        d2["t_det_0_1"] = det01
        d2["t_det_1_0"] = det1
        d2["t_det_5_0"] = det5
        d2["t_det_10_0"] = det10
        return d2


    ben_test = score_df(ben_test)
    mal_test = score_df(mal_test)

    fpr01 = float(np.mean(ben_test["max_lr"].values >= tau_01))
    fpr1  = float(np.mean(ben_test["max_lr"].values >= tau_1))
    fpr5  = float(np.mean(ben_test["max_lr"].values >= tau_5))
    fpr10  = float(np.mean(ben_test["max_lr"].values >= tau_10))

    tpr01 = float(np.mean(mal_test["max_lr"].values >= tau_01))
    tpr1  = float(np.mean(mal_test["max_lr"].values >= tau_1))
    tpr5  = float(np.mean(mal_test["max_lr"].values >= tau_5))
    tpr10  = float(np.mean(mal_test["max_lr"].values >= tau_10))



    fig1 = pd.DataFrame([{
        "tau": "0.1% nominal",
        "threshold": tau_01,
        "FPR_test": fpr01,
        "TPR_test": tpr01,
        "ben_test_n": len(ben_test),
        "mal_test_n": len(mal_test),
    }, {
        "tau": "1% nominal",
        "threshold": tau_1,
        "FPR_test": fpr1,
        "TPR_test": tpr1,
        "ben_test_n": len(ben_test),
        "mal_test_n": len(mal_test),
    }, {
        "tau": "5% nominal",
        "threshold": tau_5,
        "FPR_test": fpr5,
        "TPR_test": tpr5,
        "ben_test_n": len(ben_test),
        "mal_test_n": len(mal_test),
    }, {
        "tau": "10% nominal",
        "threshold": tau_10,
        "FPR_test": fpr10,
        "TPR_test": tpr10,
        "ben_test_n": len(ben_test),
        "mal_test_n": len(mal_test),
    }])


    fam_rows = []
    for fam, g in mal_test.groupby("family"):
        fam_rows.append({
            "family": fam,
            "n": len(g),
            "TPR@tau_0.1": float(np.mean(g["max_lr"].values >= tau_01)),
            "TPR@tau_1.0": float(np.mean(g["max_lr"].values >= tau_1)),
            "TPR@tau_5.0": float(np.mean(g["max_lr"].values >= tau_5)),
            "TPR@tau_10.0": float(np.mean(g["max_lr"].values >= tau_10)),
        })

    fig1_fam = pd.DataFrame(fam_rows).sort_values("family")

    fig2_01 = early_table(mal_test, "t_det_0_1", inclusive=args.inclusive)
    fig2_1  = early_table(mal_test, "t_det_1_0", inclusive=args.inclusive)
    fig2_5  = early_table(mal_test, "t_det_5_0", inclusive=args.inclusive)
    fig2_10  = early_table(mal_test, "t_det_10_0", inclusive=args.inclusive)


    fig1.to_csv(processed_dir / "fig1_tpr_fpr_ngram.csv", index=False)
    fig1_fam.to_csv(processed_dir / "fig1_tpr_by_family_ngram.csv", index=False)
    fig2_01.to_csv(processed_dir / "fig2_early_0.1_ngram.csv", index=False)
    fig2_1.to_csv(processed_dir / "fig2_early_1.0_ngram.csv", index=False)
    fig2_5.to_csv(processed_dir / "fig2_early_5.0_ngram.csv", index=False)
    fig2_10.to_csv(processed_dir / "fig2_early_10.0_ngram.csv", index=False)


    print("\nFigure 1 (overall):")
    print(fig1.to_string(index=False))

    print("\nFigure 1 (by family):")
    print(fig1_fam.to_string(index=False))

    print("\nFigure 2 (early detection @ tau_0.1):")
    print(fig2_01.to_string(index=False))

    print("\nFigure 2 (early detection @ tau_1.0):")
    print(fig2_1.to_string(index=False))

    print("\nFigure 2 (early detection @ tau_5.0):")
    print(fig2_5.to_string(index=False))

    print("\nFigure 2 (early detection @ tau_10.0):")
    print(fig2_10.to_string(index=False))


    print(f"\nSaved CSVs in: {processed_dir}")


if __name__ == "__main__":
    main()
