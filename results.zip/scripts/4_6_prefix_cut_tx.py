from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from constants import REPO_ROOT

DEVICE = torch.device("cpu")

class TransformerLM(nn.Module):
    def __init__(
        self,
        vocab_size: int,
        d_model: int,
        n_heads: int,
        n_layers: int,
        d_ff: int,
        dropout: float,
        max_pos: int,
        pad_id: int = 0,
    ):
        super().__init__()
        self.pad_id = pad_id
        self.tok = nn.Embedding(vocab_size, d_model, padding_idx=pad_id)
        self.pos = nn.Embedding(max_pos, d_model)
        enc_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=d_ff,
            dropout=dropout,
            batch_first=True,
            activation="gelu",
        )
        self.enc = nn.TransformerEncoder(enc_layer, num_layers=n_layers)
        self.ln = nn.LayerNorm(d_model)
        self.head = nn.Linear(d_model, vocab_size, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T = x.shape
        if T > self.pos.num_embeddings:
            raise ValueError(f"T={T} exceeds max_pos={self.pos.num_embeddings}")
        pos = torch.arange(T, device=x.device).unsqueeze(0).expand(B, T)
        h = self.tok(x) + self.pos(pos)
        causal = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), diagonal=1)
        h = self.enc(h, mask=causal)
        h = self.ln(h)
        return self.head(h)
        
def pick_latest_processed_dir() -> Path:
    root = Path(REPO_ROOT)
    cands = [p for p in root.glob("processed_*") if p.is_dir()]
    return max(cands, key=lambda p: p.stat().st_mtime)


def load_sequences(processed_dir: Path, ids: set[str], id_col: str) -> Dict[str, List[str]]:
    remaining = set(map(str, ids))
    out: Dict[str, List[str]] = {}
    for fp in sorted(processed_dir.glob("traces_batch_*.parquet")):
        if not remaining:
            break
        df = pd.read_parquet(fp, columns=[id_col, "tokens"])
        df[id_col] = df[id_col].astype(str)
        sub = df[df[id_col].isin(remaining)]
        for tid, toks in zip(sub[id_col].tolist(), sub["tokens"].tolist()):
            out[str(tid)] = list(toks)
        remaining -= set(sub[id_col].tolist())
    return out


def roc_auc(y_true: np.ndarray, scores: np.ndarray) -> float:
    y_true = np.asarray(y_true, int)
    scores = np.asarray(scores, float)
    n_pos = int(np.sum(y_true == 1))
    n_neg = int(np.sum(y_true == 0))
    ranks = pd.Series(scores).rank(method="average").to_numpy()
    sum_ranks_pos = float(np.sum(ranks[y_true == 1]))
    return float((sum_ranks_pos - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


@dataclass
class TxCfg:
    pad: str = "<pad>"
    unk: str = "<unk>"
    bos: str = "<bos>"
    context: int = 256
    stride: int = 64
    max_pos: int = 512
    d_model: int = 256
    n_heads: int = 8
    n_layers: int = 4
    d_ff: int = 1024
    dropout: float = 0.1


def load_tx_model(dirpath: Path, cfg: TxCfg) -> Tuple[TransformerLM, Dict[str, int]]:
    vocab = json.loads((dirpath / "vocab.json").read_text(encoding="utf-8"))
    ck = torch.load(dirpath / "best.pt", map_location=DEVICE)
    pad_id = int(ck.get("pad_id", vocab.get(cfg.pad, 0)))

    model = TransformerLM(
        vocab_size=len(vocab),
        d_model=cfg.d_model,
        n_heads=cfg.n_heads,
        n_layers=cfg.n_layers,
        d_ff=cfg.d_ff,
        dropout=cfg.dropout,
        max_pos=cfg.max_pos,
        pad_id=pad_id,
    ).to(DEVICE)
    model.load_state_dict(ck["model"])
    model.eval()
    return model, vocab


@torch.no_grad()
def logprob_prefixes_tx_contextcarry(
    model: TransformerLM,
    vocab: Dict[str, int],
    seq_tokens: List[str],
    *,
    cfg: TxCfg,
) -> List[float]:
    bos_id = vocab[cfg.bos]
    unk_id = vocab[cfg.unk]

    ids = [bos_id] + [vocab.get(t, unk_id) for t in seq_tokens]
    N = len(seq_tokens)
    if N == 0:
        return []

    cum = 0.0
    out: List[float] = []
    t = 1
    while t <= N:
        t_end = min(N + 1, t + cfg.stride)
        a = max(0, t - cfg.context - 1)
        b = t_end

        x_ids = ids[a:b]
        y_ids = ids[a + 1 : b + 1]
        L = min(len(x_ids), len(y_ids))
        x_ids = x_ids[:L]
        y_ids = y_ids[:L]

        x = torch.tensor([x_ids], dtype=torch.long, device=DEVICE)
        y = torch.tensor([y_ids], dtype=torch.long, device=DEVICE)

        logits = model(x)
        logp = torch.log_softmax(logits, dim=-1)
        tgt_lp = logp.gather(-1, y.unsqueeze(-1)).squeeze(-1).squeeze(0)

        for j in range(t, t_end):
            loc = j - a - 1
            if 0 <= loc < len(tgt_lp):
                cum += float(tgt_lp[loc].item())
                out.append(cum)

        t = t_end

    return out


def max_prefix_lr_tx(model_mal, model_ben, vocab, toks: List[str], cfg: TxCfg) -> float:
    mal_lp = logprob_prefixes_tx_contextcarry(model_mal, vocab, toks, cfg=cfg)
    ben_lp = logprob_prefixes_tx_contextcarry(model_ben, vocab, toks, cfg=cfg)
    L = min(len(mal_lp), len(ben_lp))
    if L == 0:
        return float("-inf")
    return float(max(mal_lp[i] - ben_lp[i] for i in range(L)))


def max_avg_prefix_lr_tx(model_mal, model_ben, vocab, toks: List[str], cfg: TxCfg) -> float:
    mal_lp = logprob_prefixes_tx_contextcarry(model_mal, vocab, toks, cfg=cfg)
    ben_lp = logprob_prefixes_tx_contextcarry(model_ben, vocab, toks, cfg=cfg)
    L = min(len(mal_lp), len(ben_lp))
    if L == 0:
        return float("-inf")
    lr = [mal_lp[i] - ben_lp[i] for i in range(L)]
    return float(max(lr[i] / (i + 1) for i in range(L)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--processed_dir", type=str, default=None)
    ap.add_argument("--cuts", type=str, default="0,10,25,50,100,200")
    args = ap.parse_args()

    processed_dir = Path(args.processed_dir) if args.processed_dir else pick_latest_processed_dir()
    print("Using processed_dir:", processed_dir)

    cuts = sorted(set(int(x.strip()) for x in args.cuts.split(",") if x.strip()))
    if any(c < 0 for c in cuts):
        raise ValueError("cuts must be >= 0")

    splits = json.loads((processed_dir / "splits.json").read_text(encoding="utf-8"))
    id_col = splits.get("id_col", "trace_id_content")
    ben_ids = set(splits["benign"]["test"])
    mal_ids = set(splits["malware"]["test"])

    print("Loading sequences...")
    ben = list(load_sequences(processed_dir, ben_ids, id_col).values())
    mal = list(load_sequences(processed_dir, mal_ids, id_col).values())

    thr = json.loads((processed_dir / "tx_thresholds.json").read_text(encoding="utf-8"))
    cfg = TxCfg()
    if "cfg" in thr:
        for k, v in thr["cfg"].items():
            if hasattr(cfg, k):
                setattr(cfg, k, v)

    model_ben, vocab_ben = load_tx_model(processed_dir / "tx_models" / "benign", cfg)
    model_mal, vocab_mal = load_tx_model(processed_dir / "tx_models" / "malware", cfg)
    if vocab_ben != vocab_mal:
        raise AssertionError("TX vocabs differ between benign/malware models.")
    vocab = vocab_ben

    y = np.concatenate([np.zeros(len(ben), int), np.ones(len(mal), int)])

    print("\n=== TX PREFIX CUT EXPERIMENT ===")
    print("cut\tAUC(max_cum)\tAUC(max_avg)")

    for cut in cuts:
        ben_cut = [t[cut:] for t in ben]
        mal_cut = [t[cut:] for t in mal]

        s_cum = np.concatenate([
            np.array([max_prefix_lr_tx(model_mal, model_ben, vocab, t, cfg) for t in ben_cut], float),
            np.array([max_prefix_lr_tx(model_mal, model_ben, vocab, t, cfg) for t in mal_cut], float),
        ])
        auc_cum = roc_auc(y, s_cum)

        s_avg = np.concatenate([
            np.array([max_avg_prefix_lr_tx(model_mal, model_ben, vocab, t, cfg) for t in ben_cut], float),
            np.array([max_avg_prefix_lr_tx(model_mal, model_ben, vocab, t, cfg) for t in mal_cut], float),
        ])
        auc_avg = roc_auc(y, s_avg)

        print(f"{cut}\t{auc_cum:.6f}\t{auc_avg:.6f}")


if __name__ == "__main__":
    main()
