import os, json, math, random
from dataclasses import dataclass
from pathlib import Path
from typing import List, Dict, Tuple, Optional

from constants import REPO_ROOT
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader

SEED = 1337
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed_all(SEED)

torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

@dataclass
class Cfg:
    pad: str = "<PAD>"
    bos: str = "<BOS>"
    unk: str = "<UNK>"

    d_model: int = 256
    n_heads: int = 8
    n_layers: int = 4
    d_ff: int = 1024
    dropout: float = 0.1
    max_pos: int = 50000

    batch_size: int = 8
    lr: float = 2e-4
    weight_decay: float = 0.01
    warmup_steps: int = 200
    max_steps: int = 4000
    log_every: int = 100
    eval_every: int = 400
    grad_clip: float = 1.0
    block: int = 512

    score_context: int = 512
    score_stride: int = 512

    malware_val_frac: float = 0.1

cfg = Cfg()


def split_train_val(seqs: List[List[str]], val_frac: float, seed: int) -> Tuple[List[List[str]], List[List[str]]]:
    rng = random.Random(seed)
    idx = list(range(len(seqs)))
    rng.shuffle(idx)
    n_val = max(1, int(val_frac * len(seqs)))
    val_idx = set(idx[:n_val])
    tr = [seqs[i] for i in range(len(seqs)) if i not in val_idx]
    va = [seqs[i] for i in range(len(seqs)) if i in val_idx]
    return tr, va


def pick_latest_processed_dir() -> Path:
    root = Path(REPO_ROOT)
    cands = [p for p in root.glob("processed_*") if p.is_dir()]
    if not cands:
        raise FileNotFoundError(f"No processed_* directories under {root}. Run extraction + splits first.")
    return max(cands, key=lambda p: p.stat().st_mtime)


def load_splits_and_processed_dir(explicit_processed_dir: Optional[str] = None) -> Tuple[dict, Path]:
    """
    Loads splits.json and returns (splits, processed_dir).
    If explicit_processed_dir is provided, it is used; otherwise newest processed_*.
    """
    processed_dir = Path(explicit_processed_dir) if explicit_processed_dir else pick_latest_processed_dir()
    splits_path = processed_dir / "splits.json"
    if not splits_path.exists():
        raise FileNotFoundError(f"Could not find splits.json in: {splits_path}")

    with open(splits_path, "r", encoding="utf-8") as f:
        splits = json.load(f)

    if "processed_dir" in splits:
        pd2 = Path(splits["processed_dir"])
        if pd2.exists() and pd2.resolve() != processed_dir.resolve():
            raise AssertionError(
                f"processed_dir argument ({processed_dir}) != splits['processed_dir'] ({pd2}). "
                "Run with --processed_dir matching splits.json."
            )

    return splits, processed_dir

def quantile_threshold_discrete(scores: np.ndarray, alpha: float) -> tuple[float, float, int]:
    """
    Discrete, rank-based threshold for trace-level FPR control.

    Detector triggers on: score >= tau
    We must choose tau such that:
        FP_count = sum(score_i >= tau) <= allowed_fp_count
    where allowed_fp_count = floor(alpha * n).

    If ties at the cutoff make the exact target unattainable, we return the
    tightest tau that still respects the FP constraint and report the true
    achievable_alpha (<= target).
    """
    scores = np.asarray(scores, dtype=float)
    n = int(scores.size)
    if n == 0:
        return float("inf"), 0.0, 0

    allowed = int(math.floor(alpha * n))

    if allowed <= 0:
        tau = float(np.max(scores)) + 1e-12
        return tau, 0.0, 0

    vals, counts = np.unique(scores, return_counts=True)
    order = np.argsort(vals)[::-1]
    vals = vals[order]
    counts = counts[order]

    cum = 0
    for v, c in zip(vals, counts):
        c = int(c)
        if cum + c > allowed:
            tau = float(v) + 1e-12
            achievable = cum / n
            return tau, achievable, allowed
        cum += c

    tau = float(vals[-1]) - 1e-12
    achievable = cum / n
    return tau, achievable, allowed

def build_vocab(seqs: List[List[str]], min_freq: int = 1) -> Dict[str, int]:
    from collections import Counter
    c = Counter()
    for s in seqs:
        c.update(s)
    vocab = {cfg.pad: 0, cfg.unk: 1, cfg.bos: 2}
    for tok, freq in c.items():
        if freq >= min_freq and tok not in vocab:
            vocab[tok] = len(vocab)
    return vocab


def encode(seq: List[str], vocab: Dict[str, int]) -> List[int]:
    unk = vocab[cfg.unk]
    return [vocab.get(t, unk) for t in seq]


class LMDataset(Dataset):
    """
    Non-overlapping blocks for standard LM training.
    Each block is (x, y) where y is x shifted by one.
    """
    def __init__(self, seqs_tok: List[List[str]], vocab: Dict[str, int], block: int):
        self.vocab = vocab
        self.block = block
        self.bos_id = vocab[cfg.bos]
        self.blocks: List[Tuple[List[int], List[int]]] = []

        for s in seqs_tok:
            ids = [self.bos_id] + encode(s, vocab)
            i = 0
            while i + 2 < len(ids):
                chunk = ids[i : i + block + 1]
                if len(chunk) < 3:
                    break
                x = chunk[:-1]
                y = chunk[1:]
                self.blocks.append((x, y))
                i += block

    def __len__(self):
        return len(self.blocks)

    def __getitem__(self, idx):
        x, y = self.blocks[idx]
        return torch.tensor(x, dtype=torch.long), torch.tensor(y, dtype=torch.long)


def collate_pad(batch, pad_id: int):
    xs, ys = zip(*batch)
    maxlen = max(x.size(0) for x in xs)
    xpad = torch.full((len(xs), maxlen), fill_value=pad_id, dtype=torch.long)
    ypad = torch.full((len(xs), maxlen), fill_value=-100, dtype=torch.long)
    for i, (x, y) in enumerate(zip(xs, ys)):
        xpad[i, :x.size(0)] = x
        ypad[i, :y.size(0)] = y
    key_padding_mask = (xpad == pad_id)
    return xpad, ypad, key_padding_mask


class TransformerLM(nn.Module):
    def __init__(self, vocab_size: int, d_model: int, n_heads: int, n_layers: int, d_ff: int, dropout: float, max_pos: int, pad_id: int):
        super().__init__()
        self.pad_id = pad_id
        self.tok = nn.Embedding(vocab_size, d_model, padding_idx=pad_id)
        self.pos = nn.Embedding(max_pos, d_model)
        enc_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=d_ff,
            dropout=dropout,
            batch_first=True,
            activation="gelu",
        )
        self.enc = nn.TransformerEncoder(enc_layer, num_layers=n_layers)
        self.ln = nn.LayerNorm(d_model)
        self.head = nn.Linear(d_model, vocab_size, bias=False)

    def forward(self, x: torch.Tensor, key_padding_mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        B, T = x.shape
        if T > self.pos.num_embeddings:
            raise ValueError(f"Sequence length T={T} exceeds max_pos={self.pos.num_embeddings}")
        pos = torch.arange(T, device=x.device).unsqueeze(0).expand(B, T)
        h = self.tok(x) + self.pos(pos)
        causal = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), diagonal=1)
        h = self.enc(h, mask=causal, src_key_padding_mask=key_padding_mask)
        h = self.ln(h)
        return self.head(h)

def lr_schedule(step: int) -> float:
    if step < cfg.warmup_steps:
        return step / max(1, cfg.warmup_steps)
    progress = (step - cfg.warmup_steps) / max(1, (cfg.max_steps - cfg.warmup_steps))
    return 0.5 * (1.0 + math.cos(math.pi * min(1.0, progress)))


def eval_loss(model: TransformerLM, dl: DataLoader, loss_fn: nn.Module, vocab_size: int) -> float:
    model.eval()
    vals = []
    with torch.no_grad():
        for x, y, kpm in dl:
            x = x.to(DEVICE)
            y = y.to(DEVICE)
            kpm = kpm.to(DEVICE)
            logits = model(x, key_padding_mask=kpm)
            lv = loss_fn(logits.view(-1, vocab_size), y.view(-1)).item()
            vals.append(lv)
    return float(np.mean(vals)) if vals else float("inf")


def train_one(
    name: str,
    seqs_train: List[List[str]],
    seqs_val: List[List[str]],
    out_dir: Path,
    *,
    vocab: Dict[str, int],
) -> Tuple[TransformerLM, Dict[str, int]]:    
    out_dir.mkdir(parents=True, exist_ok=True)
    with open(out_dir / "vocab.json", "w", encoding="utf-8") as f:
        json.dump(vocab, f, indent=2)

    pad_id = vocab[cfg.pad]

    ds_tr = LMDataset(seqs_train, vocab, block=cfg.block)
    ds_va = LMDataset(seqs_val, vocab, block=cfg.block)

    dl_tr = DataLoader(
        ds_tr,
        batch_size=cfg.batch_size,
        shuffle=True,
        collate_fn=lambda b: collate_pad(b, pad_id),
    )
    dl_va = DataLoader(
        ds_va,
        batch_size=cfg.batch_size,
        shuffle=False,
        collate_fn=lambda b: collate_pad(b, pad_id),
    )

    model = TransformerLM(
        vocab_size=len(vocab),
        d_model=cfg.d_model,
        n_heads=cfg.n_heads,
        n_layers=cfg.n_layers,
        d_ff=cfg.d_ff,
        dropout=cfg.dropout,
        max_pos=cfg.max_pos,
        pad_id=pad_id,
    ).to(DEVICE)

    opt = torch.optim.AdamW(model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)
    loss_fn = nn.CrossEntropyLoss(ignore_index=-100)

    best_val = float("inf")
    step = 0
    model.train()

    it = iter(dl_tr)
    while step < cfg.max_steps:
        try:
            x, y, kpm = next(it)
        except StopIteration:
            it = iter(dl_tr)
            x, y, kpm = next(it)

        x = x.to(DEVICE)
        y = y.to(DEVICE)
        kpm = kpm.to(DEVICE)

        logits = model(x, key_padding_mask=kpm)
        loss = loss_fn(logits.view(-1, logits.size(-1)), y.view(-1))

        opt.zero_grad(set_to_none=True)
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), cfg.grad_clip)

        lr_mult = lr_schedule(step)
        for pg in opt.param_groups:
            pg["lr"] = cfg.lr * lr_mult
        opt.step()

        if step % cfg.log_every == 0:
            print(f"[{name}] step={step} loss={loss.item():.4f} lr={opt.param_groups[0]['lr']:.2e} blocks={len(ds_tr)}")

        if step % cfg.eval_every == 0 and step > 0:
            val_loss = eval_loss(model, dl_va, loss_fn, len(vocab))
            print(f"[{name}] VAL step={step} loss={val_loss:.4f}")
            if val_loss < best_val:
                best_val = val_loss
                torch.save({"model": model.state_dict(), "pad_id": pad_id}, out_dir / "best.pt")
                print(f"[{name}] saved best.pt (val={best_val:.4f})")
            model.train()

        step += 1

    torch.save({"model": model.state_dict(), "pad_id": pad_id}, out_dir / "final.pt")
    print(f"[{name}] saved final.pt")

    return model, vocab


@torch.no_grad()
def logprob_prefixes_tx_contextcarry(
    model: TransformerLM,
    vocab: Dict[str, int],
    seq_tokens: List[str],
    *,
    context: int,
    stride: int,
) -> List[float]:
    """
    Returns cumulative log-probabilities for each token in seq_tokens (length N).
    We approximate prefix log-likelihoods by scoring in windows:
      - Use up to `context` tokens of left context.
      - Score `stride` new target tokens per step.
    """
    model.eval()
    bos_id = vocab[cfg.bos]
    unk_id = vocab[cfg.unk]

    ids = [bos_id] + [vocab.get(t, unk_id) for t in seq_tokens]
    N = len(seq_tokens)
    if N == 0:
        return []

    cum = 0.0
    out: List[float] = []

    t = 1
    while t <= N:
        t_end = min(N + 1, t + stride)
        a = max(0, t - context - 1)
        b = t_end

        x_ids = ids[a:b]
        y_ids = ids[a+1:b+1]
        L = min(len(x_ids), len(y_ids))
        x_ids = x_ids[:L]
        y_ids = y_ids[:L]

        x = torch.tensor([x_ids], dtype=torch.long, device=DEVICE)
        y = torch.tensor([y_ids], dtype=torch.long, device=DEVICE)

        logits = model(x)
        logp = torch.log_softmax(logits, dim=-1)
        tgt_lp = logp.gather(-1, y.unsqueeze(-1)).squeeze(-1).squeeze(0)

        for p in range(t, t_end):
            wi = p - (a + 1)
            if 0 <= wi < tgt_lp.numel():
                cum += float(tgt_lp[wi].item())
                out.append(cum)

        t = t_end

    if len(out) != N:
        raise AssertionError(f"context-carry scoring produced len(out)={len(out)} != N={N}")

    return out


def max_lr_over_prefixes_tx(
    model_mal: TransformerLM,
    vocab_mal: Dict[str, int],
    model_ben: TransformerLM,
    vocab_ben: Dict[str, int],
    seq_tokens: List[str],
) -> Tuple[float, List[float]]:
    mal_lp = logprob_prefixes_tx_contextcarry(model_mal, vocab_mal, seq_tokens, context=cfg.score_context, stride=cfg.score_stride)
    ben_lp = logprob_prefixes_tx_contextcarry(model_ben, vocab_ben, seq_tokens, context=cfg.score_context, stride=cfg.score_stride)
    L = min(len(mal_lp), len(ben_lp))
    s = [mal_lp[i] - ben_lp[i] for i in range(L)]
    return (max(s) if s else float("-inf")), s


def iter_trace_batches(processed_dir: Path, id_col: str, glob_pat: str = "traces_batch_*.parquet"):
    files = sorted(processed_dir.glob(glob_pat))
    if not files:
        raise FileNotFoundError(f"No trace batch files found in {processed_dir} matching {glob_pat}")
    for fp in files:
        yield fp, pd.read_parquet(fp, columns=[id_col, "tokens"])


def load_sequences_for_ids(processed_dir: Path, ids: set[str], *, id_col: str) -> Tuple[List[List[str]], int]:
    out: list[list[str]] = []
    remaining = set(ids)

    for _, df in iter_trace_batches(processed_dir, id_col=id_col):
        if not remaining:
            break
        sub = df[df[id_col].isin(remaining)]
        if sub.empty:
            continue
        out.extend(sub["tokens"].tolist())
        remaining.difference_update(sub[id_col].tolist())

    if remaining:
        print(f"[WARN] missing {len(remaining)} ids in parquet batches (not found).")
    return out, len(remaining)


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--processed_dir", type=str, default=None,
                    help="processed_{timestamp} directory. If omitted, picks newest processed_* under REPO_ROOT.")
    args = ap.parse_args()

    splits, processed_dir = load_splits_and_processed_dir(args.processed_dir)
    print("Using processed dir:", processed_dir)
    print("DEVICE:", DEVICE)

    id_col = splits.get("id_col", "trace_id_content")
    print("Using id_col:", id_col)

    ben_train_ids = set(splits["benign"]["train"])
    ben_val_ids   = set(splits["benign"]["val"])
    mal_train_ids = set(splits["malware"]["train"])

    print("Loading sequences from parquet batches...")
    ben_train, miss_bt = load_sequences_for_ids(processed_dir, ben_train_ids, id_col=id_col)
    ben_val,   miss_bv = load_sequences_for_ids(processed_dir, ben_val_ids, id_col=id_col)
    mal_train, miss_mt = load_sequences_for_ids(processed_dir, mal_train_ids, id_col=id_col)

    print("Building shared vocabulary on (benign_train ∪ malware_train)...")
    shared_vocab = build_vocab(ben_train + mal_train, min_freq=1)

    print(f"Sizes: benign_train={len(ben_train)} benign_val={len(ben_val)} malware_train={len(mal_train)}")

    tx_root = processed_dir / "tx_models"
    out_ben = tx_root / "benign"
    out_mal = tx_root / "malware"

    train_one("benign", ben_train, ben_val, out_dir=out_ben, vocab=shared_vocab)

    mal_tr, mal_va = split_train_val(mal_train, val_frac=cfg.malware_val_frac, seed=SEED)
    print(f"Malware internal split: train={len(mal_tr)} val={len(mal_va)}")
    train_one("malware", mal_tr, mal_va, out_dir=out_mal, vocab=shared_vocab)

    def load_model(dirpath: Path) -> Tuple[TransformerLM, Dict[str, int]]:
        with open(dirpath / "vocab.json", "r", encoding="utf-8") as f:
            vocab = json.load(f)
        
        if vocab != shared_vocab:
            raise AssertionError(
                f"{dirpath}/vocab.json differs from shared vocab. "
                "Delete tx_models/ and retrain to ensure shared vocabulary."
            )
        ck = torch.load(dirpath / "best.pt", map_location=DEVICE)
        pad_id = int(ck.get("pad_id", vocab.get(cfg.pad, 0)))
        model = TransformerLM(
            vocab_size=len(vocab),
            d_model=cfg.d_model,
            n_heads=cfg.n_heads,
            n_layers=cfg.n_layers,
            d_ff=cfg.d_ff,
            dropout=cfg.dropout,
            max_pos=cfg.max_pos,
            pad_id=pad_id,
        ).to(DEVICE)
        model.load_state_dict(ck["model"])
        model.eval()
        return model, vocab

    model_ben, vocab_ben = load_model(out_ben)
    model_mal, vocab_mal = load_model(out_mal)

    print("Scoring benign VAL for thresholds (benign val only)...")
    if len(ben_val) < 1000:
        print(f"[WARN] benign VAL is small (n={len(ben_val)}); very low FPR targets are nominal only.")

    max_scores = []
    for seq in ben_val:
        m, _ = max_lr_over_prefixes_tx(model_mal, vocab_mal, model_ben, vocab_ben, seq)
        max_scores.append(m)

    max_scores = np.asarray(max_scores, dtype=float)

    tau_01_d, alpha_01_eff, k01 = quantile_threshold_discrete(max_scores, 0.001)
    tau_1_d,  alpha_1_eff,  k1  = quantile_threshold_discrete(max_scores, 0.01)
    tau_5_d,  alpha_5_eff,  k5  = quantile_threshold_discrete(max_scores, 0.05)
    tau_10_d,  alpha_10_eff,  k10  = quantile_threshold_discrete(max_scores, 0.10)


    def realized_fpr(tau: float) -> float:
        return float(np.mean(max_scores >= tau))

    n_val = int(len(max_scores))
    out = {
        "seed": splits.get("seed", SEED),
        "id_col": id_col,
        "model": "two-transformer-lms_shared_vocab",
        "score": "max_prefix_loglik_ratio_contextcarry",
        "threshold_source": "benign_val_only",
        "threshold_method": "DISCRETE tau on max_prefix_lr_score (trace triggers if any prefix crosses tau)",
        "processed_dir": str(processed_dir),
        "trace_batches_glob": str(processed_dir / "traces_batch_*.parquet"),
        "n_ben_train": int(len(ben_train)),
        "n_ben_val": int(len(ben_val)),
        "n_mal_train": int(len(mal_train)),
        "missing_ids": {
            "ben_train": int(miss_bt),
            "ben_val": int(miss_bv),
            "mal_train": int(miss_mt),
        },
        "tau": {
            "discrete_0.1pct": float(tau_01_d),
            "discrete_1pct": float(tau_1_d),
            "discrete_5pct": float(tau_5_d),
            "discrete_10pct": float(tau_10_d),
        },
        "effective_alpha_discrete": {
            "target_0.1pct": 0.001,
            "achievable_0.1pct": float(alpha_01_eff),
            "allowed_fp_count_0.1pct": int(k01),

            "target_1pct": 0.01,
            "achievable_1pct": float(alpha_1_eff),
            "allowed_fp_count_1pct": int(k1),

            "target_5pct": 0.05,
            "achievable_5pct": float(alpha_5_eff),
            "allowed_fp_count_5pct": int(k5),

            "target_10pct": 0.10,
            "achievable_10pct": float(alpha_10_eff),
            "allowed_fp_count_10pct": int(k10),
        },
        "val_realized_fpr": {
            "discrete_0.1pct_score>=tau": realized_fpr(tau_01_d),
            "discrete_1pct_score>=tau": realized_fpr(tau_1_d),
            "discrete_5pct_score>=tau": realized_fpr(tau_5_d),
            "discrete_10pct_score>=tau": realized_fpr(tau_10_d),
        },

        "tau_0_1": float(tau_01_d),
        "tau_1_0": float(tau_1_d),
        "tau_5_0": float(tau_5_d),
        "tau_10_0": float(tau_10_d),
        "ben_val_score_summary": {
            "n": int(n_val),
            "min": float(np.min(max_scores)) if n_val else None,
            "median": float(np.median(max_scores)) if n_val else None,
            "p90": float(np.quantile(max_scores, 0.9)) if n_val else None,
            "p99": float(np.quantile(max_scores, 0.99)) if n_val else None,
            "max": float(np.max(max_scores)) if n_val else None,
        },
        "cfg": cfg.__dict__,
        "device": DEVICE,
        "shared_vocab_size": int(len(shared_vocab)),
    }

    th_path = processed_dir / "tx_thresholds.json"
    with open(th_path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print("Saved:", th_path)
    print(json.dumps(
        {"tau_0_1": float(tau_01_d), "tau_1_0": float(tau_1_d), "tau_5_0": float(tau_5_d), "tau_10_0": float(tau_10_d)},
        indent=2
    ))



if __name__ == "__main__":
    main()
