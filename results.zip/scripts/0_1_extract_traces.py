import argparse
import hashlib
import json
import os
import sys
import zipfile
from collections import Counter
from collections.abc import Iterable, Iterator
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from itertools import islice
from typing import Any

import pandas as pd

from constants import REPO_ROOT

DEFAULT_E_MAX = 50_000
DEFAULT_N_MIN = 10
DEFAULT_K_INIT = 0

API_KEYS = ("api", "api_name", "function", "call", "name")
TIME_KEYS = ("timestamp", "time", "ts")


def batched(it: Iterable[tuple[str, bytes]], batch_size: int) -> Iterator[list[tuple[str, bytes]]]:
    """Collect items from an iterator into lists of size batch_size."""
    it = iter(it)
    while True:
        batch = list(islice(it, batch_size))
        if not batch:
            return
        yield batch


def count_json_reports(path: str, *, zip_inner_prefix: str | None = None) -> int:
    """
    Count JSON files without reading their bytes into memory.

    - For directories: counts *.json files recursively + counts json inside any nested zips.
    - For zips: counts members ending in *.json (optionally under inner prefix).
    """
    if os.path.isdir(path):
        total = 0
        for root, _, files in os.walk(path):
            for name in files:
                lower = name.lower()
                full = os.path.join(root, name)
                if lower.endswith(".json"):
                    total += 1
                elif lower.endswith(".zip"):
                    total += count_json_reports(full, zip_inner_prefix=zip_inner_prefix)
        return total

    if path.lower().endswith(".zip") and os.path.isfile(path):
        prefix = None
        if zip_inner_prefix is not None:
            prefix = zip_inner_prefix.replace("\\", "/")
            if prefix and not prefix.endswith("/"):
                prefix += "/"

        with zipfile.ZipFile(path) as zf:
            n = 0
            for name in zf.namelist():
                if name.endswith("/"):
                    continue
                inner = name.replace("\\", "/")
                if prefix and not inner.startswith(prefix):
                    continue
                if inner.lower().endswith(".json"):
                    n += 1
            return n

    return 0


def iter_report_json_sources(path: str, *, zip_inner_prefix: str | None = None) -> Iterator[tuple[str, bytes]]:
    """
    Yield (virtual_path, raw_bytes) for each JSON report.

    Supports:
      - directory trees (recursive)
      - .zip files
      - zip files nested inside directories

    If `zip_inner_prefix` is provided, it filters ZIP members to only those whose
    normalized inner path starts with that prefix (POSIX-style, with '/').
    """
    if os.path.isdir(path):
        for root, _, files in os.walk(path):
            files.sort()
            for name in files:
                full = os.path.join(root, name)
                lower = name.lower()

                if lower.endswith(".json"):
                    try:
                        with open(full, "rb") as f:
                            yield full, f.read()
                    except OSError as e:
                        print(f"[WARN] read failed: {full}: {e}", file=sys.stderr)

                elif lower.endswith(".zip"):
                    yield from iter_report_json_sources(full, zip_inner_prefix=zip_inner_prefix)
        return

    if path.lower().endswith(".zip"):
        prefix = None
        if zip_inner_prefix is not None:
            prefix = zip_inner_prefix.replace("\\", "/")
            if prefix and not prefix.endswith("/"):
                prefix += "/"

        with zipfile.ZipFile(path) as zf:
            for name in sorted(zf.namelist()):
                if name.endswith("/"):
                    continue

                inner = name.replace("\\", "/")

                if prefix and not inner.startswith(prefix):
                    continue
                if not inner.lower().endswith(".json"):
                    continue

                try:
                    data = zf.read(name)
                    yield f"{path}::{inner}", data
                except (KeyError, RuntimeError, OSError) as e:
                    print(f"[WARN] zip read failed: {path}::{inner}: {e}", file=sys.stderr)
                    continue


def virtual_abs_path(virtual_fp: str) -> str:
    """
    Convert a virtual path (either a filesystem path, or 'zip_path::inner')
    into a canonical absolute identifier string.
    """
    if "::" in virtual_fp:
        zip_path, inner = virtual_fp.split("::", 1)
        zip_abs = os.path.abspath(zip_path)
        inner_norm = inner.replace("\\", "/")
        return f"{zip_abs}::{inner_norm}"
    return os.path.abspath(virtual_fp)


def sha256_hex(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def trace_id_content(data: bytes) -> str:
    """Stable across machines/paths: SHA256 over raw report bytes."""
    return sha256_hex(data)


def trace_id_path(virtual_fp: str) -> str:
    """Provenance ID: SHA256 over canonical absolute virtual path."""
    s = virtual_abs_path(virtual_fp)
    return sha256_hex(s.encode("utf-8"))


def get_api(call: dict[str, Any]) -> str | None:
    for k in API_KEYS:
        v = call.get(k)
        if isinstance(v, str) and v:
            return v.strip()
    return None


def get_time(call: dict[str, Any]) -> float | None:
    for k in TIME_KEYS:
        v = call.get(k)
        if isinstance(v, (int, float)):
            return float(v)
    return None


@dataclass(frozen=True)
class ExtractCfg:
    e_max: int = DEFAULT_E_MAX
    n_min: int = DEFAULT_N_MIN
    k_init: int = DEFAULT_K_INIT


@dataclass
class ExtractStats:
    total_reports_seen: int = 0
    kept_traces: int = 0
    dropped: Counter = None
    missing_family: int = 0

    total_events: int = 0
    missing_ts_events: int = 0

    def __post_init__(self) -> None:
        if self.dropped is None:
            self.dropped = Counter()

    def as_dict(self) -> dict[str, Any]:
        d = {
            "total_reports_seen": self.total_reports_seen,
            "kept_traces": self.kept_traces,
            "dropped": dict(self.dropped),
            "missing_family": self.missing_family,
            "total_events": self.total_events,
            "missing_ts_events": self.missing_ts_events,
        }
        d["missing_ts_frac"] = (self.missing_ts_events / self.total_events) if self.total_events else 0.0
        return d


def extract_tokens_from_report_bytes(
    data: bytes,
    cfg: ExtractCfg,
    stats: ExtractStats | None = None,
) -> list[str] | None:
    """
    Extract ordered API-call tokens from a CAPE/Cuckoo report.

    - Collect calls across processes
    - Sort by (timestamp, pid, idx) where timestamp None sorts to the end
    - Drop first cfg.k_init calls
    - Truncate to cfg.e_max
    - Enforce minimum length cfg.n_min
    """
    if stats is not None:
        stats.total_reports_seen += 1

    try:
        j = json.loads(data)
    except json.JSONDecodeError:
        try:
            j = json.loads(data.decode("utf-8", errors="ignore"))
        except json.JSONDecodeError:
            if stats is not None:
                stats.dropped["json_decode_error"] += 1
            return None

    behavior = j.get("behavior", {})
    procs = behavior.get("processes", [])
    if not isinstance(procs, list) or not procs:
        if stats is not None:
            stats.dropped["no_processes"] += 1
        return None

    events: list[tuple[float | None, int, int, str]] = []

    for p in procs:
        if not isinstance(p, dict):
            continue
        pid = p.get("process_id") or p.get("pid") or -1
        calls = p.get("calls") or []
        if not isinstance(calls, list):
            continue

        for idx, c in enumerate(calls):
            if not isinstance(c, dict):
                continue
            api = get_api(c)
            if not api:
                continue
            t = get_time(c)
            events.append((t, int(pid) if isinstance(pid, (int, float)) else -1, idx, api))

    if not events:
        if stats is not None:
            stats.dropped["no_events"] += 1
        return None

    if stats is not None:
        stats.total_events += len(events)
        stats.missing_ts_events += sum(1 for (t, _, _, _) in events if t is None)

    events.sort(key=lambda e: (e[0] if e[0] is not None else 1e30, e[1], e[2]))
    tokens = [api for _, _, _, api in events]

    if len(tokens) <= cfg.k_init:
        if stats is not None:
            stats.dropped["too_short_pre_kinit"] += 1
        return None

    tokens = tokens[cfg.k_init : cfg.k_init + cfg.e_max]

    if len(tokens) < cfg.n_min:
        if stats is not None:
            stats.dropped["too_short_post_filters"] += 1
        return None

    if stats is not None:
        stats.kept_traces += 1

    return tokens


def write_parquet_batch(df: pd.DataFrame, out_dir: str, source: str, batch_idx: int) -> str:
    """Write one parquet file per batch. Returns filename."""
    os.makedirs(out_dir, exist_ok=True)
    fn = os.path.join(out_dir, f"traces_batch_{source}_{batch_idx:06d}.parquet")
    df.to_parquet(fn, index=False)
    return fn


def write_manifest(out_dir: str, manifest: dict[str, Any]) -> None:
    os.makedirs(out_dir, exist_ok=True)
    fn = os.path.join(out_dir, "manifest.json")
    with open(fn, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, sort_keys=True)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--batch-size", type=int, default=100, help="Read JSON reports in batches (memory control).")
    ap.add_argument("--flush-every", type=int, default=1000, help="Flush parquet after this many reports processed.")
    ap.add_argument("--e-max", type=int, default=DEFAULT_E_MAX, help="Max tokens kept (after dropping k-init).")
    ap.add_argument("--n-min", type=int, default=DEFAULT_N_MIN, help="Min tokens required (after truncation).")
    ap.add_argument("--k-init", type=int, default=DEFAULT_K_INIT, help="Drop first k tokens (sandbox startup).")
    ap.add_argument(
        "--out-dir",
        type=str,
        default="",
        help="Output directory (default: REPO_ROOT/processed_YYYYmmdd_HHMMSS).",
    )
    ap.add_argument(
        "--benign-inner-prefix",
        type=str,
        default="",
        help="If benign reports are in a zip, restrict to this inner prefix ('' = all).",
    )
    args = ap.parse_args()

    cfg = ExtractCfg(e_max=args.e_max, n_min=args.n_min, k_init=args.k_init)

    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    out_dir = args.out_dir.strip() or os.path.join(REPO_ROOT, f"processed_{ts}")

    def progress(msg: str, done: int, total: int, every: int = 500) -> None:
        if done == total or done % every == 0:
            left = total - done
            print(f"{msg}: {done}/{total} (left {left})")

    def flush_buffer(buffer_rows: list[dict[str, Any]], out_dir_: str, source: str, batch_idx: int) -> str | None:
        if not buffer_rows:
            return None
        df_flush = pd.DataFrame(buffer_rows)
        fn = write_parquet_batch(df_flush, out_dir_, source, batch_idx)
        buffer_rows.clear()
        return fn

    print(f"Output directory: {out_dir}")
    print(f"Tokenization cfg: {asdict(cfg)}")

    manifest: dict[str, Any] = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "repo_root": REPO_ROOT,
        "out_dir": out_dir,
        "cfg": asdict(cfg),
        "inputs": {},
        "outputs": {"parquet_files": []},
        "stats": {},
        "notes": [
            "trace_id_content = sha256(raw report bytes) (stable across machines)",
            "trace_id_path = sha256(canonical absolute virtual path) (provenance only)",
        ],
    }

    avast_stats = ExtractStats()
    avast_root = os.path.join(REPO_ROOT, "data", "avast-ctu-mal")
    avast_reports = os.path.join(avast_root, "reports")
    avast_reports_zip = f"{avast_reports}.zip"
    avast_path = avast_reports if os.path.isdir(avast_reports) else avast_reports_zip

    meta_map: dict[str, str] = {}
    meta_path = os.path.join(avast_root, "labels.csv")
    if os.path.exists(meta_path):
        meta = pd.read_csv(meta_path)
        if "sha256" in meta.columns and "classification_family" in meta.columns:
            meta_map = dict(zip(meta["sha256"], meta["classification_family"], strict=False))
        else:
            print(f"[WARN] labels.csv missing expected columns: {list(meta.columns)}", file=sys.stderr)

    avast_total = count_json_reports(avast_path)
    print(f"AVAST: found {avast_total} JSON reports under {avast_path}")

    manifest["inputs"]["avast"] = {
        "path": avast_path,
        "labels_csv": meta_path if os.path.exists(meta_path) else None,
        "json_count": avast_total,
    }

    avast_done = 0
    avast_flush_idx = 0
    avast_buffer: list[dict[str, Any]] = []
    avast_missing_family_examples: list[str] = []

    try:
        avast_iter = iter_report_json_sources(avast_path)
        for batch in batched(avast_iter, args.batch_size):
            for virtual_fp, data in batch:
                avast_done += 1
                progress("AVAST processing", avast_done, avast_total, every=500)

                name = os.path.basename(virtual_fp.split("::")[-1])
                sha_from_name = os.path.splitext(name)[0]
                fam = meta_map.get(sha_from_name)
                if fam is None:
                    avast_stats.missing_family += 1
                    if len(avast_missing_family_examples) < 10:
                        avast_missing_family_examples.append(sha_from_name)

                toks = extract_tokens_from_report_bytes(data, cfg, stats=avast_stats)
                if toks is not None:
                    avast_buffer.append(
                        {
                            "trace_id_content": trace_id_content(data),
                            "trace_id_path": trace_id_path(virtual_fp),
                            "virtual_path": virtual_abs_path(virtual_fp),
                            "label": "malware",
                            "family": fam,
                            "sample_name_stem": sha_from_name,
                            "tokens": toks,
                            "tokens_str": " ".join(toks),
                            "len": len(toks),
                            "source": "avast_ctu",
                        }
                    )

                if avast_done % args.flush_every == 0:
                    avast_flush_idx += 1
                    fn = flush_buffer(avast_buffer, out_dir, "avast", avast_flush_idx)
                    if fn:
                        manifest["outputs"]["parquet_files"].append(fn)

        if avast_buffer:
            avast_flush_idx += 1
            fn = flush_buffer(avast_buffer, out_dir, "avast", avast_flush_idx)
            if fn:
                manifest["outputs"]["parquet_files"].append(fn)

    finally:
        manifest["stats"]["avast"] = avast_stats.as_dict()
        manifest["stats"]["avast"]["missing_family_examples"] = avast_missing_family_examples
        write_manifest(out_dir, manifest)
        
    benign_stats = ExtractStats()
    benign_root = os.path.join(REPO_ROOT, "data", "benign")
    benign_reports = os.path.join(benign_root, "reports")
    benign_reports_zip = f"{benign_reports}.zip"
    benign_path = benign_reports if os.path.isdir(benign_reports) else benign_reports_zip

    benign_inner_prefix = args.benign_inner_prefix  # '' means all

    benign_total = count_json_reports(benign_path, zip_inner_prefix=benign_inner_prefix)
    print(f"BENIGN: found {benign_total} JSON reports under {benign_path}::{benign_inner_prefix}/")

    manifest["inputs"]["benign"] = {
        "path": benign_path,
        "zip_inner_prefix": benign_inner_prefix,
        "json_count": benign_total,
    }

    benign_done = 0
    benign_flush_idx = 0
    benign_buffer: list[dict[str, Any]] = []

    try:
        benign_iter = iter_report_json_sources(benign_path, zip_inner_prefix=benign_inner_prefix)
        for batch in batched(benign_iter, args.batch_size):
            for virtual_fp, data in batch:
                benign_done += 1
                progress("BENIGN processing", benign_done, benign_total, every=500)

                toks = extract_tokens_from_report_bytes(data, cfg, stats=benign_stats)
                if toks is not None:
                    benign_buffer.append(
                        {
                            "trace_id_content": trace_id_content(data),
                            "trace_id_path": trace_id_path(virtual_fp),
                            "virtual_path": virtual_abs_path(virtual_fp),
                            "label": "benign",
                            "family": "goodware",
                            "sample_name_stem": os.path.splitext(os.path.basename(virtual_fp.split("::")[-1]))[0],
                            "tokens": toks,
                            "tokens_str": " ".join(toks),
                            "len": len(toks),
                            "source": "benign",
                        }
                    )

                if benign_done % args.flush_every == 0:
                    benign_flush_idx += 1
                    fn = flush_buffer(benign_buffer, out_dir, "benign", benign_flush_idx)
                    if fn:
                        manifest["outputs"]["parquet_files"].append(fn)

        if benign_buffer:
            benign_flush_idx += 1
            fn = flush_buffer(benign_buffer, out_dir, "benign", benign_flush_idx)
            if fn:
                manifest["outputs"]["parquet_files"].append(fn)

    finally:
        manifest["stats"]["benign"] = benign_stats.as_dict()
        write_manifest(out_dir, manifest)

    print(f"Done. Wrote parquet dataset to: {out_dir}")
    print("Summary:")
    print(json.dumps(manifest["stats"], indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
