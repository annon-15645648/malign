import json
import random
import hashlib
from pathlib import Path
from collections import Counter, defaultdict

import pandas as pd
from constants import REPO_ROOT

BATCH_GLOB = "traces_batch_*.parquet"
MILESTONE_GLOB = "milestones_batch_*.parquet"

SAMPLE_N = 200
RANDOM_SEED = 0

DEFAULT_E_MAX = 20_000


def pick_latest_processed_dir() -> Path:
    root = Path(REPO_ROOT)
    cands = [p for p in root.glob("processed_*") if p.is_dir()]
    if not cands:
        raise FileNotFoundError(f"No processed_* dirs under {root}")
    return max(cands, key=lambda p: p.stat().st_mtime)


def load_manifest(processed_dir: Path) -> dict | None:
    mf = processed_dir / "manifest.json"
    if mf.exists():
        with open(mf, "r", encoding="utf-8") as f:
            return json.load(f)
    return None


def iter_trace_batches(processed_dir: Path, columns=None):
    files = sorted(processed_dir.glob(BATCH_GLOB))
    if not files:
        raise FileNotFoundError(f"No parquet batches found under {processed_dir} matching {BATCH_GLOB}")
    for fp in files:
        yield fp, pd.read_parquet(fp, columns=columns)


def iter_milestone_batches(processed_dir: Path, columns=None):
    files = sorted(processed_dir.glob(MILESTONE_GLOB))
    if not files:
        return
    for fp in files:
        yield fp, pd.read_parquet(fp, columns=columns)


def token_seq_hash(tokens: list[str]) -> str:
    return hashlib.sha256("\n".join(tokens).encode("utf-8")).hexdigest()


def safe_div(a, b):
    return (a / b) if b else float("nan")


def main():
    processed_dir = pick_latest_processed_dir()
    print(f"Using processed dir: {processed_dir}")

    manifest = load_manifest(processed_dir)
    if manifest:
        cfg = manifest.get("cfg", {})
        e_max = int(cfg.get("e_max", DEFAULT_E_MAX))
        k_init = int(cfg.get("k_init", -1))
        n_min = int(cfg.get("n_min", -1))
        print(f"Found manifest.json cfg: e_max={e_max} k_init={k_init} n_min={n_min}")
    else:
        e_max = DEFAULT_E_MAX
        print(f"No manifest.json found; assuming e_max={e_max}")

    counts = Counter()
    missing_family_malware = 0

    capped_total = 0
    n_total = 0
    capped_ben = 0
    n_ben = 0
    capped_mal = 0
    n_mal = 0

    fam_capped = Counter()
    fam_total = Counter()

    seen_id = set()
    dup_trace_id_content = 0

    rng = random.Random(RANDOM_SEED)
    sample_hashes = []
    seen_seq = 0

    sample_rows = []
    seen_rows = 0

    needed_cols = ["trace_id_content", "label", "family", "len", "tokens", "source"]

    for fp, df in iter_trace_batches(processed_dir, columns=needed_cols):
        for (src, lab), k in df.groupby(["source", "label"]).size().items():
            counts[(src, lab)] += int(k)

        missing_family_malware += int(((df["label"] == "malware") & df["family"].isna()).sum())

        is_capped = df["len"] == e_max

        n_total += len(df)
        capped_total += int(is_capped.sum())

        ben_mask = df["label"] == "benign"
        mal_mask = df["label"] == "malware"

        n_ben += int(ben_mask.sum())
        capped_ben += int((is_capped & ben_mask).sum())

        n_mal += int(mal_mask.sum())
        capped_mal += int((is_capped & mal_mask).sum())

        mal_known = df[mal_mask & df["family"].notna()].copy()
        if not mal_known.empty:
            mal_known["is_capped"] = mal_known["len"] == e_max
            g = mal_known.groupby("family", sort=False)["is_capped"].agg(["sum", "count"])
            for fam, row in g.iterrows():
                fam = str(fam)
                fam_capped[fam] += int(row["sum"])
                fam_total[fam] += int(row["count"])

        for tid in df["trace_id_content"].tolist():
            if tid in seen_id:
                dup_trace_id_content += 1
            else:
                seen_id.add(tid)

        for toks, lab in zip(df["tokens"].tolist(), df["label"].tolist()):
            seen_rows += 1
            if len(sample_rows) < SAMPLE_N:
                sample_rows.append(toks)
            else:
                j = rng.randrange(seen_rows)
                if j < SAMPLE_N:
                    sample_rows[j] = toks

            h = token_seq_hash(toks)
            seen_seq += 1
            if len(sample_hashes) < SAMPLE_N:
                sample_hashes.append((h, lab))
            else:
                j2 = rng.randrange(seen_seq)
                if j2 < SAMPLE_N:
                    sample_hashes[j2] = (h, lab)

    print("\nCounts by label/source:")
    for (src, lab), k in sorted(counts.items()):
        print(f"  {src:12s} {lab:8s} {k}")

    print("\nMissing family (malware):", missing_family_malware)
    print("Duplicate trace_id_content seen across batches:", dup_trace_id_content)

    print("\nCapped-length rate overall (len==E_MAX):", safe_div(capped_total, n_total))
    print("Capped-length rate benign:", safe_div(capped_ben, n_ben))
    print("Capped-length rate malware:", safe_div(capped_mal, n_mal))

    fam_rates = {fam: safe_div(fam_capped[fam], fam_total[fam]) for fam in fam_total}
    fam_rates_sorted = sorted(fam_rates.items(), key=lambda x: x[1], reverse=True)

    print("\nCapped-length rate by family:")
    for fam, rate in fam_rates_sorted[:50]:
        print(f"  {fam:30s} {rate:.4f}  ({fam_capped[fam]}/{fam_total[fam]})")

    c = Counter()
    for toks in sample_rows:
        c.update(toks)

    print("\nApprox vocab size (sampled):", len(c))
    print("Top 20 tokens:", c.most_common(20))

    h_to_labels = defaultdict(set)
    for h, lab in sample_hashes:
        h_to_labels[h].add(lab)
    cross = [h for h, labs in h_to_labels.items() if len(labs) > 1]
    print("\nApprox identical token-sequences across labels (from reservoir):", len(cross))
    if cross:
        print("  Example hashes:", cross[:10])

    ms_files = sorted(processed_dir.glob(MILESTONE_GLOB))
    if not ms_files:
        print("\nNo milestones_batch_*.parquet found (skipping milestone coverage checks).")
        return

    print(f"\nFound {len(ms_files)} milestone batch files. Checking coverage...")
    ms_cols = ["trace_id_content", "label", "family", "t_dns", "t_c2", "t_pers", "t_priv"]

    ms_id_col = None
    ms_sample = pd.read_parquet(ms_files[0])
    if "trace_id_content" in ms_sample.columns:
        ms_id_col = "trace_id_content"
    elif "trace_id" in ms_sample.columns:
        ms_id_col = "trace_id"
    else:
        print("  [WARN] milestones have no trace_id_content/trace_id column; cannot validate coverage.")
        return

    ms_seen = set()
    ms_mal = 0
    ms_with_any = 0

    for _, msdf in iter_milestone_batches(processed_dir, columns=[ms_id_col, "label", "t_dns", "t_c2", "t_pers", "t_priv"]):
        ms_seen.update(msdf[ms_id_col].tolist())
        mal = msdf[msdf["label"] == "malware"]
        ms_mal += len(mal)
        if not mal.empty:
            any_hit = mal[["t_dns", "t_c2", "t_pers", "t_priv"]].notna().any(axis=1).sum()
            ms_with_any += int(any_hit)

    print(f"  Milestone rows total: {len(ms_seen)} (unique IDs)")
    print(f"  Malware milestone rows: {ms_mal}")
    print(f"  Malware with >=1 milestone present: {ms_with_any}  (rate={safe_div(ms_with_any, ms_mal):.3f})")

    if ms_id_col == "trace_id_content":
        missing_in_traces = len(ms_seen - seen_id)
        print(f"  Milestone IDs missing from traces (should be 0): {missing_in_traces}")

    print("\nSanity checks done.")


if __name__ == "__main__":
    main()
