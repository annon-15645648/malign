from __future__ import annotations

import argparse
import json
import pickle
from pathlib import Path
from typing import Dict, List, Iterable, Tuple
from dataclasses import dataclass
import numpy as np
import pandas as pd
import math
from constants import REPO_ROOT

@dataclass
class NgramLM:
    order: int
    k: float
    vocab: Dict[str, int]
    unk_id: int
    bos_id: int
    counts: List[Dict[Tuple[int, ...], Counter]]
    context_totals: List[Dict[Tuple[int, ...], int]]

    def logprob_next(self, history: List[int], token_id: int) -> float:
        V = len(self.vocab)
        max_h = self.order - 1
        h = history[-max_h:] if max_h > 0 else []

        for n in range(self.order, 0, -1):
            ctx_len = n - 1
            ctx = tuple(h[-ctx_len:]) if ctx_len > 0 else tuple()

            dist = self.counts[n].get(ctx)
            total = self.context_totals[n].get(ctx, 0)

            if total > 0 and dist is not None:
                c_hw = dist.get(token_id, 0)
                p = (c_hw + self.k) / (total + self.k * V)
                return math.log(p)

        return -math.log(V)

    def logprob_prefixes(self, tokens: List[int]) -> List[float]:
        hist = [self.bos_id]
        cum = 0.0
        out = []
        for tid in tokens:
            lp = self.logprob_next(hist, tid)
            cum += lp
            out.append(cum)
            hist.append(tid)
        return out

def pick_latest_processed_dir() -> Path:
    root = Path(REPO_ROOT)
    cands = [p for p in root.glob("processed_*") if p.is_dir()]
    if not cands:
        raise FileNotFoundError(f"No processed_* under {root}")
    return max(cands, key=lambda p: p.stat().st_mtime)


def load_sequences(processed_dir: Path, ids: set[str], id_col: str) -> Dict[str, List[str]]:
    remaining = set(map(str, ids))
    out: Dict[str, List[str]] = {}
    for fp in sorted(processed_dir.glob("traces_batch_*.parquet")):
        if not remaining:
            break
        df = pd.read_parquet(fp, columns=[id_col, "tokens"])
        df[id_col] = df[id_col].astype(str)
        sub = df[df[id_col].isin(remaining)]
        if sub.empty:
            continue
        for tid, toks in zip(sub[id_col].tolist(), sub["tokens"].tolist()):
            out[str(tid)] = list(toks)
        remaining -= set(sub[id_col].tolist())
    if remaining:
        print(f"[WARN] missing {len(remaining)} ids in trace batches.")
    return out


def roc_auc(y_true: np.ndarray, scores: np.ndarray) -> float:
    y_true = np.asarray(y_true, int)
    scores = np.asarray(scores, float)
    n_pos = int(np.sum(y_true == 1))
    n_neg = int(np.sum(y_true == 0))
    if n_pos == 0 or n_neg == 0:
        return float("nan")
    ranks = pd.Series(scores).rank(method="average").to_numpy()
    sum_ranks_pos = float(np.sum(ranks[y_true == 1]))
    return float((sum_ranks_pos - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


def bootstrap_auc_ci(
    y_true: np.ndarray,
    scores: np.ndarray,
    *,
    n_boot: int = 2000,
    seed: int = 0,
    ci: float = 0.95,
) -> Tuple[float, float, float]:
    rng = np.random.default_rng(seed)
    y_true = np.asarray(y_true, int)
    scores = np.asarray(scores, float)

    idx_pos = np.where(y_true == 1)[0]
    idx_neg = np.where(y_true == 0)[0]
    n_pos = len(idx_pos)
    n_neg = len(idx_neg)

    auc_hat = roc_auc(y_true, scores)
    boots = []
    for _ in range(n_boot):
        bpos = rng.choice(idx_pos, size=n_pos, replace=True)
        bneg = rng.choice(idx_neg, size=n_neg, replace=True)
        bidx = np.concatenate([bpos, bneg])
        boots.append(roc_auc(y_true[bidx], scores[bidx]))

    boots = np.asarray(boots, float)
    alpha = (1.0 - ci) / 2.0
    lo = float(np.quantile(boots, alpha))
    hi = float(np.quantile(boots, 1.0 - alpha))
    return float(auc_hat), lo, hi


def prefix_lr_series_ngram(lm_mal, lm_ben, toks: List[str]) -> List[float]:
    if len(toks) == 0:
        return []
    mal_ids = [lm_mal.vocab.get(t, lm_mal.unk_id) for t in toks]
    ben_ids = [lm_ben.vocab.get(t, lm_ben.unk_id) for t in toks]
    mal_lp = lm_mal.logprob_prefixes(mal_ids)
    ben_lp = lm_ben.logprob_prefixes(ben_ids)
    L = min(len(mal_lp), len(ben_lp))
    return [mal_lp[i] - ben_lp[i] for i in range(L)]


def score_max_cum_lr_prefix(lm_mal, lm_ben, toks: List[str], K: int) -> float:
    toksK = toks[:K] if K > 0 else toks
    s = prefix_lr_series_ngram(lm_mal, lm_ben, toksK)
    return float(max(s)) if s else float("-inf")


def score_max_avg_lr_prefix(lm_mal, lm_ben, toks: List[str], K: int) -> float:
    toksK = toks[:K] if K > 0 else toks
    s = prefix_lr_series_ngram(lm_mal, lm_ben, toksK)
    if not s:
        return float("-inf")
    return float(max(s[i] / (i + 1) for i in range(len(s))))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--processed_dir", type=str, default=None)
    ap.add_argument("--Ks", type=str, default="25,50,100,200,500,1000",
                    help="Comma-separated prefix lengths K (tokens).")
    ap.add_argument("--bootstrap", action="store_true", help="Also compute bootstrap CI for AUC.")
    ap.add_argument("--n_boot", type=int, default=2000)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    processed_dir = Path(args.processed_dir) if args.processed_dir else pick_latest_processed_dir()
    print("Using processed_dir:", processed_dir)

    Ks = [int(x.strip()) for x in args.Ks.split(",") if x.strip()]
    Ks = sorted(set(Ks))
    if any(k <= 0 for k in Ks):
        raise ValueError("All K must be positive integers.")

    splits = json.loads((processed_dir / "splits.json").read_text(encoding="utf-8"))
    id_col = splits.get("id_col", "trace_id_content")

    ben_ids = set(splits["benign"]["test"])
    mal_ids = set(splits["malware"]["test"])

    print("Loading sequences...")
    ben = load_sequences(processed_dir, ben_ids, id_col)
    mal = load_sequences(processed_dir, mal_ids, id_col)

    with open(processed_dir / "ngram_models.pkl", "rb") as f:
        obj = pickle.load(f)
    lm_ben = obj["lm_ben"]
    lm_mal = obj["lm_mal"]

    ben_list = list(ben.values())
    mal_list = list(mal.values())

    y = np.concatenate([np.zeros(len(ben_list), int), np.ones(len(mal_list), int)])

    rows = []
    for K in Ks:
        ben_sc = np.array([score_max_cum_lr_prefix(lm_mal, lm_ben, toks, K) for toks in ben_list], float)
        mal_sc = np.array([score_max_cum_lr_prefix(lm_mal, lm_ben, toks, K) for toks in mal_list], float)
        s = np.concatenate([ben_sc, mal_sc])

        auc = roc_auc(y, s)
        row = {"K": K, "variant": "max_cum_lr", "AUC": float(auc)}

        if args.bootstrap:
            a, lo, hi = bootstrap_auc_ci(y, s, n_boot=args.n_boot, seed=args.seed + K)
            row.update({"AUC_boot_lo": lo, "AUC_boot_hi": hi})

        rows.append(row)

        ben_sa = np.array([score_max_avg_lr_prefix(lm_mal, lm_ben, toks, K) for toks in ben_list], float)
        mal_sa = np.array([score_max_avg_lr_prefix(lm_mal, lm_ben, toks, K) for toks in mal_list], float)
        s2 = np.concatenate([ben_sa, mal_sa])

        auc2 = roc_auc(y, s2)
        row2 = {"K": K, "variant": "max_avg_lr", "AUC": float(auc2)}

        if args.bootstrap:
            a2, lo2, hi2 = bootstrap_auc_ci(y, s2, n_boot=args.n_boot, seed=args.seed + 10000 + K)
            row2.update({"AUC_boot_lo": lo2, "AUC_boot_hi": hi2})

        rows.append(row2)

        print(f"K={K:4d}  AUC(max_cum)={auc:.6f}  AUC(max_avg)={auc2:.6f}")

    df = pd.DataFrame(rows).sort_values(["K", "variant"])
    out = processed_dir / "posthoc"
    out.mkdir(parents=True, exist_ok=True)
    out_fp = out / "prefix_auc_ngram.csv"
    df.to_csv(out_fp, index=False)
    print("\nSaved:", out_fp)


if __name__ == "__main__":
    main()
