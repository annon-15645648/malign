from __future__ import annotations

import argparse
import hashlib
import json
import random
from collections import defaultdict
from pathlib import Path
from typing import Iterable
import pyarrow.parquet as pq

import pandas as pd

from constants import REPO_ROOT

SEED = 1337
TEST_FAMILIES = {"Emotet", "Trickbot", "njRAT"}
MAX_PER_FAMILY = 500
BENIGN_SPLIT = (0.7, 0.15, 0.15)

BATCH_GLOB = "traces_batch_*.parquet"

DEFAULT_ID_COL = "trace_id_content"
ALT_ID_COL = "trace_id"

def norm_family(x: object) -> str | None:
    """Normalize family strings for robust matching."""
    if x is None:
        return None
    if isinstance(x, float) and pd.isna(x):
        return None
    s = str(x).strip()
    return s.lower() if s else None


TEST_FAMILIES_NORM = {f.strip().lower() for f in TEST_FAMILIES}


def pick_latest_processed_dir(repo_root: str) -> Path:
    """Pick the most recently modified directory matching processed_* under REPO_ROOT."""
    root = Path(repo_root)
    candidates = [p for p in root.glob("processed_*") if p.is_dir()]
    if not candidates:
        raise FileNotFoundError(f"No processed_* directories found under {root}")
    return max(candidates, key=lambda p: p.stat().st_mtime)


def iter_batches(processed_dir: Path, columns: list[str] | None = None):
    files = sorted(processed_dir.glob(BATCH_GLOB))
    if not files:
        raise FileNotFoundError(f"No parquet batches found in {processed_dir} matching {BATCH_GLOB}")
    for fp in files:
        yield fp, pd.read_parquet(fp, columns=columns)


def detect_id_column(processed_dir: Path) -> str:
    """Pick the best available ID column (new extractor prefers trace_id_content)."""
    files = sorted(processed_dir.glob(BATCH_GLOB))
    if not files:
        raise FileNotFoundError(f"No parquet batches found in {processed_dir} matching {BATCH_GLOB}")
    cols = set(pq.ParquetFile(files[0]).schema.names)
    if DEFAULT_ID_COL in cols:
        return DEFAULT_ID_COL
    if ALT_ID_COL in cols:
        return ALT_ID_COL
    raise KeyError(f"Could not find an ID column. Expected '{DEFAULT_ID_COL}' or '{ALT_ID_COL}'. Found: {sorted(cols)}")


def cap_from_map(rng: random.Random, fam_to_ids: dict[str, list[str]], max_per_family: int) -> list[str]:
    """
    Deterministically cap per family:
    - iterate families in sorted order
    - shuffle within family using rng
    """
    out: list[str] = []
    for fam in sorted(fam_to_ids.keys()):
        ids = fam_to_ids[fam].copy()
        rng.shuffle(ids)
        out.extend(ids[:max_per_family])
    return out


def assert_disjoint(a: set[str], b: set[str], msg: str) -> None:
    inter = a.intersection(b)
    if inter:
        ex = list(sorted(inter))[:10]
        raise AssertionError(f"{msg}: overlap={len(inter)} examples={ex}")


def token_seq_hash(tokens: list[str]) -> str:
    return hashlib.sha256("\n".join(tokens).encode("utf-8")).hexdigest()


def dedup_ids_by_token_hash(processed_dir: Path, ids: list[str], *, id_col: str) -> tuple[list[str], dict[str, list[str]]]:
    """
    Given a list of IDs, return a de-duplicated list where only one ID
    is kept per unique token-sequence hash.

    Canonical representative: lexicographically smallest id within the group.

    Returns:
      - kept_ids: list[str]
      - collisions: dict[seq_hash -> list[id]] for hashes with >1 ids
    """
    id_set = set(ids)
    remaining = set(id_set)
    hash_to_ids: dict[str, list[str]] = defaultdict(list)

    for _, df in iter_batches(processed_dir, columns=[id_col, "tokens"]):
        if not remaining:
            break
        sub = df[df[id_col].isin(remaining)]
        if sub.empty:
            continue

        for tid, toks in zip(sub[id_col].tolist(), sub["tokens"].tolist()):
            h = token_seq_hash(toks)
            hash_to_ids[h].append(tid)
            remaining.discard(tid)

    if remaining:
        raise AssertionError(f"Token-dedup: {len(remaining)} ids not found in parquet batches (id_col={id_col}).")

    kept_ids: list[str] = []
    collisions: dict[str, list[str]] = {}

    for h, tids in hash_to_ids.items():
        tids_sorted = sorted(tids)
        kept_ids.append(tids_sorted[0])
        if len(tids_sorted) > 1:
            collisions[h] = tids_sorted

    return kept_ids, collisions


def dedup_guard(processed_dir: Path, split_to_ids: dict[str, set[str]], *, id_col: str) -> None:
    """
    Ensure no identical token sequence appears in >1 split.
    Hard-fails on cross-split duplicates.
    """
    all_ids: set[str] = set().union(*split_to_ids.values())
    remaining = set(all_ids)

    hash_to_splits: dict[str, set[str]] = defaultdict(set)
    hash_to_examples: dict[str, list[tuple[str, str]]] = defaultdict(list)
    split_hash_counts: dict[str, dict[str, int]] = {k: defaultdict(int) for k in split_to_ids.keys()}

    if not all_ids:
        print("Dedup guard: no IDs to check.")
        return

    print(f"Dedup guard: hashing token sequences for {len(all_ids)} traces (id_col={id_col})...")

    for _, df in iter_batches(processed_dir, columns=[id_col, "tokens"]):
        if not remaining:
            break
        sub = df[df[id_col].isin(remaining)]
        if sub.empty:
            continue

        for tid, toks in zip(sub[id_col].tolist(), sub["tokens"].tolist()):
            belonging = [s for s, ids in split_to_ids.items() if tid in ids]
            if not belonging:
                remaining.discard(tid)
                continue
            if len(belonging) > 1:
                raise AssertionError(f"Trace appears in multiple splits (ID overlap): {tid} splits={belonging}")

            split_name = belonging[0]
            h = token_seq_hash(toks)

            hash_to_splits[h].add(split_name)
            if len(hash_to_examples[h]) < 5:
                hash_to_examples[h].append((split_name, tid))
            split_hash_counts[split_name][h] += 1

            remaining.discard(tid)

    if remaining:
        raise AssertionError(f"Dedup guard: {len(remaining)} ids not found in parquet batches (id_col={id_col}).")

    cross_split = [(h, splits) for h, splits in hash_to_splits.items() if len(splits) > 1]
    if cross_split:
        examples = []
        for h, splits in cross_split[:10]:
            examples.append(
                {"hash": h, "splits": sorted(list(splits)), "examples": hash_to_examples.get(h, [])[:5]}
            )
        raise AssertionError(
            f"Dedup guard FAILED: found {len(cross_split)} token-sequence duplicates across splits.\n"
            f"Examples (up to 10): {json.dumps(examples, indent=2)}"
        )

    within_msgs = []
    for split_name, hcounts in split_hash_counts.items():
        dups = sum(1 for _, c in hcounts.items() if c > 1)
        if dups > 0:
            within_msgs.append(f"{split_name}: {dups} duplicated sequences (within-split)")
    if within_msgs:
        print("Dedup guard WARNING (within-split duplicates):")
        for m in within_msgs:
            print("  -", m)

    print("Dedup guard PASSED: no identical token sequences found across different splits.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--processed_dir",
        type=str,
        default=None,
        help="Path to processed_{timestamp} directory. If omitted, picks newest processed_* under REPO_ROOT.",
    )
    ap.add_argument(
        "--id_col",
        type=str,
        default="",
        help=f"Which ID column to use (default auto-detect; prefers {DEFAULT_ID_COL}).",
    )
    ap.add_argument(
        "--dedup_malware",
        action="store_true",
        help="Also deduplicate malware traces by token-hash (within each family) before capping/splitting.",
    )
    ap.add_argument(
        "--include_unknown_family_in_train",
        action="store_true",
        help="If set, malware with missing family will be allowed ONLY in malware train (never in test).",
    )
    ap.add_argument(
        "--no_guard",
        action="store_true",
        help="Disable cross-split dedup guard (not recommended).",
    )
    args = ap.parse_args()

    processed_dir = Path(args.processed_dir) if args.processed_dir else pick_latest_processed_dir(REPO_ROOT)
    print(f"Using processed dir: {processed_dir}")

    id_col = args.id_col.strip() or detect_id_column(processed_dir)
    print(f"Using id_col: {id_col}")

    rng = random.Random(SEED)

    mal_train_map: dict[str, list[str]] = {}
    mal_test_map: dict[str, list[str]] = {}
    mal_unknown_ids: list[str] = []
    benign_ids: list[str] = []

    train_families: set[str] = set()
    test_families: set[str] = set()

    n_mal_total = 0
    n_mal_missing_family = 0
    n_mal_with_family = 0
    n_ben_total = 0

    benign_ids_raw: list[str] = []

    needed_cols = [id_col, "label", "family"]
    for _, df in iter_batches(processed_dir, columns=needed_cols):
        mal_all = df[df["label"] == "malware"]
        if not mal_all.empty:
            n_mal_total += len(mal_all)

            fam_norm = mal_all["family"].map(norm_family)
            has_fam = fam_norm.notna()
            n_mal_missing_family += int((~has_fam).sum())

            unknown = mal_all[~has_fam]
            if not unknown.empty:
                mal_unknown_ids.extend(unknown[id_col].tolist())

            mal = mal_all[has_fam].copy()
            fam_norm = fam_norm[has_fam]
            n_mal_with_family += len(mal)

            is_test = fam_norm.isin(TEST_FAMILIES_NORM)
            mal_test = mal[is_test]
            mal_train = mal[~is_test]

            if not mal_train.empty:
                for fam, g in mal_train.groupby(mal_train["family"].map(norm_family), sort=False):
                    fam = str(fam)
                    train_families.add(fam)
                    mal_train_map.setdefault(fam, []).extend(g[id_col].tolist())

            if not mal_test.empty:
                for fam, g in mal_test.groupby(mal_test["family"].map(norm_family), sort=False):
                    fam = str(fam)
                    test_families.add(fam)
                    mal_test_map.setdefault(fam, []).extend(g[id_col].tolist())

        ben = df[df["label"] == "benign"]
        if not ben.empty:
            ids_here = ben[id_col].tolist()
            benign_ids_raw.extend(ids_here)
            n_ben_total += len(ids_here)

    if args.include_unknown_family_in_train and mal_unknown_ids:
        mal_train_map.setdefault("_unknown_family", []).extend(mal_unknown_ids)
        train_families.add("_unknown_family")
        print(f"Included {len(mal_unknown_ids)} unknown-family malware traces in TRAIN ONLY.")

    print(f"Benign IDs before token-dedup: {len(benign_ids_raw)}")
    benign_ids, benign_dups = dedup_ids_by_token_hash(processed_dir, benign_ids_raw, id_col=id_col)
    print(f"Benign IDs after token-dedup:  {len(benign_ids)}")
    print(f"Benign duplicate groups (token-identical): {len(benign_dups)}")

    dedup_map_path = processed_dir / f"benign_token_dedup_map_{id_col}.json"
    with open(dedup_map_path, "w", encoding="utf-8") as f:
        json.dump({"id_col": id_col, "n_dup_groups": len(benign_dups), "groups": benign_dups}, f, indent=2)
    print(f"Wrote: {dedup_map_path}")

    if args.dedup_malware:
        print("Deduplicating malware by token-hash within each family...")
        mal_train_dups_total = 0
        mal_test_dups_total = 0

        for fam in list(mal_train_map.keys()):
            kept, dups = dedup_ids_by_token_hash(processed_dir, mal_train_map[fam], id_col=id_col)
            mal_train_dups_total += len(dups)
            mal_train_map[fam] = kept

        for fam in list(mal_test_map.keys()):
            kept, dups = dedup_ids_by_token_hash(processed_dir, mal_test_map[fam], id_col=id_col)
            mal_test_dups_total += len(dups)
            mal_test_map[fam] = kept

        print(f"Malware duplicate groups removed (train families): {mal_train_dups_total}")
        print(f"Malware duplicate groups removed (test families):  {mal_test_dups_total}")

    train_mal_ids = cap_from_map(rng, mal_train_map, MAX_PER_FAMILY)
    test_mal_ids = cap_from_map(rng, mal_test_map, MAX_PER_FAMILY)

    rng.shuffle(benign_ids)
    n = len(benign_ids)
    n_tr = int(BENIGN_SPLIT[0] * n)
    n_va = int(BENIGN_SPLIT[1] * n)

    train_ben = benign_ids[:n_tr]
    val_ben = benign_ids[n_tr : n_tr + n_va]
    test_ben = benign_ids[n_tr + n_va :]

    set_mal_train = set(train_mal_ids)
    set_mal_test = set(test_mal_ids)
    set_ben_train = set(train_ben)
    set_ben_val = set(val_ben)
    set_ben_test = set(test_ben)

    assert_disjoint(set_ben_train, set_ben_val, "Benign train/val not disjoint")
    assert_disjoint(set_ben_train, set_ben_test, "Benign train/test not disjoint")
    assert_disjoint(set_ben_val, set_ben_test, "Benign val/test not disjoint")
    assert_disjoint(set_mal_train, set_mal_test, "Malware train/test not disjoint")

    all_ben = set_ben_train | set_ben_val | set_ben_test
    all_mal = set_mal_train | set_mal_test
    assert_disjoint(all_ben, all_mal, "Benign and malware IDs overlap")

    if not args.no_guard:
        split_to_ids = {
            "benign_train": set_ben_train,
            "benign_val": set_ben_val,
            "benign_test": set_ben_test,
            "mal_train": set_mal_train,
            "mal_test": set_mal_test,
        }
        dedup_guard(processed_dir, split_to_ids, id_col=id_col)

    splits = {
        "seed": SEED,
        "processed_dir": str(processed_dir),
        "id_col": id_col,
        "threshold_policy": {
            "type": "discrete",
            "notes": "Downstream evaluators should use discrete_* thresholds (not q_*)."
        },
        "malware": {"train": train_mal_ids, "test": test_mal_ids},
        "benign": {"train": train_ben, "val": val_ben, "test": test_ben},
        "test_families": sorted(list(TEST_FAMILIES)),
        "test_families_norm": sorted(list(TEST_FAMILIES_NORM)),
        "max_per_family": MAX_PER_FAMILY,
        "benign_split": list(BENIGN_SPLIT),
        "batch_glob": str(processed_dir / BATCH_GLOB),
        "counts": {
            "mal_total_rows_seen": n_mal_total,
            "mal_with_family": n_mal_with_family,
            "mal_missing_family": n_mal_missing_family,
            "mal_unknown_family_in_train": bool(args.include_unknown_family_in_train),
            "mal_unknown_family_ids": len(mal_unknown_ids),
            "ben_total_rows_seen": n_ben_total,
            "ben_total_raw_ids": len(benign_ids_raw),
            "ben_total_after_token_dedup": len(benign_ids),
            "mal_train_after_cap": len(train_mal_ids),
            "mal_test_after_cap": len(test_mal_ids),
            "ben_train": len(train_ben),
            "ben_val": len(val_ben),
            "ben_test": len(test_ben),
        },
        "families_norm": {
            "train": sorted(train_families),
            "test": sorted(test_families),
        },
        "token_dedup": {
            "benign_enabled": True,
            "benign_dup_groups": len(benign_dups),
            "malware_enabled": bool(args.dedup_malware),
            "method": 'sha256("\\n".join(tokens))',
            "canonical_choice": "lexicographically smallest id per hash group",
            "benign_dedup_map": dedup_map_path.name,
        },
        "dedup_guard": {
            "enabled": (not args.no_guard),
            "method": 'sha256("\\n".join(tokens)) cross-split uniqueness',
        },
    }

    out_path = processed_dir / "splits.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(splits, f, indent=2)

    print("Wrote:", out_path)
    print("Malware rows seen:", n_mal_total, "with family:", n_mal_with_family, "missing family:", n_mal_missing_family)
    print("Mal train:", len(train_mal_ids), "Mal test:", len(test_mal_ids))
    print("Ben train/val/test:", len(train_ben), len(val_ben), len(test_ben))
    print("Train families (norm):", sorted(train_families))
    print("Test families  (norm):", sorted(test_families))


if __name__ == "__main__":
    main()
