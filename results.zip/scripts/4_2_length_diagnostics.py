from __future__ import annotations

import json
import pickle
from pathlib import Path
from typing import Dict, List
from dataclasses import dataclass
import torch.nn as nn

import numpy as np
import pandas as pd
import math
from constants import REPO_ROOT

@dataclass
class NgramLM:
    order: int
    k: float
    vocab: Dict[str, int]
    unk_id: int
    bos_id: int
    counts: List[Dict[Tuple[int, ...], Counter]]
    context_totals: List[Dict[Tuple[int, ...], int]]

    def logprob_next(self, history: List[int], token_id: int) -> float:
        V = len(self.vocab)
        max_h = self.order - 1
        h = history[-max_h:] if max_h > 0 else []

        for n in range(self.order, 0, -1):
            ctx_len = n - 1
            ctx = tuple(h[-ctx_len:]) if ctx_len > 0 else tuple()

            dist = self.counts[n].get(ctx)
            total = self.context_totals[n].get(ctx, 0)

            if total > 0 and dist is not None:
                c_hw = dist.get(token_id, 0)
                p = (c_hw + self.k) / (total + self.k * V)
                return math.log(p)

        return -math.log(V)

    def logprob_prefixes(self, tokens: List[int]) -> List[float]:
        hist = [self.bos_id]
        cum = 0.0
        out = []
        for tid in tokens:
            lp = self.logprob_next(hist, tid)
            cum += lp
            out.append(cum)
            hist.append(tid)
        return out
        
class TransformerLM(nn.Module):
    def __init__(
        self,
        vocab_size: int,
        d_model: int,
        n_heads: int,
        n_layers: int,
        d_ff: int,
        dropout: float,
        max_pos: int,
        pad_id: int = 0,
    ):
        super().__init__()
        self.pad_id = pad_id
        self.tok = nn.Embedding(vocab_size, d_model, padding_idx=pad_id)
        self.pos = nn.Embedding(max_pos, d_model)
        enc_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=d_ff,
            dropout=dropout,
            batch_first=True,
            activation="gelu",
        )
        self.enc = nn.TransformerEncoder(enc_layer, num_layers=n_layers)
        self.ln = nn.LayerNorm(d_model)
        self.head = nn.Linear(d_model, vocab_size, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T = x.shape
        if T > self.pos.num_embeddings:
            raise ValueError(f"T={T} exceeds max_pos={self.pos.num_embeddings}")
        pos = torch.arange(T, device=x.device).unsqueeze(0).expand(B, T)
        h = self.tok(x) + self.pos(pos)
        causal = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), diagonal=1)
        h = self.enc(h, mask=causal)
        h = self.ln(h)
        return self.head(h)


def pick_latest_processed_dir() -> Path:
    root = Path(REPO_ROOT)
    cands = [p for p in root.glob("processed_*") if p.is_dir()]
    return max(cands, key=lambda p: p.stat().st_mtime)


def load_sequences(processed_dir: Path, ids: set[str], id_col: str) -> Dict[str, List[str]]:
    remaining = set(map(str, ids))
    out = {}
    for fp in sorted(processed_dir.glob("traces_batch_*.parquet")):
        if not remaining:
            break
        df = pd.read_parquet(fp, columns=[id_col, "tokens"])
        df[id_col] = df[id_col].astype(str)
        sub = df[df[id_col].isin(remaining)]
        for tid, toks in zip(sub[id_col], sub["tokens"]):
            out[str(tid)] = toks
        remaining -= set(sub[id_col])
    return out


def roc_auc(y_true: np.ndarray, scores: np.ndarray) -> float:
    y_true = np.asarray(y_true, int)
    scores = np.asarray(scores, float)
    n_pos = np.sum(y_true == 1)
    n_neg = np.sum(y_true == 0)

    ranks = pd.Series(scores).rank(method="average").to_numpy()
    sum_ranks_pos = np.sum(ranks[y_true == 1])
    return (sum_ranks_pos - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg)


def _as_list_tokens(seq) -> List[str]:
    if seq is None:
        return []
    if isinstance(seq, list):
        return seq
    try:
        return list(seq)
    except TypeError:
        return [str(seq)]


def prefix_lr_series_ngram(lm_mal, lm_ben, seq) -> List[float]:
    toks = _as_list_tokens(seq)
    if len(toks) == 0:
        return []

    mal_ids = [lm_mal.vocab.get(t, lm_mal.unk_id) for t in toks]
    ben_ids = [lm_ben.vocab.get(t, lm_ben.unk_id) for t in toks]

    mal_lp = lm_mal.logprob_prefixes(mal_ids)
    ben_lp = lm_ben.logprob_prefixes(ben_ids)

    L = min(len(mal_lp), len(ben_lp))
    return [mal_lp[i] - ben_lp[i] for i in range(L)]


def max_lr(lm_mal, lm_ben, seq) -> float:
    s = prefix_lr_series_ngram(lm_mal, lm_ben, seq)
    return float(max(s)) if s else float("-inf")


def max_avg_lr(lm_mal, lm_ben, seq) -> float:
    s = prefix_lr_series_ngram(lm_mal, lm_ben, seq)
    if not s:
        return float("-inf")
    return float(max(s[i] / (i + 1) for i in range(len(s))))


def main(processed_dir: Path | None = None):

    if processed_dir is None:
        processed_dir = pick_latest_processed_dir()

    print("Using:", processed_dir)

    splits = json.loads((processed_dir / "splits.json").read_text())
    id_col = splits.get("id_col", "trace_id_content")

    ben_ids = set(splits["benign"]["test"])
    mal_ids = set(splits["malware"]["test"])

    ben = load_sequences(processed_dir, ben_ids, id_col)
    mal = load_sequences(processed_dir, mal_ids, id_col)

    ben_len = np.array([len(v) for v in ben.values()])
    mal_len = np.array([len(v) for v in mal.values()])

    print("\n=== LENGTH STATS ===")
    print("Benign:",
          "min", np.min(ben_len),
          "p50", np.median(ben_len),
          "p99", np.percentile(ben_len, 99),
          "max", np.max(ben_len))

    print("Malware:",
          "min", np.min(mal_len),
          "p50", np.median(mal_len),
          "p99", np.percentile(mal_len, 99),
          "max", np.max(mal_len))

    y = np.concatenate([np.zeros(len(ben_len)), np.ones(len(mal_len))])
    scores_len = np.concatenate([ben_len, mal_len])
    auc_len = roc_auc(y, scores_len)

    print("\nLength-only AUC:", auc_len)

    with open(processed_dir / "ngram_models.pkl", "rb") as f:
        obj = pickle.load(f)
    lm_ben = obj["lm_ben"]
    lm_mal = obj["lm_mal"]

    print("\n=== SCORING NGRAM ===")

    ben_lr = np.array([max_lr(lm_mal, lm_ben, v) for v in ben.values()])
    mal_lr = np.array([max_lr(lm_mal, lm_ben, v) for v in mal.values()])

    ben_lr_avg = np.array([max_avg_lr(lm_mal, lm_ben, v) for v in ben.values()])
    mal_lr_avg = np.array([max_avg_lr(lm_mal, lm_ben, v) for v in mal.values()])

    scores_lr = np.concatenate([ben_lr, mal_lr])
    scores_lr_avg = np.concatenate([ben_lr_avg, mal_lr_avg])

    auc_lr = roc_auc(y, scores_lr)
    auc_lr_avg = roc_auc(y, scores_lr_avg)

    print("AUC max cumulative LR:", auc_lr)
    print("AUC max average LR:", auc_lr_avg)

    all_len = np.concatenate([ben_len, mal_len])
    corr = np.corrcoef(all_len, scores_lr)[0, 1]

    print("\nCorrelation(length, max LR):", corr)

    print("\nIf:")
    print("- Length AUC is high (~0.8–1.0), length is a confounder.")
    print("- Length AUC ~ 0.5, then length is irrelevant.")
    print("- Max average LR AUC stays high → model not length-driven.")
    print("- Max average LR collapses → cumulative growth dominates.")


if __name__ == "__main__":
    main()
