from __future__ import annotations

import argparse
import json
import math
import pickle
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple, Optional

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from constants import REPO_ROOT


class TransformerLM(nn.Module):
    def __init__(
        self,
        vocab_size: int,
        d_model: int,
        n_heads: int,
        n_layers: int,
        d_ff: int,
        dropout: float,
        max_pos: int,
        pad_id: int = 0,
    ):
        super().__init__()
        self.pad_id = pad_id
        self.tok = nn.Embedding(vocab_size, d_model, padding_idx=pad_id)
        self.pos = nn.Embedding(max_pos, d_model)
        enc_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=d_ff,
            dropout=dropout,
            batch_first=True,
            activation="gelu",
        )
        self.enc = nn.TransformerEncoder(enc_layer, num_layers=n_layers)
        self.ln = nn.LayerNorm(d_model)
        self.head = nn.Linear(d_model, vocab_size, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T = x.shape
        if T > self.pos.num_embeddings:
            raise ValueError(f"T={T} exceeds max_pos={self.pos.num_embeddings}")
        pos = torch.arange(T, device=x.device).unsqueeze(0).expand(B, T)
        h = self.tok(x) + self.pos(pos)
        causal = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), diagonal=1)
        h = self.enc(h, mask=causal)
        h = self.ln(h)
        return self.head(h)

@dataclass
class NgramLM:
    order: int
    k: float
    vocab: Dict[str, int]
    unk_id: int
    bos_id: int
    counts: List[Dict[Tuple[int, ...], Counter]]
    context_totals: List[Dict[Tuple[int, ...], int]]

    def logprob_next(self, history: List[int], token_id: int) -> float:
        V = len(self.vocab)
        max_h = self.order - 1
        h = history[-max_h:] if max_h > 0 else []

        for n in range(self.order, 0, -1):
            ctx_len = n - 1
            ctx = tuple(h[-ctx_len:]) if ctx_len > 0 else tuple()

            dist = self.counts[n].get(ctx)
            total = self.context_totals[n].get(ctx, 0)

            if total > 0 and dist is not None:
                c_hw = dist.get(token_id, 0)
                p = (c_hw + self.k) / (total + self.k * V)
                return math.log(p)

        return -math.log(V)

    def logprob_prefixes(self, tokens: List[int]) -> List[float]:
        hist = [self.bos_id]
        cum = 0.0
        out = []
        for tid in tokens:
            lp = self.logprob_next(hist, tid)
            cum += lp
            out.append(cum)
            hist.append(tid)
        return out


def pick_latest_processed_dir() -> Path:
    root = Path(REPO_ROOT)
    cands = [p for p in root.glob("processed_*") if p.is_dir()]
    if not cands:
        raise FileNotFoundError(f"No processed_* under {root}")
    return max(cands, key=lambda p: p.stat().st_mtime)


def load_sequences(processed_dir: Path, ids: set[str], id_col: str) -> Dict[str, List[str]]:
    remaining = set(map(str, ids))
    out: Dict[str, List[str]] = {}
    for fp in sorted(processed_dir.glob("traces_batch_*.parquet")):
        if not remaining:
            break
        df = pd.read_parquet(fp, columns=[id_col, "tokens"])
        df[id_col] = df[id_col].astype(str)
        sub = df[df[id_col].isin(remaining)]
        if sub.empty:
            continue
        for tid, toks in zip(sub[id_col].tolist(), sub["tokens"].tolist()):
            out[str(tid)] = list(toks)
        remaining -= set(sub[id_col].tolist())
    if remaining:
        print(f"[WARN] missing {len(remaining)} ids in trace batches.")
    return out


def load_meta(processed_dir: Path, ids: set[str], id_col: str) -> pd.DataFrame:
    remaining = set(map(str, ids))
    cols = [id_col, "label", "family", "source"]
    parts = []
    for fp in sorted(processed_dir.glob("traces_batch_*.parquet")):
        if not remaining:
            break
        df = pd.read_parquet(fp, columns=cols)
        df[id_col] = df[id_col].astype(str)
        sub = df[df[id_col].isin(remaining)]
        if sub.empty:
            continue
        parts.append(sub)
        remaining -= set(sub[id_col].tolist())
    if parts:
        m = pd.concat(parts, ignore_index=True)
        return m.drop_duplicates(id_col)
    return pd.DataFrame(columns=cols)


def roc_auc(y_true: np.ndarray, scores: np.ndarray) -> float:
    """Tie-safe AUC via average ranks (Mann–Whitney)."""
    y_true = np.asarray(y_true, int)
    scores = np.asarray(scores, float)
    n_pos = int(np.sum(y_true == 1))
    n_neg = int(np.sum(y_true == 0))
    if n_pos == 0 or n_neg == 0:
        return float("nan")
    ranks = pd.Series(scores).rank(method="average").to_numpy()
    sum_ranks_pos = float(np.sum(ranks[y_true == 1]))
    return float((sum_ranks_pos - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


def bootstrap_auc_ci(
    y_true: np.ndarray,
    scores: np.ndarray,
    *,
    n_boot: int = 2000,
    seed: int = 0,
    ci: float = 0.95,
) -> Tuple[float, float, float]:
    rng = np.random.default_rng(seed)
    y_true = np.asarray(y_true, int)
    scores = np.asarray(scores, float)

    idx_pos = np.where(y_true == 1)[0]
    idx_neg = np.where(y_true == 0)[0]
    n_pos = len(idx_pos)
    n_neg = len(idx_neg)
    if n_pos == 0 or n_neg == 0:
        return float("nan"), float("nan"), float("nan")

    auc_hat = roc_auc(y_true, scores)
    boots = []
    for _ in range(n_boot):
        bpos = rng.choice(idx_pos, size=n_pos, replace=True)
        bneg = rng.choice(idx_neg, size=n_neg, replace=True)
        bidx = np.concatenate([bpos, bneg])
        boots.append(roc_auc(y_true[bidx], scores[bidx]))
    boots = np.asarray(boots, float)

    alpha = (1.0 - ci) / 2.0
    lo = float(np.quantile(boots, alpha))
    hi = float(np.quantile(boots, 1.0 - alpha))
    return float(auc_hat), lo, hi


def prefix_lr_series_ngram(lm_mal, lm_ben, toks: List[str]) -> List[float]:
    if len(toks) == 0:
        return []
    mal_ids = [lm_mal.vocab.get(t, lm_mal.unk_id) for t in toks]
    ben_ids = [lm_ben.vocab.get(t, lm_ben.unk_id) for t in toks]
    mal_lp = lm_mal.logprob_prefixes(mal_ids)
    ben_lp = lm_ben.logprob_prefixes(ben_ids)
    L = min(len(mal_lp), len(ben_lp))
    return [mal_lp[i] - ben_lp[i] for i in range(L)]


def score_maxlr_ngram(processed_dir: Path, id_to_tokens: Dict[str, List[str]]) -> Dict[str, float]:
    with open(processed_dir / "ngram_models.pkl", "rb") as f:
        obj = pickle.load(f)
    lm_ben = obj["lm_ben"]
    lm_mal = obj["lm_mal"]

    out: Dict[str, float] = {}
    for tid, toks in id_to_tokens.items():
        s = prefix_lr_series_ngram(lm_mal, lm_ben, toks)
        out[tid] = float(max(s)) if s else float("-inf")
    return out


@dataclass
class TxCfg:
    pad: str = "<pad>"
    unk: str = "<unk>"
    bos: str = "<bos>"
    context: int = 256
    stride: int = 64
    max_pos: int = 512
    d_model: int = 256
    n_heads: int = 8
    n_layers: int = 4
    d_ff: int = 1024
    dropout: float = 0.1


def score_maxlr_tx(processed_dir: Path, id_to_tokens: Dict[str, List[str]]) -> Dict[str, float]:

    DEVICE = torch.device("cpu")

    thr = json.loads((processed_dir / "tx_thresholds.json").read_text(encoding="utf-8"))
    cfg = TxCfg()
    if "cfg" in thr:
        for k, v in thr["cfg"].items():
            if hasattr(cfg, k):
                setattr(cfg, k, v)

    def load_tx_model(dirpath: Path) -> Tuple[TransformerLM, Dict[str, int]]:
        vocab = json.loads((dirpath / "vocab.json").read_text(encoding="utf-8"))
        ck = torch.load(dirpath / "best.pt", map_location=DEVICE)
        pad_id = int(ck.get("pad_id", vocab.get(cfg.pad, 0)))
        model = TransformerLM(
            vocab_size=len(vocab),
            d_model=cfg.d_model,
            n_heads=cfg.n_heads,
            n_layers=cfg.n_layers,
            d_ff=cfg.d_ff,
            dropout=cfg.dropout,
            max_pos=cfg.max_pos,
            pad_id=pad_id,
        ).to(DEVICE)
        model.load_state_dict(ck["model"])
        model.eval()
        return model, vocab

    @torch.no_grad()
    def logprob_prefixes(model, vocab: Dict[str, int], seq_tokens: List[str]) -> List[float]:
        bos_id = vocab[cfg.bos]
        unk_id = vocab[cfg.unk]
        ids = [bos_id] + [vocab.get(t, unk_id) for t in seq_tokens]
        N = len(seq_tokens)
        if N == 0:
            return []
        cum = 0.0
        out = []
        t = 1
        while t <= N:
            t_end = min(N + 1, t + cfg.stride)
            a = max(0, t - cfg.context - 1)
            b = t_end
            x_ids = ids[a:b]
            y_ids = ids[a + 1 : b + 1]
            L = min(len(x_ids), len(y_ids))
            x_ids = x_ids[:L]
            y_ids = y_ids[:L]
            x = torch.tensor([x_ids], dtype=torch.long, device=DEVICE)
            y = torch.tensor([y_ids], dtype=torch.long, device=DEVICE)
            logits = model(x)
            logp = torch.log_softmax(logits, dim=-1)
            tgt_lp = logp.gather(-1, y.unsqueeze(-1)).squeeze(-1).squeeze(0)
            for j in range(t, t_end):
                loc = j - a - 1
                if 0 <= loc < len(tgt_lp):
                    cum += float(tgt_lp[loc].item())
                    out.append(cum)
            t = t_end
        return out

    model_ben, vocab_ben = load_tx_model(processed_dir / "tx_models" / "benign")
    model_mal, vocab_mal = load_tx_model(processed_dir / "tx_models" / "malware")
    if vocab_ben != vocab_mal:
        raise AssertionError("TX vocabs differ between benign/malware models.")
    vocab = vocab_ben

    out: Dict[str, float] = {}
    for tid, toks in id_to_tokens.items():
        mal_lp = logprob_prefixes(model_mal, vocab, toks)
        ben_lp = logprob_prefixes(model_ben, vocab, toks)
        L = min(len(mal_lp), len(ben_lp))
        if L == 0:
            out[tid] = float("-inf")
        else:
            out[tid] = float(max(mal_lp[i] - ben_lp[i] for i in range(L)))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--processed_dir", type=str, default=None)
    ap.add_argument("--model", choices=["ngram", "tx", "both"], default="both")
    ap.add_argument("--bootstrap", action="store_true")
    ap.add_argument("--n_boot", type=int, default=2000)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    processed_dir = Path(args.processed_dir) if args.processed_dir else pick_latest_processed_dir()
    splits = json.loads((processed_dir / "splits.json").read_text(encoding="utf-8"))
    id_col = splits.get("id_col", "trace_id_content")

    ben_ids = set(splits["benign"]["test"])
    mal_ids = set(splits["malware"]["test"])
    all_ids = ben_ids | mal_ids

    print("Using:", processed_dir)
    print("Loading meta...")
    meta = load_meta(processed_dir, all_ids, id_col=id_col)
    meta = meta.set_index(id_col)

    print("Loading sequences...")
    ben_tokens = load_sequences(processed_dir, ben_ids, id_col=id_col)
    mal_tokens = load_sequences(processed_dir, mal_ids, id_col=id_col)

    mal_fam = meta.loc[list(mal_ids), "family"].fillna("UNKNOWN").astype(str)
    families = sorted(mal_fam.unique().tolist())

    out_dir = processed_dir / "posthoc"
    out_dir.mkdir(parents=True, exist_ok=True)

    def compute_family_table(scores: Dict[str, float], model_name: str) -> pd.DataFrame:
        ben_scores = np.array([scores[str(tid)] for tid in ben_ids], float)

        rows = []
        for fam in families:
            fam_ids = mal_fam[mal_fam == fam].index.astype(str).tolist()
            mal_scores = np.array([scores[tid] for tid in fam_ids], float)

            y = np.concatenate([np.zeros(len(ben_scores), int), np.ones(len(mal_scores), int)])
            s = np.concatenate([ben_scores, mal_scores])
            auc = roc_auc(y, s)
            row = {
                "model": model_name,
                "family": fam,
                "n_ben": int(len(ben_scores)),
                "n_mal": int(len(mal_scores)),
                "AUC": float(auc),
            }
            if args.bootstrap:
                a, lo, hi = bootstrap_auc_ci(y, s, n_boot=args.n_boot, seed=args.seed + hash((model_name, fam)) % 100000)
                row.update({"AUC_boot_lo": lo, "AUC_boot_hi": hi})
            rows.append(row)

        all_mal_scores = np.array([scores[str(tid)] for tid in mal_ids], float)
        y_all = np.concatenate([np.zeros(len(ben_scores), int), np.ones(len(all_mal_scores), int)])
        s_all = np.concatenate([ben_scores, all_mal_scores])
        auc_all = roc_auc(y_all, s_all)
        rows.append({
            "model": model_name,
            "family": "__OVERALL__",
            "n_ben": int(len(ben_scores)),
            "n_mal": int(len(all_mal_scores)),
            "AUC": float(auc_all),
        })

        return pd.DataFrame(rows).sort_values(["family"])

    tables = []

    if args.model in ["ngram", "both"]:
        print("\nScoring n-gram...")
        scores_ng = score_maxlr_ngram(processed_dir, {**ben_tokens, **mal_tokens})
        df_ng = compute_family_table(scores_ng, "ngram")
        df_ng.to_csv(out_dir / "per_family_auc_ngram.csv", index=False)
        print("Saved:", out_dir / "per_family_auc_ngram.csv")
        tables.append(df_ng)

    if args.model in ["tx", "both"]:
        print("\nScoring TX...")
        scores_tx = score_maxlr_tx(processed_dir, {**ben_tokens, **mal_tokens})
        df_tx = compute_family_table(scores_tx, "tx")
        df_tx.to_csv(out_dir / "per_family_auc_tx.csv", index=False)
        print("Saved:", out_dir / "per_family_auc_tx.csv")
        tables.append(df_tx)

    if tables:
        df_all = pd.concat(tables, ignore_index=True)
        df_all.to_csv(out_dir / "per_family_auc_all.csv", index=False)
        print("Saved:", out_dir / "per_family_auc_all.csv")


if __name__ == "__main__":
    main()
