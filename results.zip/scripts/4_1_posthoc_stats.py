from __future__ import annotations

import argparse
import json
import math
import os
import pickle
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import torch
import torch.nn as nn

from constants import REPO_ROOT

import torch

@dataclass
class NgramLM:
    order: int
    k: float
    vocab: Dict[str, int]
    unk_id: int
    bos_id: int
    counts: List[Dict[Tuple[int, ...], Counter]]
    context_totals: List[Dict[Tuple[int, ...], int]]

    def logprob_next(self, history: List[int], token_id: int) -> float:
        V = len(self.vocab)
        max_h = self.order - 1
        h = history[-max_h:] if max_h > 0 else []

        for n in range(self.order, 0, -1):
            ctx_len = n - 1
            ctx = tuple(h[-ctx_len:]) if ctx_len > 0 else tuple()

            dist = self.counts[n].get(ctx)
            total = self.context_totals[n].get(ctx, 0)

            if total > 0 and dist is not None:
                c_hw = dist.get(token_id, 0)
                p = (c_hw + self.k) / (total + self.k * V)
                return math.log(p)

        return -math.log(V)

    def logprob_prefixes(self, tokens: List[int]) -> List[float]:
        hist = [self.bos_id]
        cum = 0.0
        out = []
        for tid in tokens:
            lp = self.logprob_next(hist, tid)
            cum += lp
            out.append(cum)
            hist.append(tid)
        return out
        
class TransformerLM(nn.Module):
    def __init__(
        self,
        vocab_size: int,
        d_model: int,
        n_heads: int,
        n_layers: int,
        d_ff: int,
        dropout: float,
        max_pos: int,
        pad_id: int = 0,
    ):
        super().__init__()
        self.pad_id = pad_id
        self.tok = nn.Embedding(vocab_size, d_model, padding_idx=pad_id)
        self.pos = nn.Embedding(max_pos, d_model)
        enc_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=d_ff,
            dropout=dropout,
            batch_first=True,
            activation="gelu",
        )
        self.enc = nn.TransformerEncoder(enc_layer, num_layers=n_layers)
        self.ln = nn.LayerNorm(d_model)
        self.head = nn.Linear(d_model, vocab_size, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T = x.shape
        if T > self.pos.num_embeddings:
            raise ValueError(f"T={T} exceeds max_pos={self.pos.num_embeddings}")
        pos = torch.arange(T, device=x.device).unsqueeze(0).expand(B, T)
        h = self.tok(x) + self.pos(pos)
        causal = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), diagonal=1)
        h = self.enc(h, mask=causal)
        h = self.ln(h)
        return self.head(h)


def pick_latest_processed_dir() -> Path:
    root = Path(REPO_ROOT)
    cands = [p for p in root.glob("processed_*") if p.is_dir()]
    if not cands:
        raise FileNotFoundError(f"No processed_* directories under {root}")
    return max(cands, key=lambda p: p.stat().st_mtime)


def iter_parquet_files(dirpath: Path, pattern: str):
    files = sorted(dirpath.glob(pattern))
    if not files:
        raise FileNotFoundError(f"No parquet files found in {dirpath} matching {pattern}")
    for fp in files:
        yield fp


def load_sequences_only(processed_dir: Path, ids: set[str], *, id_col: str) -> Dict[str, List[str]]:
    remaining = set(map(str, ids))
    out: Dict[str, List[str]] = {}
    for fp in iter_parquet_files(processed_dir, "traces_batch_*.parquet"):
        if not remaining:
            break
        df = pd.read_parquet(fp, columns=[id_col, "tokens"])
        df[id_col] = df[id_col].astype(str)
        sub = df[df[id_col].isin(remaining)]
        if sub.empty:
            continue
        for tid, toks in zip(sub[id_col].tolist(), sub["tokens"].tolist()):
            out[str(tid)] = toks
        remaining.difference_update(set(sub[id_col].tolist()))
    if remaining:
        print(f"[WARN] missing {len(remaining)} ids in trace batches.")
    return out


def load_meta(processed_dir: Path, ids: set[str], *, id_col: str) -> pd.DataFrame:
    remaining = set(map(str, ids))
    parts = []
    cols = [id_col, "label", "family", "source"]
    for fp in iter_parquet_files(processed_dir, "traces_batch_*.parquet"):
        if not remaining:
            break
        df = pd.read_parquet(fp, columns=cols)
        df[id_col] = df[id_col].astype(str)
        sub = df[df[id_col].isin(remaining)]
        if sub.empty:
            continue
        parts.append(sub[cols])
        remaining.difference_update(set(sub[id_col].tolist()))
    if parts:
        m = pd.concat(parts, ignore_index=True)
        return m.drop_duplicates(id_col)
    return pd.DataFrame({id_col: list(map(str, ids)), "label": None, "family": None, "source": None})


@dataclass
class Taus:
    tau_0_1: float
    tau_1_0: float
    tau_5_0: float
    tau_10_0: float


def load_ngram_taus(processed_dir: Path) -> Taus:
    fp = processed_dir / "ngram_thresholds.json"
    if not fp.exists():
        raise FileNotFoundError(f"Missing {fp} (run 1_1_ngram_lr_train_threshold.py first)")
    thr = json.loads(fp.read_text(encoding="utf-8"))
    return Taus(
        tau_0_1=float(thr["tau_0_1"]),
        tau_1_0=float(thr["tau_1_0"]),
        tau_5_0=float(thr["tau_5_0"]),
        tau_10_0=float(thr["tau_10_0"]),
    )


def load_tx_taus(processed_dir: Path) -> Taus:
    fp = processed_dir / "tx_thresholds.json"
    if not fp.exists():
        raise FileNotFoundError(f"Missing {fp} (run 2_1_tx_lm_train_threshold.py first)")
    thr = json.loads(fp.read_text(encoding="utf-8"))
    return Taus(
        tau_0_1=float(thr["tau_0_1"]),
        tau_1_0=float(thr["tau_1_0"]),
        tau_5_0=float(thr["tau_5_0"]),
        tau_10_0=float(thr["tau_10_0"]),
    )


def roc_auc_from_scores(y_true: np.ndarray, scores: np.ndarray) -> float:
    """
    AUC via Mann–Whitney U with average ranks (handles ties).
    y_true: 1 for malware, 0 for benign
    """
    y_true = np.asarray(y_true, dtype=int)
    scores = np.asarray(scores, dtype=float)
    n_pos = int(np.sum(y_true == 1))
    n_neg = int(np.sum(y_true == 0))
    if n_pos == 0 or n_neg == 0:
        return float("nan")

    ranks = pd.Series(scores).rank(method="average").to_numpy()
    sum_ranks_pos = float(np.sum(ranks[y_true == 1]))
    auc = (sum_ranks_pos - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg)
    return float(auc)


def bootstrap_auc_ci(
    y_true: np.ndarray,
    scores: np.ndarray,
    *,
    n_boot: int = 2000,
    seed: int = 0,
    ci: float = 0.95,
) -> Tuple[float, float, float]:
    """
    Stratified bootstrap (resample benign and malware separately) + percentile CI.
    Returns (auc_hat, lo, hi).
    """
    rng = np.random.default_rng(seed)
    y_true = np.asarray(y_true, dtype=int)
    scores = np.asarray(scores, dtype=float)

    idx_pos = np.where(y_true == 1)[0]
    idx_neg = np.where(y_true == 0)[0]
    n_pos = len(idx_pos)
    n_neg = len(idx_neg)

    auc_hat = roc_auc_from_scores(y_true, scores)
    boots = []
    for _ in range(n_boot):
        bpos = rng.choice(idx_pos, size=n_pos, replace=True)
        bneg = rng.choice(idx_neg, size=n_neg, replace=True)
        bidx = np.concatenate([bpos, bneg])
        boots.append(roc_auc_from_scores(y_true[bidx], scores[bidx]))
    boots = np.asarray(boots, float)
    alpha = (1.0 - ci) / 2.0
    lo = float(np.quantile(boots, alpha))
    hi = float(np.quantile(boots, 1.0 - alpha))
    return auc_hat, lo, hi


def wilson_ci(phat: float, n: int, z: float = 1.96) -> Tuple[float, float]:
    if n <= 0:
        return float("nan"), float("nan")
    denom = 1.0 + (z * z) / n
    center = (phat + (z * z) / (2.0 * n)) / denom
    half = (z / denom) * math.sqrt((phat * (1.0 - phat) / n) + (z * z) / (4.0 * n * n))
    return max(0.0, center - half), min(1.0, center + half)


def bootstrap_rate_ci(
    scores: np.ndarray,
    tau: float,
    *,
    n_boot: int = 5000,
    seed: int = 0,
    ci: float = 0.95,
) -> Tuple[float, float, float]:
    rng = np.random.default_rng(seed)
    scores = np.asarray(scores, dtype=float)
    n = len(scores)
    hat = float(np.mean(scores >= tau))
    boots = []
    for _ in range(n_boot):
        b = rng.choice(scores, size=n, replace=True)
        boots.append(float(np.mean(b >= tau)))
    boots = np.asarray(boots, float)
    alpha = (1.0 - ci) / 2.0
    lo = float(np.quantile(boots, alpha))
    hi = float(np.quantile(boots, 1.0 - alpha))
    return hat, lo, hi


def plot_score_hist(
    ben_scores: np.ndarray,
    mal_scores: np.ndarray,
    *,
    title: str,
    out_png: Path,
    bins: int = 80,
    clip_lo_pct: float = 0.1,
    clip_hi_pct: float = 99.9,
    log1p: bool = True,
) -> None:
    ben = np.asarray(ben_scores, float)
    mal = np.asarray(mal_scores, float)

    ben = ben[np.isfinite(ben)]
    mal = mal[np.isfinite(mal)]

    if ben.size == 0 or mal.size == 0:
        print(f"[WARN] plot_score_hist: no finite scores for {title}")
        return

    allv = np.concatenate([ben, mal])
    lo = float(np.percentile(allv, clip_lo_pct))
    hi = float(np.percentile(allv, clip_hi_pct))
    if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
        lo, hi = float(np.min(allv)), float(np.max(allv))

    ben_c = np.clip(ben, lo, hi)
    mal_c = np.clip(mal, lo, hi)

    if log1p:
        ben_c = np.log1p(np.maximum(ben_c, 0.0))
        mal_c = np.log1p(np.maximum(mal_c, 0.0))
        xlabel = "log(1 + max LR score)"
    else:
        xlabel = "max LR score over prefixes"

    plt.figure()
    plt.hist(ben_c, bins=bins, density=True, alpha=0.6, label="benign")
    plt.hist(mal_c, bins=bins, density=True, alpha=0.6, label="malware")
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel("density")
    plt.legend()
    plt.tight_layout()
    out_png.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out_png, dpi=160)
    plt.close()

def prefix_lr_series_ngram(lm_mal, lm_ben, seq: List[str]) -> List[float]:
    if len(seq) == 0:
        return []
    mal_ids = [lm_mal.vocab.get(t, lm_mal.unk_id) for t in seq]
    ben_ids = [lm_ben.vocab.get(t, lm_ben.unk_id) for t in seq]
    mal_lp = lm_mal.logprob_prefixes(mal_ids)
    ben_lp = lm_ben.logprob_prefixes(ben_ids)
    L = min(len(mal_lp), len(ben_lp))
    return [mal_lp[i] - ben_lp[i] for i in range(L)]


def max_lr_score_over_prefixes_ngram(lm_mal, lm_ben, seq: List[str]) -> float:
    s = prefix_lr_series_ngram(lm_mal, lm_ben, seq)
    return max(s) if s else float("-inf")


def score_maxlr_ngram(
    processed_dir: Path,
    id_to_tokens: Dict[str, List[str]],
) -> np.ndarray:
    with open(processed_dir / "ngram_models.pkl", "rb") as f:
        obj = pickle.load(f)
    lm_ben = obj["lm_ben"]
    lm_mal = obj["lm_mal"]

    out = []
    for tid, toks in id_to_tokens.items():
        out.append(max_lr_score_over_prefixes_ngram(lm_mal, lm_ben, toks))
    return np.asarray(out, float)


DEVICE = torch.device("cpu")


@dataclass
class TxCfg:
    pad: str = "<pad>"
    unk: str = "<unk>"
    bos: str = "<bos>"
    context: int = 256
    stride: int = 64
    max_pos: int = 512
    d_model: int = 256
    n_heads: int = 8
    n_layers: int = 4
    d_ff: int = 1024
    dropout: float = 0.1


@torch.no_grad()
def logprob_prefixes_tx_contextcarry(
    model: TransformerLM,
    vocab: Dict[str, int],
    seq_tokens: List[str],
    *,
    context: int,
    stride: int,
    bos: str,
    unk: str,
) -> List[float]:
    model.eval()
    bos_id = vocab[bos]
    unk_id = vocab[unk]

    ids = [bos_id] + [vocab.get(t, unk_id) for t in seq_tokens]
    N = len(seq_tokens)
    if N == 0:
        return []

    cum = 0.0
    out: List[float] = []

    t = 1
    while t <= N:
        t_end = min(N + 1, t + stride)
        a = max(0, t - context - 1)
        b = t_end

        x_ids = ids[a:b]
        y_ids = ids[a + 1 : b + 1]
        L = min(len(x_ids), len(y_ids))
        x_ids = x_ids[:L]
        y_ids = y_ids[:L]

        x = torch.tensor([x_ids], dtype=torch.long, device=DEVICE)
        y = torch.tensor([y_ids], dtype=torch.long, device=DEVICE)

        logits = model(x)
        logp = torch.log_softmax(logits, dim=-1)
        tgt_lp = logp.gather(-1, y.unsqueeze(-1)).squeeze(-1).squeeze(0)

        for j in range(t, t_end):
            loc = (j - a - 1)
            if 0 <= loc < len(tgt_lp):
                cum += float(tgt_lp[loc].item())
                out.append(cum)

        t = t_end

    return out


@torch.no_grad()
def prefix_lr_series_tx(
    model_mal: TransformerLM,
    model_ben: TransformerLM,
    vocab: Dict[str, int],
    seq: List[str],
    cfg: TxCfg,
) -> List[float]:
    mal_lp = logprob_prefixes_tx_contextcarry(
        model_mal, vocab, seq, context=cfg.context, stride=cfg.stride, bos=cfg.bos, unk=cfg.unk
    )
    ben_lp = logprob_prefixes_tx_contextcarry(
        model_ben, vocab, seq, context=cfg.context, stride=cfg.stride, bos=cfg.bos, unk=cfg.unk
    )
    L = min(len(mal_lp), len(ben_lp))
    return [mal_lp[i] - ben_lp[i] for i in range(L)]


def load_tx_model(dirpath: Path, cfg: TxCfg) -> Tuple[TransformerLM, Dict[str, int]]:
    vocab = json.loads((dirpath / "vocab.json").read_text(encoding="utf-8"))
    ck = torch.load(dirpath / "best.pt", map_location=DEVICE)
    pad_id = int(ck.get("pad_id", vocab.get(cfg.pad, 0)))
    model = TransformerLM(
        vocab_size=len(vocab),
        d_model=cfg.d_model,
        n_heads=cfg.n_heads,
        n_layers=cfg.n_layers,
        d_ff=cfg.d_ff,
        dropout=cfg.dropout,
        max_pos=cfg.max_pos,
        pad_id=pad_id,
    ).to(DEVICE)
    model.load_state_dict(ck["model"])
    model.eval()
    return model, vocab


def score_maxlr_tx(
    processed_dir: Path,
    id_to_tokens: Dict[str, List[str]],
) -> np.ndarray:
    thr = json.loads((processed_dir / "tx_thresholds.json").read_text(encoding="utf-8"))
    cfg = TxCfg()
    if "cfg" in thr:
        for k, v in thr["cfg"].items():
            if hasattr(cfg, k):
                setattr(cfg, k, v)

    model_ben, vocab_ben = load_tx_model(processed_dir / "tx_models" / "benign", cfg)
    model_mal, vocab_mal = load_tx_model(processed_dir / "tx_models" / "malware", cfg)
    if vocab_ben != vocab_mal:
        raise AssertionError("TX vocabs differ between benign/malware models. Retrain with shared vocab.")
    vocab = vocab_ben

    out = []
    for tid, toks in id_to_tokens.items():
        series = prefix_lr_series_tx(model_mal, model_ben, vocab, toks, cfg)
        out.append(max(series) if series else float("-inf"))
    return np.asarray(out, float)


def fit_slope(x: np.ndarray, y: np.ndarray) -> float:
    """Least-squares slope for y = a + b x."""
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    if len(x) < 2:
        return float("nan")
    xv = x - x.mean()
    denom = float(np.sum(xv * xv))
    if denom <= 0:
        return float("nan")
    b = float(np.sum(xv * (y - y.mean())) / denom)
    return b


def aurc(x: np.ndarray, y: np.ndarray) -> float:
    """Area under robustness curve using trapezoid rule normalized by max x."""
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    if len(x) < 2:
        return float("nan")
    order = np.argsort(x)
    x = x[order]
    y = y[order]
    area = float(np.trapezoid(y, x))
    return area / float(x[-1] - x[0] + 1e-12)


def paired_permutation_pvalue(diffs: np.ndarray, *, n_perm: int = 20000, seed: int = 0) -> float:
    """
    Paired sign-flip permutation test for H0: mean(diffs)=0.
    """
    rng = np.random.default_rng(seed)
    diffs = np.asarray(diffs, float)
    diffs = diffs[~np.isnan(diffs)]
    if len(diffs) == 0:
        return float("nan")
    obs = float(np.mean(diffs))
    count = 0
    for _ in range(n_perm):
        signs = rng.choice([-1.0, 1.0], size=len(diffs), replace=True)
        perm = float(np.mean(diffs * signs))
        if abs(perm) >= abs(obs):
            count += 1
    return (count + 1) / float(n_perm + 1)


def compute_robustness_stats(
    processed_dir: Path,
    *,
    n_perm: int = 20000,
    seed: int = 0,
) -> pd.DataFrame:
    """
    Reads fig3_robustness_{ngram,tx}.csv and compares:
      - slope of TPR vs p_del_target per seed/mode/tau
      - AURC of TPR vs p_del_target per seed/mode/tau

    Outputs a tidy table with effect sizes and p-values (paired by seed when possible).
    """
    fp_ng = processed_dir / "fig3_robustness_ngram.csv"
    fp_tx = processed_dir / "fig3_robustness_tx.csv"
    if not fp_ng.exists() or not fp_tx.exists():
        raise FileNotFoundError(f"Missing robustness CSV(s): {fp_ng.exists()=}, {fp_tx.exists()=}")

    ng = pd.read_csv(fp_ng)
    tx = pd.read_csv(fp_tx)

    need = {"mode", "p_del_target", "tau", "TPR_test", "seed"}
    for name, df in [("ngram", ng), ("tx", tx)]:
        if not need.issubset(df.columns):
            raise ValueError(f"{name} robustness CSV missing required columns. Need {sorted(need)}")

    rows = []
    def per_seed_metrics(df: pd.DataFrame, model_name: str) -> pd.DataFrame:
        out = []
        for (mode, tau, seed_), g in df.groupby(["mode", "tau", "seed"], as_index=False):
            x = g["p_del_target"].to_numpy(float)
            y = g["TPR_test"].to_numpy(float)
            out.append({
                "model": model_name,
                "mode": mode,
                "tau": tau,
                "seed": int(seed_),
                "slope_tpr_vs_pdel": fit_slope(x, y),
                "aurc_tpr": aurc(x, y),
            })
        return pd.DataFrame(out)

    ngm = per_seed_metrics(ng, "ngram")
    txm = per_seed_metrics(tx, "tx")

    m = ngm.merge(txm, on=["mode", "tau", "seed"], suffixes=("_ngram", "_tx"))

    for (mode, tau), g in m.groupby(["mode", "tau"]):
        slope_diff = (g["slope_tpr_vs_pdel_tx"] - g["slope_tpr_vs_pdel_ngram"]).to_numpy(float)
        aurc_diff = (g["aurc_tpr_tx"] - g["aurc_tpr_ngram"]).to_numpy(float)

        rows.append({
            "mode": mode,
            "tau": tau,
            "n_seeds_paired": int(len(g)),
            "mean_slope_ngram": float(np.mean(g["slope_tpr_vs_pdel_ngram"])),
            "mean_slope_tx": float(np.mean(g["slope_tpr_vs_pdel_tx"])),
            "mean_slope_diff_tx_minus_ngram": float(np.mean(slope_diff)),
            "p_perm_slope_diff": paired_permutation_pvalue(slope_diff, n_perm=n_perm, seed=seed),

            "mean_aurc_ngram": float(np.mean(g["aurc_tpr_ngram"])),
            "mean_aurc_tx": float(np.mean(g["aurc_tpr_tx"])),
            "mean_aurc_diff_tx_minus_ngram": float(np.mean(aurc_diff)),
            "p_perm_aurc_diff": paired_permutation_pvalue(aurc_diff, n_perm=n_perm, seed=seed + 1),
        })

    return pd.DataFrame(rows).sort_values(["mode", "tau"])



def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--processed_dir", type=str, default=None, help="processed_* directory (default: newest)")
    ap.add_argument("--auc_boot", type=int, default=2000, help="bootstrap replicates for AUC CI")
    ap.add_argument("--fpr_boot", type=int, default=5000, help="bootstrap replicates for FPR CI")
    ap.add_argument("--perm", type=int, default=20000, help="permutations for robustness paired test")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    processed_dir = Path(args.processed_dir) if args.processed_dir else pick_latest_processed_dir()
    print("Using processed_dir:", processed_dir)

    splits = json.loads((processed_dir / "splits.json").read_text(encoding="utf-8"))
    id_col = splits.get("id_col", "trace_id_content")
    print("id_col:", id_col)

    ben_test_ids = set(splits["benign"]["test"])
    mal_test_ids = set(splits["malware"]["test"])
    eval_ids = ben_test_ids | mal_test_ids

    print("Loading sequences...")
    ben_test = load_sequences_only(processed_dir, ben_test_ids, id_col=id_col)
    mal_test = load_sequences_only(processed_dir, mal_test_ids, id_col=id_col)

    print("Loading meta...")
    meta = load_meta(processed_dir, eval_ids, id_col=id_col)

    out_dir = processed_dir / "posthoc"
    out_dir.mkdir(parents=True, exist_ok=True)

    print("\n=== NGRAM: scoring ===")
    ng_taus = load_ngram_taus(processed_dir)
    benS_ng = score_maxlr_ngram(processed_dir, ben_test)
    malS_ng = score_maxlr_ngram(processed_dir, mal_test)

    def summarize_scores(name, arr):
        arr = np.asarray(arr, float)
        finite = arr[np.isfinite(arr)]
        print(f"{name}: n={len(arr)} finite={len(finite)} "
            f"min={np.min(finite):.3g} p50={np.median(finite):.3g} "
            f"p99={np.percentile(finite,99):.3g} max={np.max(finite):.3g}")

    summarize_scores("ngram benign", benS_ng)
    summarize_scores("ngram malware", malS_ng)

    plot_score_hist(
        benS_ng, malS_ng,
        title="N-gram LR: score distribution (benign vs malware)",
        out_png=out_dir / "dist_ngram.png",
    )

    y = np.concatenate([np.zeros_like(benS_ng, int), np.ones_like(malS_ng, int)])
    s = np.concatenate([benS_ng, malS_ng])
    auc_ng, auc_ng_lo, auc_ng_hi = bootstrap_auc_ci(y, s, n_boot=args.auc_boot, seed=args.seed)

    fpr_rows = []
    for name, tau in [("tau_0_1", ng_taus.tau_0_1), ("tau_1_0", ng_taus.tau_1_0), ("tau_5_0", ng_taus.tau_5_0), ("tau_10_0", ng_taus.tau_10_0)]:
        hat, lo, hi = bootstrap_rate_ci(benS_ng, tau, n_boot=args.fpr_boot, seed=args.seed)
        wil_lo, wil_hi = wilson_ci(hat, len(benS_ng))
        fpr_rows.append({
            "model": "ngram",
            "tau": name,
            "threshold": float(tau),
            "FPR_hat": hat,
            "FPR_boot_lo": lo,
            "FPR_boot_hi": hi,
            "FPR_wilson_lo": wil_lo,
            "FPR_wilson_hi": wil_hi,
            "n_ben_test": int(len(benS_ng)),
        })

    print("\n=== TX: scoring ===")
    tx_taus = load_tx_taus(processed_dir)
    benS_tx = score_maxlr_tx(processed_dir, ben_test)
    malS_tx = score_maxlr_tx(processed_dir, mal_test)

    summarize_scores("tx benign", benS_tx)
    summarize_scores("tx malware", malS_tx)

    plot_score_hist(
        benS_tx, malS_tx,
        title="Transformer LR: score distribution (benign vs malware)",
        out_png=out_dir / "dist_tx.png",
    )

    y2 = np.concatenate([np.zeros_like(benS_tx, int), np.ones_like(malS_tx, int)])
    s2 = np.concatenate([benS_tx, malS_tx])
    auc_tx, auc_tx_lo, auc_tx_hi = bootstrap_auc_ci(y2, s2, n_boot=args.auc_boot, seed=args.seed + 10)

    for name, tau in [("tau_0_1", tx_taus.tau_0_1), ("tau_1_0", tx_taus.tau_1_0), ("tau_5_0", tx_taus.tau_5_0), ("tau_10_0", tx_taus.tau_10_0)]:
        hat, lo, hi = bootstrap_rate_ci(benS_tx, tau, n_boot=args.fpr_boot, seed=args.seed + 10)
        wil_lo, wil_hi = wilson_ci(hat, len(benS_tx))
        fpr_rows.append({
            "model": "tx",
            "tau": name,
            "threshold": float(tau),
            "FPR_hat": hat,
            "FPR_boot_lo": lo,
            "FPR_boot_hi": hi,
            "FPR_wilson_lo": wil_lo,
            "FPR_wilson_hi": wil_hi,
            "n_ben_test": int(len(benS_tx)),
        })

    fpr_df = pd.DataFrame(fpr_rows)
    fpr_df.to_csv(out_dir / "fpr_bootstrap_ci.csv", index=False)

    auc_df = pd.DataFrame([
        {"model": "ngram", "AUC": auc_ng, "AUC_boot_lo": auc_ng_lo, "AUC_boot_hi": auc_ng_hi},
        {"model": "tx", "AUC": auc_tx, "AUC_boot_lo": auc_tx_lo, "AUC_boot_hi": auc_tx_hi},
    ])
    auc_df.to_csv(out_dir / "auc_bootstrap_ci.csv", index=False)

    print("\n=== Robustness: slope/AURC comparison ===")
    rob = compute_robustness_stats(processed_dir, n_perm=args.perm, seed=args.seed)
    rob.to_csv(out_dir / "robustness_slope_aurc_tests.csv", index=False)

    print("\nSaved outputs in:", out_dir)
    print("\nAUC summary:")
    print(auc_df.to_string(index=False))

    print("\nFPR bootstrap/Wilson summary:")
    print(fpr_df.to_string(index=False))

    print("\nRobustness paired tests (TX better => AURC_diff>0 and slope_diff>0):")
    print(rob.to_string(index=False))


if __name__ == "__main__":
    main()
