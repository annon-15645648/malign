import json
import math
import pickle
import argparse
import hashlib
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple, Optional

import numpy as np
import pandas as pd

from constants import REPO_ROOT


@dataclass
class NgramLM:
    order: int
    k: float
    vocab: Dict[str, int]
    unk_id: int
    bos_id: int

    counts: List[Dict[Tuple[int, ...], Counter]]
    context_totals: List[Dict[Tuple[int, ...], int]]

    def logprob_next(self, history: List[int], token_id: int) -> float:
        V = len(self.vocab)
        max_h = self.order - 1
        h = history[-max_h:] if max_h > 0 else []

        for n in range(self.order, 0, -1):
            ctx_len = n - 1
            ctx = tuple(h[-ctx_len:]) if ctx_len > 0 else tuple()

            dist = self.counts[n].get(ctx)
            total = self.context_totals[n].get(ctx, 0)

            if total > 0 and dist is not None:
                c_hw = dist.get(token_id, 0)
                p = (c_hw + self.k) / (total + self.k * V)
                return math.log(p)

        return -math.log(V)

    def logprob_prefixes(self, tokens: List[int]) -> List[float]:
        hist = [self.bos_id]
        cum = 0.0
        out = []
        for tid in tokens:
            lp = self.logprob_next(hist, tid)
            cum += lp
            out.append(cum)
            hist.append(tid)
        return out


def build_vocab(seqs: List[List[str]], min_freq: int = 1) -> Dict[str, int]:
    c = Counter()
    for s in seqs:
        c.update(s)
    vocab = {"<UNK>": 0, "<BOS>": 1}
    for tok, freq in c.items():
        if freq >= min_freq and tok not in vocab:
            vocab[tok] = len(vocab)
    return vocab


def encode(seqs: List[List[str]], vocab: Dict[str, int]) -> List[List[int]]:
    unk = vocab["<UNK>"]
    return [[vocab.get(t, unk) for t in s] for s in seqs]


def train_ngram_lm(
    seqs_tok: List[List[str]],
    vocab: Dict[str, int],
    order: int = 5,
    k: float = 0.1,
) -> NgramLM:
    """
    Train an n-gram LM using a PROVIDED vocab (shared across benign+malware).
    This guarantees both LMs live in the same token-ID space.
    """
    unk_id = vocab["<UNK>"]
    bos_id = vocab["<BOS>"]

    seqs = encode(seqs_tok, vocab)

    counts: List[Dict[Tuple[int, ...], Counter]] = [defaultdict(Counter) for _ in range(order + 1)]
    totals: List[Dict[Tuple[int, ...], int]] = [defaultdict(int) for _ in range(order + 1)]

    max_h = order - 1
    for s in seqs:
        hist = [bos_id]
        for tid in s:
            h = hist[-max_h:] if max_h > 0 else []
            for n in range(1, order + 1):
                ctx_len = n - 1
                ctx = tuple(h[-ctx_len:]) if ctx_len > 0 else tuple()
                counts[n][ctx][tid] += 1
                totals[n][ctx] += 1
            hist.append(tid)

    return NgramLM(
        order=order,
        k=k,
        vocab=vocab,
        unk_id=unk_id,
        bos_id=bos_id,
        counts=counts,
        context_totals=totals,
    )

def max_lr_score_over_prefixes(lm_mal: NgramLM, lm_ben: NgramLM, seq: List[str]) -> Tuple[float, List[float]]:
    """
    Returns:
      - max LR over prefixes (trace-level alert score under "any prefix triggers" rule)
      - LR trajectory S(t) for all prefixes
    """
    mal_ids = [lm_mal.vocab.get(t, lm_mal.unk_id) for t in seq]
    ben_ids = [lm_ben.vocab.get(t, lm_ben.unk_id) for t in seq]

    mal_lp = lm_mal.logprob_prefixes(mal_ids)
    ben_lp = lm_ben.logprob_prefixes(ben_ids)

    s = [a - b for a, b in zip(mal_lp, ben_lp)]
    return (max(s) if s else float("-inf")), s


def load_splits(processed_dir: Path) -> dict:
    with open(processed_dir / "splits.json", "r", encoding="utf-8") as f:
        return json.load(f)


def iter_trace_batches(processed_dir: Path, columns: list[str], glob_pat: str = "traces_batch_*.parquet"):
    files = sorted(processed_dir.glob(glob_pat))
    if not files:
        raise FileNotFoundError(f"No trace batch files found in {processed_dir} matching {glob_pat}")
    for fp in files:
        yield fp, pd.read_parquet(fp, columns=columns)


def load_sequences_for_ids(
    processed_dir: Path,
    id_set: set[str],
    *,
    id_col: str,
) -> tuple[List[List[str]], int]:
    """
    Returns (seqs, missing_count).
    """
    out: list[list[str]] = []
    remaining = set(id_set)

    for _, df in iter_trace_batches(processed_dir, columns=[id_col, "tokens"]):
        if not remaining:
            break
        sub = df[df[id_col].isin(remaining)]
        if not sub.empty:
            out.extend(sub["tokens"].tolist())
            remaining.difference_update(sub[id_col].tolist())

    return out, len(remaining)


def pick_latest_processed_dir() -> Path:
    root = Path(REPO_ROOT)
    cands = [p for p in root.glob("processed_*") if p.is_dir()]
    if not cands:
        raise FileNotFoundError(f"No processed_* dirs under {root}")
    return max(cands, key=lambda p: p.stat().st_mtime)


def quantile_threshold_discrete(scores: np.ndarray, alpha: float) -> tuple[float, float, int]:
    """
    Discrete threshold for trace-level FPR control using ONLY attainable FPRs.

    We choose the *least conservative* threshold (smallest tau) such that:
        mean(score >= tau) <= alpha
    using the operational ">=" rule.

    Returns:
      tau, achievable_alpha, allowed_fp_count
    """
    scores = np.asarray(scores, dtype=float)
    n = int(scores.size)
    if n == 0:
        return float("inf"), 0.0, 0

    allowed = int(math.floor(alpha * n))

    if allowed <= 0:
        return float(np.max(scores)) + 1e-12, 0.0, 0

    uniq = np.unique(scores)
    for tau in uniq:
        fp = int(np.sum(scores >= tau))
        if fp <= allowed:
            achievable = fp / n
            return float(tau), float(achievable), int(allowed)

    return float(np.max(scores)) + 1e-12, 0.0, int(allowed)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--processed_dir",
        type=str,
        default=None,
        help="processed_{timestamp} directory. If omitted, picks newest processed_* under REPO_ROOT.",
    )
    ap.add_argument("--order", type=int, default=5)
    ap.add_argument("--k", type=float, default=0.1)
    ap.add_argument("--min_freq", type=int, default=1)
    ap.add_argument(
        "--fail_on_missing",
        type=float,
        default=0.0,
        help="Hard-fail if missing-ID fraction exceeds this (e.g., 0.001 = 0.1%). Default 0.0 (fail if any missing).",
    )
    args = ap.parse_args()

    processed_dir = Path(args.processed_dir) if args.processed_dir else pick_latest_processed_dir()
    print(f"Using processed dir: {processed_dir}")

    splits = load_splits(processed_dir)
    id_col = splits.get("id_col", "trace_id_content")

    ben_train_ids = set(splits["benign"]["train"])
    ben_val_ids = set(splits["benign"]["val"])
    mal_train_ids = set(splits["malware"]["train"])

    print(f"Using id_col={id_col}")
    print("Loading sequences from parquet batches...")
    ben_train, miss_bt = load_sequences_for_ids(processed_dir, ben_train_ids, id_col=id_col)
    ben_val, miss_bv = load_sequences_for_ids(processed_dir, ben_val_ids, id_col=id_col)
    mal_train, miss_mt = load_sequences_for_ids(processed_dir, mal_train_ids, id_col=id_col)

    shared_vocab = build_vocab(ben_train + mal_train, min_freq=args.min_freq)

    def check_missing(name: str, missing: int, total: int) -> None:
        frac = (missing / total) if total else 0.0
        if missing:
            print(f"[WARN] {name}: missing {missing}/{total} ids ({frac:.6f})")
        if frac > float(args.fail_on_missing):
            raise RuntimeError(f"{name}: missing fraction {frac:.6f} exceeds fail_on_missing={args.fail_on_missing}")

    check_missing("ben_train", miss_bt, len(ben_train_ids))
    check_missing("ben_val", miss_bv, len(ben_val_ids))
    check_missing("mal_train", miss_mt, len(mal_train_ids))

    print(f"Train sizes (loaded): benign_train={len(ben_train)} benign_val={len(ben_val)} malware_train={len(mal_train)}")

    print("Training benign n-gram LM...")
    lm_ben = train_ngram_lm(ben_train, vocab=shared_vocab, order=args.order, k=args.k)
    print("Training malware n-gram LM...")
    lm_mal = train_ngram_lm(mal_train, vocab=shared_vocab, order=args.order, k=args.k)

    model_path = processed_dir / "ngram_models.pkl"
    with open(model_path, "wb") as f:
        pickle.dump(
            {
                "lm_ben": lm_ben,
                "lm_mal": lm_mal,
                "shared_vocab": shared_vocab,
            },
            f,
        )
    assert lm_ben.vocab == lm_mal.vocab, "BUG: n-gram vocabs differ (should be shared)"
    print(f"Saved: {model_path}")

    print("Scoring benign VAL for thresholds (benign val only)...")
    max_scores = np.empty(len(ben_val), dtype=float)

    for i, seq in enumerate(ben_val):
        m, _ = max_lr_score_over_prefixes(lm_mal, lm_ben, seq)
        max_scores[i] = m

    n_val = len(max_scores)
    if n_val < 1000:
        print(f"[WARN] benign VAL is small (n={n_val}); very low FPR targets (e.g., 0.1%) are not resolvable at trace-level.")

    tau_01_q = float(np.quantile(max_scores, 0.999))
    tau_1_q  = float(np.quantile(max_scores, 0.99))
    tau_5_q  = float(np.quantile(max_scores, 0.95))
    tau_10_q  = float(np.quantile(max_scores, 0.90))


    tau_01_d, alpha_01_eff, k01 = quantile_threshold_discrete(max_scores, 0.001)
    tau_1_d,  alpha_1_eff,  k1  = quantile_threshold_discrete(max_scores, 0.01)
    tau_5_d,  alpha_5_eff,  k5  = quantile_threshold_discrete(max_scores, 0.05)
    tau_10_d,  alpha_10_eff,  k10  = quantile_threshold_discrete(max_scores, 0.10)

    def realized_fpr(tau: float) -> float:
        return float(np.mean(max_scores >= tau))

    out = {
        "seed": splits.get("seed", None),
        "id_col": id_col,
        "order": args.order,
        "k": args.k,
        "min_freq": args.min_freq,
        "threshold_source": "benign_val_only",
        "threshold_method": "tau on max_prefix_lr_score (trace triggers if any prefix crosses tau)",
        "processed_dir": str(processed_dir),
        "trace_batches_glob": str(processed_dir / "traces_batch_*.parquet"),
        "n_ben_train": len(ben_train),
        "n_ben_val": len(ben_val),
        "n_mal_train": len(mal_train),
        "missing_ids": {
            "ben_train": miss_bt,
            "ben_val": miss_bv,
            "mal_train": miss_mt,
        },
        "tau": {
            "q_0.1pct": tau_01_q,
            "q_1pct": tau_1_q,
            "q_5pct": tau_5_q,
            "q_10pct": tau_10_q,
            "discrete_0.1pct": tau_01_d,
            "discrete_1pct": tau_1_d,
            "discrete_5pct": tau_5_d,
            "discrete_10pct": tau_10_d,
        },
        "effective_alpha_discrete": {
            "target_0.1pct": 0.001,
            "achievable_0.1pct": alpha_01_eff,
            "allowed_fp_count_0.1pct": k01,
            "target_1pct": 0.01,
            "achievable_1pct": alpha_1_eff,
            "allowed_fp_count_1pct": k1,
            "target_5pct": 0.05,
            "achievable_5pct": alpha_5_eff,
            "allowed_fp_count_5pct": k5,
            "target_10pct": 0.10,
            "achievable_10pct": alpha_10_eff,
            "allowed_fp_count_10pct": k10,
        },
        "val_realized_fpr": {
            "q_0.1pct_score>=tau": realized_fpr(tau_01_q),
            "q_1pct_score>=tau": realized_fpr(tau_1_q),
            "q_5pct_score>=tau": realized_fpr(tau_5_q),
            "q_10pct_score>=tau": realized_fpr(tau_10_q),
            "discrete_0.1pct_score>=tau": realized_fpr(tau_01_d),
            "discrete_1pct_score>=tau": realized_fpr(tau_1_d),
            "discrete_5pct_score>=tau": realized_fpr(tau_5_d),
            "discrete_10pct_score>=tau": realized_fpr(tau_10_d),
        },
        "tau_0_1": tau_01_d,
        "tau_1_0": tau_1_d,
        "tau_5_0": tau_5_d,
        "tau_10_0": tau_10_d,
        "ben_val_score_summary": {
            "n": int(n_val),
            "min": float(np.min(max_scores)) if n_val else None,
            "median": float(np.median(max_scores)) if n_val else None,
            "p90": float(np.quantile(max_scores, 0.9)) if n_val else None,
            "p99": float(np.quantile(max_scores, 0.99)) if n_val else None,
            "max": float(np.max(max_scores)) if n_val else None,
        },
    }

    thr_path = processed_dir / "ngram_thresholds.json"    
    with open(thr_path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(f"Saved: {thr_path}")

    print(json.dumps(out["tau"], indent=2))
    print("VAL realized FPR (trace-level):")
    print(json.dumps(out["val_realized_fpr"], indent=2))


if __name__ == "__main__":
    main()
